package com.gcscheduling.generated;

import com.concurrency.agent.WorkerMetadata;
import java.util.concurrent.*;
import java.util.*;
import java.lang.ref.*;
import org.example.codegen.model.GCObj;
public class ConcurrentTest_20260107_035354_424 {
    private static volatile GCObj gcObj0 = new GCObj(189480);
    private static volatile Set<Object> set0 = new HashSet();
    private static volatile List<Object> list0 = new Vector();
    private static volatile Map<Object, Object> objVar0 = new LinkedHashMap();
    private static volatile Map<Object, Object> map0 = new HashMap();
    private static volatile List<Object> list1 = new LinkedList();
    private static volatile int[] arr0 = new int[31520];
    private static volatile Object[] arr1 = new Object[66739];
    private static volatile Set<Object> set1 = new TreeSet();
    private static volatile List<Object> list2 = new ArrayList();
    private static volatile Set<Object> set2 = new TreeSet();
    private static volatile GCObj gcObj1 = new GCObj(127338);
    private static volatile GCObj gcObj2 = new GCObj(1953725);
    private static volatile List<Object> list3 = new ArrayList();
    private static volatile List<Object> list4 = new ArrayList();
    private static volatile Set<Object> set3 = new TreeSet();
    private static volatile int[] arr2 = new int[924];
    private static volatile List<Object> list5 = new ArrayList();
    private static volatile GCObj gcObj3 = new GCObj(5368128);
    private static volatile Set<Object> set4 = new TreeSet();
    private static volatile Set<Object> objVar1 = new LinkedHashSet();
    private static volatile Set<Object> objVar2 = new LinkedHashSet();
    private static volatile GCObj gcObj4 = new GCObj(258750);
    private static volatile PhantomReference<GCObj> objVar3 = new PhantomReference(gcObj0, new ReferenceQueue());
    private static volatile int marRoundCounter = 0;
    private static volatile int mdrRoundCounter = 0;
    private static volatile int mmrRoundCounter = 0;
    private static volatile int sparRoundCounter = 0;
    private static volatile long TRAPCOUNT = 0L;
    public static void main(String[] args) throws ExecutionException, InterruptedException {
        try {
            Class.forName("com.gcscheduling.generated.ConcurrentTest_20260107_035354_424$MARWorker");
            Class.forName("com.gcscheduling.generated.ConcurrentTest_20260107_035354_424$MDRWorker");
            Class.forName("com.gcscheduling.generated.ConcurrentTest_20260107_035354_424$MMRWorker");
            Class.forName("com.gcscheduling.generated.ConcurrentTest_20260107_035354_424$SPARWorker");
        }
        catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        ExecutorService executorPool = Executors.newFixedThreadPool(4);

        Future<?> f1 = executorPool.submit(new MARWorker());
        Future<?> f2 = executorPool.submit(new MDRWorker());
        Future<?> f3 = executorPool.submit(new MMRWorker());
        Future<?> f4 = executorPool.submit(new SPARWorker());
        try {
            f1.get(10, TimeUnit.SECONDS);
            f2.get(10, TimeUnit.SECONDS);
            f3.get(10, TimeUnit.SECONDS);
            f4.get(10, TimeUnit.SECONDS);
        }
        catch (Exception e) {
            System.out.println("任务执行超时或异常: " + e.getMessage());
            f1.cancel(true);
            f2.cancel(true);
            f3.cancel(true);
            f4.cancel(true);
        }
        
        executorPool.shutdown();
        System.exit(0);
    }

    @WorkerMetadata(threadId = 0)
    static class MARWorker implements Runnable {
        static volatile List<Object> allocatedObjects = new ArrayList();
        static volatile Set<Object> largeObjectSet = new HashSet();
        static volatile Map<Object, Object> objectCache = new HashMap();
        static volatile List<List<Object> > nestedCollections = new ArrayList();
        static volatile GCObj objVar4 = new GCObj(6502758);
        static volatile List<Object> objVar5 = new Vector();
        static volatile Object[] objVar6 = new Object[17607];
        static volatile GCObj objVar7 = new GCObj(1027427);
        static volatile int[] objVar8 = new int[938];
        static volatile WeakReference<GCObj> objVar9 = new WeakReference(gcObj0);
        @Override
        public void run() {
            int switchVar = 0;
            int whileCounter = 0;
            int doWhileCounter = 0;
            boolean shouldThrowException = false;
            while (marRoundCounter<15) {
                ++marRoundCounter;
                int currentRound = marRoundCounter;
                System.out.println("MAR Round 1");
                shouldThrowException = false;
                try {
                    if (shouldThrowException) {
                        OutOfMemoryError thrownException = new OutOfMemoryError("Simulated OOM during allocation");
                        throw thrownException;
                    }
                    set1 = new TreeSet();
                }
                catch (Exception e) {
                    TRAPCOUNT++;
                    System.out.println("Exception caught during allocation");
                }
                doWhileCounter = 0;
                do {
                    doWhileCounter++;
                }
                while (doWhileCounter<4);
                if (TRAPCOUNT % 2  == 0) {
                    list3 = new ArrayList();
                }
                else {
                    set4 = new TreeSet();
                }
                shouldThrowException = false;
                try {
                    if (shouldThrowException) {
                        OutOfMemoryError thrownException = new OutOfMemoryError("Simulated OOM during allocation");
                        throw thrownException;
                    }
                    arr0 = new int[728];
                }
                catch (Exception e) {
                    TRAPCOUNT++;
                    System.out.println("Exception caught during allocation");
                }
                if (TRAPCOUNT % 2  == 0) {
                    allocatedObjects.add(new GCObj(4922850));
                }
                System.out.println("MAR Round 2");
                for (int i = 0;  i < 4; i++) {
                    allocatedObjects.add(new GCObj(108563));
                }
                set4 = new TreeSet();
                set3 = new TreeSet();
                list0 = new Vector();
                if (TRAPCOUNT % 2  == 0) {
                    allocatedObjects.add(new GCObj(235397));
                }
                else {
                    list0 = new Vector();
                }
                if (TRAPCOUNT % 2  == 0) {
                    list1 = new LinkedList();
                }
                else {
                    allocatedObjects.add(new GCObj(7648084));
                }
                if (TRAPCOUNT % 2  == 0) {
                    allocatedObjects.add(new GCObj(5669426));
                }
                else {
                }
                for (int i = 0;  i < 3; i++) {
                    map0 = new HashMap();
                }
                System.gc();
                System.out.println("MAR Round 3");
                shouldThrowException = false;
                try {
                    if (shouldThrowException) {
                        OutOfMemoryError thrownException = new OutOfMemoryError("Simulated OOM during allocation");
                        throw thrownException;
                    }
                    objVar3 = new PhantomReference(gcObj2, new ReferenceQueue());
                }
                catch (Exception e) {
                    TRAPCOUNT++;
                    System.out.println("Exception caught during allocation");
                }
                allocatedObjects.add(new GCObj(173748));
                allocatedObjects.add(new GCObj(6502793));
                list4 = new ArrayList();
                list4 = new ArrayList();
                map0 = new HashMap();
                arr2 = new int[1870];
                System.out.println("MAR Round 4");
                for (int i = 0;  i<2; i++) {
                    allocatedObjects.add(new GCObj(2001897));
                }
                for (int i = 0;  i<4; i++) {
                }
                for (int i = 0;  i < 2; i++) {
                    list2 = new ArrayList();
                }
                if (TRAPCOUNT % 2  == 0) {
                    map0 = new HashMap();
                }
                whileCounter = 0;
                while (whileCounter < 2) {
                    list0 = new Vector();
                    whileCounter++;
                }
                doWhileCounter = 0;
                do {
                    allocatedObjects.add(new GCObj(179076));
                    doWhileCounter++;
                }
                while (doWhileCounter < 3);
                System.out.println("MAR Round 5");
                allocatedObjects.add(new GCObj(109300));
                allocatedObjects.add(new GCObj(126351));
                allocatedObjects.add(new GCObj(3877799));
                objVar8 = new int[260];
                arr2 = new int[163];
                allocatedObjects.add(new GCObj(202788));
                allocatedObjects.add(new GCObj(231459));
                allocatedObjects.add(new GCObj(79036));
                System.out.println("MAR Round 6");
                allocatedObjects.add(new GCObj(929061));
                allocatedObjects.add(new GCObj(1574530));
                allocatedObjects.add(new GCObj(120444));
                allocatedObjects.add(new GCObj(3467086));
                allocatedObjects.add(new GCObj(82876));
                allocatedObjects.add(new GCObj(5670046));
                list4 = new ArrayList();
                list4 = new ArrayList();
                System.out.println("MAR Round 7");
                allocatedObjects.add(new GCObj(5327568));
                allocatedObjects.add(new GCObj(1339458));
                list2 = new ArrayList();
                allocatedObjects.add(new GCObj(6179374));
                allocatedObjects.add(new GCObj(78924));
                list5 = new ArrayList();
                allocatedObjects.add(new GCObj(1990206));
                arr2 = new int[5385];
                System.out.println("MAR Round 8");
                whileCounter = 0;
                while (whileCounter < 3) {
                    whileCounter++;
                }
                if (TRAPCOUNT % 2  == 0) {
                    allocatedObjects.add(new GCObj(3941489));
                }
                if (TRAPCOUNT % 2  == 0) {
                    list0 = new Vector();
                }
                else {
                    set4 = new TreeSet();
                }
                whileCounter = 0;
                while (whileCounter < 4) {
                    allocatedObjects.add(new GCObj(199846));
                    whileCounter++;
                }
                whileCounter = 0;
                while (whileCounter < 4) {
                    list3 = new ArrayList();
                    whileCounter++;
                }
                System.out.println("MAR Round 9");
                whileCounter = 0;
                while (whileCounter < 4) {
                    whileCounter++;
                }
                whileCounter = 0;
                while (whileCounter < 2) {
                    list4 = new ArrayList();
                    whileCounter++;
                }
                for (int i = 0;  i < 4; i++) {
                    set1 = new TreeSet();
                }
                shouldThrowException = false;
                try {
                    if (shouldThrowException) {
                        OutOfMemoryError thrownException = new OutOfMemoryError("Simulated OOM during allocation");
                        throw thrownException;
                    }
                    objVar8 = new int[6233];
                }
                catch (Exception e) {
                    TRAPCOUNT++;
                    System.out.println("Exception caught during allocation");
                }
                switchVar = 2;
                System.out.println("MAR Round 10");
                allocatedObjects.add(new GCObj(5000318));
                allocatedObjects.add(new GCObj(2552134));
                set4 = new TreeSet();
                list1 = new LinkedList();
                map0 = new HashMap();
                for (int i = 0;  i < 2; i++) {
                    list0 = new Vector();
                }
                allocatedObjects.add(new GCObj(7356008));
                list3 = new ArrayList();
                System.out.println("MAR Round 11");
                for (int i = 0;  i < 4; i++) {
                    list2 = new ArrayList();
                }
                whileCounter = 0;
                while (whileCounter < 2) {
                    whileCounter++;
                }
                doWhileCounter = 0;
                do {
                    arr2 = new int[701];
                    doWhileCounter++;
                }
                while (doWhileCounter < 3);
                doWhileCounter = 0;
                do {
                    list0 = new Vector();
                    doWhileCounter++;
                }
                while (doWhileCounter < 4);
                for (int i = 0;  i < 3; i++) {
                    allocatedObjects.add(new GCObj(6596847));
                }
                System.out.println("MAR Round 12");
                shouldThrowException = false;
                try {
                    if (shouldThrowException) {
                        OutOfMemoryError thrownException = new OutOfMemoryError("Simulated OOM during allocation");
                        throw thrownException;
                    }
                    list3 = new ArrayList();
                }
                catch (Exception e) {
                    TRAPCOUNT++;
                    System.out.println("Exception caught during allocation");
                }
                doWhileCounter = 0;
                do {
                    set0 = new HashSet();
                    doWhileCounter++;
                }
                while (doWhileCounter < 4);
                for (int i = 0;  i < 2; i++) {
                    allocatedObjects.add(new GCObj(1073473));
                }
                if (TRAPCOUNT % 2  == 0) {
                    arr0 = new int[180];
                }
                else {
                    set3 = new TreeSet();
                }
                doWhileCounter = 0;
                do {
                    allocatedObjects.add(new GCObj(185290));
                    doWhileCounter++;
                }
                while (doWhileCounter < 3);
                System.out.println("MAR Round 13");
                shouldThrowException = false;
                try {
                    if (shouldThrowException) {
                        OutOfMemoryError thrownException = new OutOfMemoryError("Simulated OOM during allocation");
                        throw thrownException;
                    }
                    list3 = new ArrayList();
                }
                catch (Exception e) {
                    TRAPCOUNT++;
                    System.out.println("Exception caught during allocation");
                }
                whileCounter = 0;
                while (whileCounter < 3) {
                    objVar8 = new int[705];
                    whileCounter++;
                }
                shouldThrowException = false;
                try {
                    if (shouldThrowException) {
                        OutOfMemoryError thrownException = new OutOfMemoryError("Simulated OOM during allocation");
                        throw thrownException;
                    }
                }
                catch (Exception e) {
                    TRAPCOUNT++;
                    System.out.println("Exception caught during allocation");
                }
                for (int i = 0;  i < 4; i++) {
                    list0 = new Vector();
                }
                doWhileCounter = 0;
                System.out.println("MAR Round 14");
                if (TRAPCOUNT % 2  == 0) {
                    list1 = new LinkedList();
                }
                else {
                }
                doWhileCounter = 0;
                do {
                    set2 = new TreeSet();
                    doWhileCounter++;
                }
                while (doWhileCounter < 2);
                if (TRAPCOUNT % 2  == 0) {
                    set3 = new TreeSet();
                }
                else {
                    allocatedObjects.add(new GCObj(8299889));
                }
                shouldThrowException = false;
                try {
                    if (shouldThrowException) {
                        OutOfMemoryError thrownException = new OutOfMemoryError("Simulated OOM during allocation");
                        throw thrownException;
                    }
                    allocatedObjects.add(new GCObj(6322582));
                }
                catch (Exception e) {
                    TRAPCOUNT++;
                    System.out.println("Exception caught during allocation");
                }
                if (TRAPCOUNT % 2  == 0) {
                    allocatedObjects.add(new GCObj(6243886));
                }
                else {
                    set2 = new TreeSet();
                }
                doWhileCounter = 0;
                System.out.println("MAR Round 15");
                doWhileCounter = 0;
                do {
                    set0 = new HashSet();
                    doWhileCounter++;
                }
                while (doWhileCounter < 4);
                doWhileCounter = 0;
                do {
                    doWhileCounter++;
                }
                while (doWhileCounter < 2);
                if (TRAPCOUNT % 2  == 0) {
                    allocatedObjects.add(new GCObj(2003451));
                }
                shouldThrowException = false;
                try {
                    if (shouldThrowException) {
                        OutOfMemoryError thrownException = new OutOfMemoryError("Simulated OOM during allocation");
                        throw thrownException;
                    }
                    list5 = new ArrayList();
                }
                catch (Exception e) {
                    TRAPCOUNT++;
                    System.out.println("Exception caught during allocation");
                }
                allocatedObjects.add(new GCObj(674616));
            }
        }
    }

    @WorkerMetadata(threadId = 1)
    static class MDRWorker implements Runnable {
        private static final Random random = new Random(0L);
        @Override
        public void run() {
            int switchVar = 0;
            int whileCounter = 0;
            int doWhileCounter = 0;
            boolean shouldThrowException = false;
            while (mdrRoundCounter < 11) {
                ++mdrRoundCounter;
                int currentRound = mdrRoundCounter;
                System.out.println("MDR Round 1");
                if (random.nextDouble() < 0.5) {
                    MARWorker.objVar8 = null;
                }
                else {
                    System.gc();
                    System.out.println("System.gc()called - requesting garbage collection");
                    System.runFinalization();
                }
                gcObj0 = null;
                arr2 = null;
                System.gc();
                System.out.println("MDR Round 2");
                doWhileCounter = 0;
                do {
                    set2 = null;
                    doWhileCounter++;
                }
                while (doWhileCounter < 1);
                switchVar = 0;
                System.gc();
                System.out.println("MDR Round 3");
                for (int i = 0;  i < 2; i++) {
                    set1 = null;
                }
                System.gc();
                System.out.println("System.gc()called - requesting garbage collection");
                System.gc();
                System.out.println("MDR Round 4");
                System.gc();
                System.out.println("System.gc()called - requesting garbage collection");
                System.runFinalization();
                System.gc();
                System.out.println("MDR Round 5");
                System.gc();
                System.out.println("System.gc()called - requesting garbage collection");
                System.runFinalization();
                System.gc();
                System.out.println("MDR Round 6");
                System.gc();
                System.out.println("System.gc()called - requesting garbage collection");
                System.runFinalization();
                System.gc();
                System.out.println("MDR Round 7");
                System.gc();
                System.out.println("System.gc()called - requesting garbage collection");
                System.gc();
                System.gc();
                System.out.println("MDR Round 8");
                System.gc();
                System.out.println("System.gc()called - requesting garbage collection");
                System.gc();
                System.gc();
                System.out.println("MDR Round 9");
                System.gc();
                System.out.println("System.gc()called - requesting garbage collection");
                System.gc();
                System.gc();
                System.out.println("MDR Round 10");
                System.gc();
                System.out.println("MDR Round 11");
                System.gc();
                System.out.println("System.gc()called - requesting garbage collection");
                System.gc();
                System.gc();
            }
        }
    }

    @WorkerMetadata(threadId = 2)
    static class MMRWorker implements Runnable {
        private static final Random random = new Random(0L);
        @Override
        public void run() {
            int safeIndex = 0;
            int switchVar = 0;
            int whileCounter = 0;
            int doWhileCounter = 0;
            boolean shouldThrowException = false;
            while (mmrRoundCounter < 15) {
                ++mmrRoundCounter;
                int currentRound = mmrRoundCounter;
                System.out.println("MMR Round 1");
                if (set0 != null && set0.size()> 0) {
                    set0.clear();
                }
                set4 = new TreeSet();
                if (arr0 != null && arr0.length > 0) {
                    safeIndex = arr0.length > 0 ? arr0.length / 2 : 0;
                    arr0[safeIndex] = 178;
                }
                for (int i = 0;  i<2; i++) {
                    if (arr0 != null && arr0.length> 0) {
                        safeIndex = arr0.length > 0 ? arr0.length / 2 : 0;
                        arr0[safeIndex] = 886;
                    }
                }
                MARWorker.objVar4.replaceStrongReference(null);
                System.out.println("MMR Round 2");
                gcObj2.processGCObj();
                list5.add(new Object());
                for (int i = 0;  i<2; i++) {
                    gcObj4 = new GCObj(13396);
                }
                MARWorker.objVar4.modifyArrayElement(7, 512);
                if (list4 != null && list4.size()> 0) {
                    list4.set(0, new Object());
                }
                System.out.println("MMR Round 3");
                if (random.nextBoolean()) {
                    if (arr0 != null && arr0.length > 0) {
                        safeIndex = arr0.length > 0 ? arr0.length / 2 : 0;
                        arr0[safeIndex] = 628;
                    }
                }
                for (int i = 0;  i<1; i++) {
                    if (set3 != null && set3.size()> 0) {
                        set3.clear();
                    }
                }
                if (random.nextBoolean()) {
                    gcObj3.modifyArrayElement(5, 659);
                }
                MARWorker.objVar4.processGCObj();
                if (MARWorker.objVar6 != null && MARWorker.objVar6.length > 0) {
                    MARWorker.objVar6[0] = "element_68";
                }
                System.out.println("MMR Round 4");
                gcObj1.replaceStrongReference(null);
                list1.add(new Object());
                try {
                    gcObj4.processGCObj();
                }
                catch (Exception e) {
                }
                MARWorker.objVar7 = new GCObj(38098);
                list0.add(696);
                System.out.println("MMR Round 5");
                for (int i = 0;  i<1; i++) {
                    list4 = new ArrayList();
                }
                MARWorker.objVar4.processGCObj();
                map0.put("collection_element_58", new Object());
                list4.add(new Object());
                set4 = new TreeSet();
                System.out.println("MMR Round 6");
                gcObj4 = new GCObj(61421);
                if (list5 != null && list5.size()> 0) {
                    list5.set(0, new Object());
                }
                set4 = new TreeSet();
                list4.add(292);
                arr0 = new int[31520];
                System.out.println("MMR Round 7");
                MARWorker.objVar7.modifyArrayElement(2, 832);
                MARWorker.objVar5.add(12);
                list0 = new Vector();
                map0.clear();
                gcObj2.replaceStrongReference(null);
                System.out.println("MMR Round 8");
                MARWorker.objVar4 = new GCObj(50249);
                objVar0 = null;
                try {
                    objVar3 = null;
                }
                catch (Exception e) {
                }
                gcObj4.processGCObj();
                list0.add(new Object());
                System.out.println("MMR Round 9");
                gcObj3.processGCObj();
                MARWorker.objVar7.modifyArrayElement(3, 719);
                gcObj4.processGCObj();
                for (int i = 0;  i<2; i++) {
                    if (set3 != null && set3.size()> 0) {
                        set3.clear();
                    }
                }
                gcObj3 = new GCObj(47818);
                System.out.println("MMR Round 10");
                gcObj4.processGCObj();
                if (MARWorker.objVar5 != null && MARWorker.objVar5.size() > 0) {
                    MARWorker.objVar5.remove(0);
                }
                try {
                    gcObj1.replaceStrongReference(null);
                }
                catch (Exception e) {
                }
                if (random.nextBoolean()) {
                    gcObj2.replaceStrongReference(null);
                }
                MARWorker.objVar4.replaceStrongReference(null);
                System.out.println("MMR Round 11");
                MARWorker.objVar4.replaceStrongReference(null);
                MARWorker.objVar5.clear();
                gcObj1.replaceStrongReference(null);
                if (random.nextBoolean()) {
                    set3 = new TreeSet();
                }
                for (int i = 0;  i<2; i++) {
                    if (arr0 != null && arr0.length> 0) {
                        safeIndex = arr0.length > 0 ? arr0.length / 2 : 0;
                        arr0[safeIndex] = 497;
                    }
                }
                System.out.println("MMR Round 12");
                if (MARWorker.objVar6 != null && MARWorker.objVar6.length > 0) {
                    safeIndex = MARWorker.objVar6.length > 0 ? MARWorker.objVar6.length / 2 : 0;
                    MARWorker.objVar6[safeIndex] = "element_86";
                }
                gcObj4.processGCObj();
                gcObj3.replaceStrongReference(null);
                map0.put("collection_element_79", new Object());
                set4.add(new Object());
                System.out.println("MMR Round 13");
                gcObj1.processGCObj();
                if (arr0 != null && arr0.length > 0) {
                    arr0[0] = 453;
                }
                list4.add(new Object());
                if (random.nextBoolean()) {
                    if (list0 != null && list0.size() > 0) {
                        list0.set(0, new Object());
                    }
                }
                try {
                    set3.clear();
                }
                catch (Exception e) {
                }
                System.out.println("MMR Round 14");
                for (int i = 0;  i<1; i++) {
                    gcObj4 = new GCObj(26444);
                }
                gcObj3.replaceStrongReference(null);
                gcObj4.processGCObj();
                if (arr0 != null && arr0.length> 0) {
                    arr0[0] = 914;
                }
                list4.add(new Object());
                System.out.println("MMR Round 15");
                list4.clear();
                try {
                    MARWorker.objVar7.processGCObj();
                }
                catch (Exception e) {
                }
                for (int i = 0;  i<1; i++) {
                    list5.add(433);
                }
                if (random.nextBoolean()) {
                    set0.clear();
                }
                for (int i = 0;  i<1; i++) {
                    MARWorker.objVar4.replaceStrongReference(null);
                }
            }
        }
    }

    @WorkerMetadata(threadId = 3)
    static class SPARWorker implements Runnable {
        private static final Random random = new Random(0L);
        @Override
        public void run() {
            int switchVar = 0;
            int whileCounter = 0;
            int doWhileCounter = 0;
            boolean shouldThrowException = false;
            while (sparRoundCounter < 12) {
                ++sparRoundCounter;
                int currentRound = sparRoundCounter;
                System.out.println("SPAR Round 1");
                doWhileCounter = 0;
                do {
                    if (gcObj1 != null) {
                        gcObj1.processGCObj();
                    }
                    doWhileCounter++;
                }
                while (doWhileCounter < 6);
                shouldThrowException = false;
                try {
                    if (shouldThrowException) {
                        NullPointerException thrownException = new NullPointerException("GCFuzz generated NullPointerException for testing");
                        throw thrownException;
                    }
                    arr0[0] = 24;
                }
                catch (Exception e) {
                    TRAPCOUNT++;
                    System.out.println("Exception caught");
                }
                switchVar = 1;
                switch (switchVar) {
                    case 0:
                    int temp547 = 37;
                    break;
                    case 1:
                    int temp491 = 57;
                    break;
                    case 2:
                    int temp310 = 33;
                    break;
                    default :
                    if (MARWorker.objVar4 != null) {
                        MARWorker.objVar4.processGCObj();
                    }
                }
                System.out.println("SPAR Round 2");
                switchVar = 2;
                switch (switchVar) {
                    case 0:
                    if (gcObj2 != null) {
                        gcObj2.processGCObj();
                    }
                    break;
                    case 1:
                    int temp30 = 82;
                    break;
                    case 2:
                    int temp353 = 91;
                    break;
                    default :
                    int temp660 = 51;
                }
                shouldThrowException = true;
                try {
                    if (shouldThrowException) {
                        RuntimeException thrownException = new RuntimeException("GCFuzz generated RuntimeException for testing");
                        throw thrownException;
                    }
                    arr0[0] = 70;
                }
                catch (Exception e) {
                    TRAPCOUNT++;
                    System.out.println("Exception caught");
                }
                switchVar = 2;
                switch (switchVar) {
                    case 0:
                    int temp610 = 11;
                    break;
                    case 1:
                    int temp261 = 82;
                    break;
                    case 2:
                    int temp484 = 25;
                    break;
                    default :
                    int temp485 = 99;
                }
                System.out.println("SPAR Round 3");
                whileCounter = 0;
                while (whileCounter < 10) {
                    int temp390 = 31;
                    whileCounter++;
                }
                whileCounter = 0;
                while (whileCounter < 9) {
                    if (gcObj1 != null) {
                        gcObj1.processGCObj();
                    }
                    whileCounter++;
                }
                doWhileCounter = 0;
                do {
                    int temp336 = 7;
                    doWhileCounter++;
                }
                while (doWhileCounter < 5);
                System.out.println("SPAR Round 4");
                if (TRAPCOUNT % 2  == 0) {
                    int temp68 = 25;
                }
                else {
                    int temp462 = 54;
                }
                shouldThrowException = false;
                try {
                    if (shouldThrowException) {
                        UnsupportedOperationException thrownException = new UnsupportedOperationException("GCFuzz generated UnsupportedOperationException for testing");
                        throw thrownException;
                    }
                    arr0[0] = 52;
                }
                catch (Exception e) {
                    TRAPCOUNT++;
                    System.out.println("Exception caught");
                }
                doWhileCounter = 0;
                do {
                    int temp104 = 10;
                    doWhileCounter++;
                }
                while (doWhileCounter < 3);
                whileCounter = 0;
                System.out.println("SPAR Round 5");
                doWhileCounter = 0;
                do {
                    if (MARWorker.objVar7 != null) {
                        MARWorker.objVar7.processGCObj();
                    }
                    doWhileCounter++;
                }
                while (doWhileCounter < 2);
                if (MARWorker.objVar9 != null) {
                    int temp984 = 23;
                }
                else {
                    int temp65 = 58;
                }
                if (MARWorker.objVar7 != null) {
                    int temp720 = 71;
                }
                else {
                    int temp729 = 55;
                }
                if (map0 != null) {
                    int temp564 = 98;
                }
                doWhileCounter = 0;
                System.out.println("SPAR Round 6");
                for (int i = 0;  i < 9; i++) {
                    int temp357 = 98;
                }
                shouldThrowException = false;
                try {
                    if (shouldThrowException) {
                        IllegalArgumentException thrownException = new IllegalArgumentException("GCFuzz generated IllegalArgumentException for testing");
                        throw thrownException;
                    }
                    arr0[0] = 27;
                }
                catch (Exception e) {
                    TRAPCOUNT++;
                    System.out.println("Exception caught");
                }
                finally {
                    System.gc();
                }
                whileCounter = 0;
                while (whileCounter < 8) {
                    int temp568 = 79;
                    whileCounter++;
                }
                doWhileCounter = 0;
                System.out.println("SPAR Round 7");
                doWhileCounter = 0;
                do {
                    if (gcObj3 != null) {
                        gcObj3.processGCObj();
                    }
                    doWhileCounter++;
                }
                while (doWhileCounter < 3);
                if (objVar2 != null) {
                    if (gcObj2 != null) {
                        gcObj2.processGCObj();
                    }
                }
                whileCounter = 0;
                while (whileCounter < 10) {
                    int temp753 = 31;
                    whileCounter++;
                }
                if (MARWorker.objVar5 != null && MARWorker.objVar5.size()> 0) {
                    if (gcObj1 != null) {
                        gcObj1.processGCObj();
                    }
                }
                else {
                    int temp513 = 51;
                }
                System.out.println("SPAR Round 8");
                shouldThrowException = false;
                try {
                    if (shouldThrowException) {
                        UnsupportedOperationException thrownException = new UnsupportedOperationException("GCFuzz generated UnsupportedOperationException for testing");
                        throw thrownException;
                    }
                    arr0[0] = 0;
                }
                catch (Exception e) {
                    TRAPCOUNT++;
                    System.out.println("Exception caught");
                }
                switchVar = 2;
                switch (switchVar) {
                    case 0:
                    if (gcObj3 != null) {
                        gcObj3.processGCObj();
                    }
                    break;
                    case 1:
                    int temp401 = 58;
                    break;
                    case 2:
                    int temp894 = 29;
                    break;
                    default :
                    int temp16 = 67;
                }
                if (MARWorker.objVar9 != null) {
                    int temp459 = 15;
                }
                else {
                    int temp373 = 41;
                }
                shouldThrowException = false;
                System.out.println("SPAR Round 9");
                if (gcObj1 != null) {
                    int temp378 = 93;
                }
                else {
                    int temp847 = 53;
                }
                whileCounter = 0;
                while (whileCounter < 8) {
                    if (gcObj4 != null) {
                        gcObj4.processGCObj();
                    }
                    whileCounter++;
                }
                whileCounter = 0;
                while (whileCounter < 5) {
                    int temp658 = 38;
                    whileCounter++;
                }
                if (objVar3 != null) {
                    int temp722 = 26;
                }
                else {
                    int temp146 = 37;
                }
                System.out.println("SPAR Round 10");
                shouldThrowException = false;
                try {
                    if (shouldThrowException) {
                        UnsupportedOperationException thrownException = new UnsupportedOperationException("GCFuzz generated UnsupportedOperationException for testing");
                        throw thrownException;
                    }
                    arr0[0] = 32;
                }
                catch (Exception e) {
                    TRAPCOUNT++;
                    System.out.println("Exception caught");
                }
                finally {
                    System.gc();
                }
                for (int i = 0;  i < 11; i++) {
                }
                shouldThrowException = true;
                try {
                    if (shouldThrowException) {
                        IndexOutOfBoundsException thrownException = new IndexOutOfBoundsException("GCFuzz generated IndexOutOfBoundsException for testing");
                        throw thrownException;
                    }
                    arr0[0] = 74;
                }
                catch (Exception e) {
                    TRAPCOUNT++;
                    System.out.println("Exception caught");
                }
                finally {
                    System.gc();
                }
                whileCounter = 0;
                System.out.println("SPAR Round 11");
                doWhileCounter = 0;
                do {
                    if (MARWorker.objVar4 != null) {
                        MARWorker.objVar4.processGCObj();
                    }
                    doWhileCounter++;
                }
                while (doWhileCounter < 3);
                for (int i = 0;  i < 14; i++) {
                    int temp640 = 45;
                }
                shouldThrowException = true;
                try {
                    if (shouldThrowException) {
                        RuntimeException thrownException = new RuntimeException("GCFuzz generated RuntimeException for testing");
                        throw thrownException;
                    }
                    arr0[0] = 18;
                }
                catch (Exception e) {
                    TRAPCOUNT++;
                    System.out.println("Exception caught");
                }
                finally {
                    System.gc();
                }
                shouldThrowException = false;
                System.out.println("SPAR Round 12");
                doWhileCounter = 0;
                do {
                    if (MARWorker.objVar7 != null) {
                        MARWorker.objVar7.processGCObj();
                    }
                    doWhileCounter++;
                }
                while (doWhileCounter < 2);
                if (MARWorker.objVar5 != null) {
                    if (gcObj1 != null) {
                        gcObj1.processGCObj();
                    }
                }
                else {
                    int temp495 = 84;
                }
                if (TRAPCOUNT % 2  == 0) {
                    int temp593 = 3;
                }
                else {
                    int temp298 = 48;
                }
                for (int i = 0;  i < 6; i++) {
                    if (gcObj1 != null) {
                        gcObj1.processGCObj();
                    }
                }
                shouldThrowException = false;
            }
        }
    }
}
