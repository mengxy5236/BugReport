#!/bin/bash
#
# Minimal replay runner for GCScheduling
# Purpose: provide a tiny, self-contained script to replay a scheduling sequence
# with only the Schedule agent JAR, a test .java/.class, a sequence JSON and optional vmopts.
#
# Usage:
#   ./replay_minimal.sh -s /path/to/sequence.json -t /path/to/Test.java [-p /path/to/vmopts] [-e /path/to/execution.properties]
#   If test is .java it will be compiled with javac specified in execution.properties (or system javac).

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BASE_DIR="$(cd "${SCRIPT_DIR}/.." && pwd)"

# Defaults
EXEC_CONFIG_FILE="${BASE_DIR}/execution.properties"
OUTPUT_CLASSES="${BASE_DIR}/output/classes"
VMOPTS_DIR="${BASE_DIR}/vm-options"

print_usage() {
    cat <<EOF
Usage: $0 -s SEQUENCE_JSON -t TEST_FILE [-p VMOPTS_FILE] [-e EXEC_PROPS]

Required:
  -s SEQUENCE_JSON     Path to sequence JSON (contains "sequence" and "gcType")
  -t TEST_FILE         Test .java or .class to run (relative or absolute)

Optional:
  -p VMOPTS_FILE       VM options file (one option per line, comments with #)
  -e EXEC_PROPS        Path to execution.properties (contains javac.path and jvm.paths)

Minimal package for reproducing JVM bugs: only Schedule agent jar (Schedule/*-agent.jar),
the test file, the sequence JSON, optional vmopts, and execution.properties are required.
EOF
}

require_cmd() {
    command -v "$1" >/dev/null 2>&1 || { echo "Required command not found: $1"; exit 1; }
}

get_exec_property() {
    local key="$1"
    local default="$2"
    if [ -f "$EXEC_CONFIG_FILE" ]; then
        local value
        value=$(awk -F'=' -v search="$key" '
            /^[[:space:]]*#/ { next }
            NF < 2 { next }
            {
                k=$1
                sub(/^[[:space:]]+/, "", k)
                sub(/[[:space:]]+$/, "", k)
                if (k == search) {
                    line = substr($0, index($0, "=") + 1)
                    sub(/^[[:space:]]+/, "", line)
                    gsub(/\r/, "", line)
                    print line
                }
            }' "$EXEC_CONFIG_FILE" | tail -n 1)
        if [ -n "$value" ]; then
            echo "$value"
            return
        fi
    fi
    echo "$default"
}

# Parse args
SEQ_FILE=""
TEST_INPUT=""
VMOPTS_FILE=""

while getopts "s:t:p:e:h" opt; do
    case "$opt" in
        s) SEQ_FILE="$OPTARG" ;;
        t) TEST_INPUT="$OPTARG" ;;
        p) VMOPTS_FILE="$OPTARG" ;;
        e) EXEC_CONFIG_FILE="$OPTARG" ;;
        h|*) print_usage; exit 0 ;;
    esac
done

if [ -z "$SEQ_FILE" ] || [ -z "$TEST_INPUT" ]; then
    echo "Error: sequence and test file are required."
    print_usage
    exit 1
fi

# Prefer python3 for JSON handling, fallback to jq if python3 unavailable
PARSER=""
if command -v python3 >/dev/null 2>&1; then
    PARSER="python3"
elif command -v jq >/dev/null 2>&1; then
    PARSER="jq"
else
    echo "Error: python3 or jq is required for JSON parsing. Please install one of them on the target machine."
    exit 1
fi

# Resolve files
resolve_path() {
    local raw="$1"
    if [[ "$raw" == /* ]]; then
        echo "$raw"
    else
        echo "${BASE_DIR}/${raw#./}"
    fi
}

SEQ_FILE="$(resolve_path "$SEQ_FILE")"
TEST_INPUT="$(resolve_path "$TEST_INPUT")"
if [ -n "$VMOPTS_FILE" ]; then
    VMOPTS_FILE="$(resolve_path "$VMOPTS_FILE")"
fi

if [ ! -f "$SEQ_FILE" ]; then
    echo "Sequence file not found: $SEQ_FILE"
    exit 1
fi

# Validate JSON and extract necessary fields (use selected parser)
if [ "$PARSER" = "python3" ]; then
    SEQ_INFO=$(python3 - <<PY
import json,sys
f=open("$SEQ_FILE", "r")
try:
    d=json.load(f)
except Exception as e:
    print("JSON_ERROR:"+str(e))
    sys.exit(2)

seq = d.get("sequence", [])
if not isinstance(seq, list) or len(seq)==0:
    print("SEQ_EMPTY")
    sys.exit(3)

gc = d.get("gcType", "")
tf = d.get("fullyQualifiedClassName", "")
print(json.dumps({"len":len(seq),"gc":gc,"fqcn":tf}))
PY
)
    if echo "$SEQ_INFO" | grep -q '^JSON_ERROR:'; then
        echo "Invalid JSON: ${SEQ_INFO#JSON_ERROR:}"
        exit 1
    fi
    if [ "$SEQ_INFO" = "SEQ_EMPTY" ]; then
        echo "Sequence is empty"
        exit 1
    fi

    SEQ_LEN=$(echo "$SEQ_INFO" | python3 -c "import sys, json; print(json.load(sys.stdin)['len'])")
    SEQ_GC_TYPE=$(echo "$SEQ_INFO" | python3 -c "import sys, json; print(json.load(sys.stdin)['gc'])")
    SEQ_FQ_CLASS_JSON=$(echo "$SEQ_INFO" | python3 -c "import sys, json; print(json.load(sys.stdin)['fqcn'])")

    echo "Sequence validated (length: $SEQ_LEN), gcType: ${SEQ_GC_TYPE:-(none)}"
else
    # jq path
    if ! jq -e . >/dev/null 2>&1 <"$SEQ_FILE"; then
        echo "Invalid JSON: failed to parse with jq"
        exit 1
    fi
    SEQ_LEN=$(jq '.sequence | length' "$SEQ_FILE" 2>/dev/null)
    if [ -z "$SEQ_LEN" ] || [ "$SEQ_LEN" -eq 0 ]; then
        echo "Sequence is empty"
        exit 1
    fi
    SEQ_GC_TYPE=$(jq -r '.gcType // ""' "$SEQ_FILE")
    SEQ_FQ_CLASS_JSON=$(jq -r '.fullyQualifiedClassName // ""' "$SEQ_FILE")
    echo "Sequence validated (length: $SEQ_LEN), gcType: ${SEQ_GC_TYPE:-(none)} (parsed with jq)"
fi

# Find agent jar (expect Schedule/*-agent.jar in project)
SCHED_AGENT_JAR=""
for f in "${BASE_DIR}/"*"-agent.jar"; do
    [ -e "$f" ] || continue
    SCHED_AGENT_JAR="$f"
    break
done

if [ -z "$SCHED_AGENT_JAR" ]; then
    echo "Error: Schedule agent jar not found in ${BASE_DIR}/Schedule/target/ (*-agent.jar)."
    echo "Please build Schedule and place the agent jar in Schedule/target/"
    exit 1
fi

echo "Using agent: $SCHED_AGENT_JAR"

# Determine java and javac from execution.properties (or fallback to system)
JAVAC_CMD=$(get_exec_property "javac.path" "")
JVM_PATHS=$(get_exec_property "jvm.paths" "")
JAVA_CMD=""
if [ -n "$JVM_PATHS" ]; then
    # take first entry (semicolon separated or single)
    JAVA_CMD=$(echo "$JVM_PATHS" | awk -F';' '{print $1}')
fi
JAVAC_CMD=${JAVAC_CMD:-javac}
JAVA_CMD=${JAVA_CMD:-java}

echo "Using java: $JAVA_CMD"
echo "Using javac: $JAVAC_CMD"

# Prepare output/classes dir
mkdir -p "$OUTPUT_CLASSES"

# Compile if needed
INPUT_MODE=""
if [[ "$TEST_INPUT" == *.java ]]; then
    INPUT_MODE="java"
elif [[ "$TEST_INPUT" == *.class ]]; then
    INPUT_MODE="class"
else
    echo "Unsupported test file type: $TEST_INPUT"
    exit 1
fi

if [ "$INPUT_MODE" = "java" ]; then
    echo "Compiling $TEST_INPUT ..."
    # Build javac classpath from module target jars (Schedule, Generation, Execution)
    JAVAC_CP=""

    # Prefer jars placed directly in project root (BASE_DIR/*.jar)
    for j in "${BASE_DIR}"/*.jar; do
        [ -e "$j" ] || continue
        if [ -z "$JAVAC_CP" ]; then
            JAVAC_CP="$j"
        else
            JAVAC_CP="$JAVAC_CP:$j"
        fi
    done

    # Also include module target jars if present (backwards-compatible)
    for mod in Schedule Generation Execution; do
        for j in "${BASE_DIR}/${mod}/target/"*.jar; do
            [ -e "$j" ] || continue
            if [ -z "$JAVAC_CP" ]; then
                JAVAC_CP="$j"
            else
                JAVAC_CP="$JAVAC_CP:$j"
            fi
        done
    done

    # If any jars found, pass -cp to javac so dependencies are available at compile time
    if [ -n "$JAVAC_CP" ]; then
        echo "Using javac classpath: $JAVAC_CP"
        "$JAVAC_CMD" -encoding UTF-8 -cp "$JAVAC_CP" -d "$OUTPUT_CLASSES" "$TEST_INPUT"
    else
        "$JAVAC_CMD" -encoding UTF-8 -d "$OUTPUT_CLASSES" "$TEST_INPUT"
    fi
    echo "Compilation finished."
    # derive fully qualified class name if missing from JSON
    if [ -z "$SEQ_FQ_CLASS_JSON" ] || [ "$SEQ_FQ_CLASS_JSON" = "None" ]; then
        # try to get simple name from file and assume default package com.gcscheduling.generated
        base=$(basename "$TEST_INPUT" .java)
        FQ_CLASS="com.gcscheduling.generated.${base}"
    else
        FQ_CLASS="$SEQ_FQ_CLASS_JSON"
    fi
    CLASS_CP="$OUTPUT_CLASSES"
else
    # class file; determine classpath root
    CLASS_FILE="$TEST_INPUT"
    # attempt to infer FQCN from path relative to classes root
    # assume CLASS_FILE is under some classes root; use its containing dir as classpath root
    CLASS_DIR=$(dirname "$CLASS_FILE")
    CLASS_SIMPLE=$(basename "$CLASS_FILE" .class)
    FQ_CLASS=${SEQ_FQ_CLASS_JSON:-$CLASS_SIMPLE}
    CLASS_CP="$CLASS_DIR"
fi

# Build final VM options array
JAVA_ARGS=()

# GC flag from JSON or require it
if [ -z "$SEQ_GC_TYPE" ]; then
    echo "Warning: gcType missing in sequence JSON; JVM GC flags will not be set."
else
    case "$SEQ_GC_TYPE" in
        "G1"|"G1GC") JAVA_ARGS+=("-XX:+UseG1GC") ;;
        "PARALLEL"|"ParallelGC") JAVA_ARGS+=("-XX:+UseParallelGC") ;;
        "SERIAL"|"SerialGC") JAVA_ARGS+=("-XX:+UseSerialGC") ;;
        "ZGC"|"Z") JAVA_ARGS+=("-XX:+UseZGC") ;;
        "CMS"|"CONCURRENTMARKSWEEP"|"CMSGC") JAVA_ARGS+=("-XX:+UseConcMarkSweepGC") ;;
        "GENCON") JAVA_ARGS+=("-Xgcpolicy:gencon") ;;
        "BALANCED") JAVA_ARGS+=("-Xgcpolicy:balanced") ;;
        "OPTAVGPAUSE") JAVA_ARGS+=("-Xgcpolicy:optavgpause") ;;
        "OPTTHRUPUT") JAVA_ARGS+=("-Xgcpolicy:optthruput") ;;
        "METRONOME") JAVA_ARGS+=("-Xgcpolicy:metronome") ;;
        *) echo "Note: unknown gcType '$SEQ_GC_TYPE' - not adding GC flag." ;;
    esac
fi

# memory defaults can be provided in execution.properties
MAX_MEMORY_MB=$(get_exec_property "max.memory.mb" "1024")
if [[ "$MAX_MEMORY_MB" =~ ^[0-9]+$ ]]; then
    JAVA_ARGS+=("-Xmx${MAX_MEMORY_MB}m" "-Xms${MAX_MEMORY_MB}m")
fi

# vmopts file lines (filter out GC flags - we prefer gc from JSON)
if [ -n "$VMOPTS_FILE" ] && [ -f "$VMOPTS_FILE" ]; then
    mapfile -t VM_TUNING_OPTS < <(grep -v '^[[:space:]]*#' "$VMOPTS_FILE" | sed '/^[[:space:]]*$/d')
    FILTERED=()
    for opt in "${VM_TUNING_OPTS[@]}"; do
        if [[ "$opt" == -XX:+Use*GC || "$opt" == -Xgcpolicy:* ]]; then
            continue
        fi
        FILTERED+=("$opt")
    done
    if [ ${#FILTERED[@]} -gt 0 ]; then
        JAVA_ARGS+=("${FILTERED[@]}")
    fi
fi

# JVM system properties for sequence metadata
JAVA_ARGS+=(
    "-Dfile.encoding=UTF-8"
    "-Dgcscheduler.sequence.session.label=${FQ_CLASS##*.}"
    "-Dgcscheduler.sequence.testFileName=${TEST_INPUT}"
    "-Dgcscheduler.sequence.fullyQualifiedClassName=${FQ_CLASS}"
    "-Dgcscheduler.sequence.gc.type=${SEQ_GC_TYPE}"
)

# Agent arg
AGENT_ARGS="mode=replay;file=${SEQ_FILE};loop=false"
JAVA_CMD_FINAL=("$JAVA_CMD" "-javaagent:${SCHED_AGENT_JAR}=${AGENT_ARGS}" "-cp" "${CLASS_CP}" "${FQ_CLASS}")

# Append other JVM args before -javaagent? We appended after agent in array; ensure order: agent, JVM opts, -cp, main class
# Rebuild final command respecting order: $JAVA_CMD [JAVA_ARGS...] -javaagent:... -cp CLASS_CP FQ_CLASS
CMD=()
CMD+=("$JAVA_CMD")
CMD+=("${JAVA_ARGS[@]}")
CMD+=("-javaagent:${SCHED_AGENT_JAR}=${AGENT_ARGS}")
CMD+=("-cp" "${CLASS_CP}")
CMD+=("${FQ_CLASS}")

echo "Running JVM with command (summary):"
echo "  java: ${JAVA_CMD}"
echo "  classpath: ${CLASS_CP}"
echo "  main: ${FQ_CLASS}"
echo "  agent: ${SCHED_AGENT_JAR}"

# Execute
"${CMD[@]}"

exit $?

