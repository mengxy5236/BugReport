package com.gcscheduling.generated;

import com.concurrency.agent.WorkerMetadata;
import java.util.concurrent.*;
import java.util.*;
import java.lang.ref.*;
import org.example.codegen.model.GCObj;
public class ConcurrentTest_20260110_014123_560 {
    private static volatile Map<Object, Object> map0 = new HashMap();
    private static volatile GCObj gcObj0 = new GCObj(885853);
    private static volatile Set<Object> set0 = new HashSet();
    private static volatile int[] arr0 = new int[5861];
    private static volatile int[] arr1 = new int[26837];
    private static volatile GCObj gcObj1 = new GCObj(5439413);
    private static volatile GCObj gcObj2 = new GCObj(6844913);
    private static volatile Map<Object, Object> map1 = new HashMap();
    private static volatile Object[] arr2 = new Object[43];
    private static volatile Object[] arr3 = new Object[211];
    private static volatile Set<Object> set1 = new TreeSet();
    private static volatile Object[] arr4 = new Object[11440];
    private static volatile PhantomReference<GCObj> objVar0 = new PhantomReference(gcObj0, new ReferenceQueue());
    private static volatile SoftReference<Object> objVar1 = new SoftReference(objVar0);
    private static volatile SoftReference<Object> objVar2 = new SoftReference(objVar1);
    private static volatile int marRoundCounter = 0;
    private static volatile int mdrRoundCounter = 0;
    private static volatile int mmrRoundCounter = 0;
    private static volatile int sparRoundCounter = 0;
    private static volatile long TRAPCOUNT = 0L;
    public static void main(String[] args) throws ExecutionException, InterruptedException {
        try {
            Class.forName("com.gcscheduling.generated.ConcurrentTest_20260110_014123_560$MARWorker");
            Class.forName("com.gcscheduling.generated.ConcurrentTest_20260110_014123_560$MDRWorker");
            Class.forName("com.gcscheduling.generated.ConcurrentTest_20260110_014123_560$MMRWorker");
            Class.forName("com.gcscheduling.generated.ConcurrentTest_20260110_014123_560$SPARWorker");
        }
        catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        ExecutorService executorPool = Executors.newFixedThreadPool(4);

        Future<?> f1 = executorPool.submit(new MARWorker());
        Future<?> f2 = executorPool.submit(new MDRWorker());
        Future<?> f3 = executorPool.submit(new MMRWorker());
        Future<?> f4 = executorPool.submit(new SPARWorker());
        try {
            f1.get(10, TimeUnit.SECONDS);
            f2.get(10, TimeUnit.SECONDS);
            f3.get(10, TimeUnit.SECONDS);
            f4.get(10, TimeUnit.SECONDS);
        }
        catch (Exception e) {
            System.out.println("任务执行超时或异常: " + e.getMessage());
            f1.cancel(true);
            f2.cancel(true);
            f3.cancel(true);
            f4.cancel(true);
        }
        
        executorPool.shutdown();
        System.exit(0);
    }

    @WorkerMetadata(threadId = 0)
    static class MARWorker implements Runnable {
        static volatile List<Object> allocatedObjects = new ArrayList();
        static volatile Set<Object> largeObjectSet = new HashSet();
        static volatile Map<Object, Object> objectCache = new HashMap();
        static volatile List<List<Object> > nestedCollections = new ArrayList();
        static volatile GCObj objVar3 = new GCObj(2730517);
        static volatile List<Object> objVar4 = new LinkedList();
        static volatile GCObj objVar5 = new GCObj(2077478);
        static volatile GCObj objVar6 = new GCObj(4461539);
        static volatile int[] objVar7 = new int[245];
        static volatile GCObj objVar8 = new GCObj(1662703);
        @Override
        public void run() {
            int switchVar = 0;
            int whileCounter = 0;
            int doWhileCounter = 0;
            boolean shouldThrowException = false;
            while (marRoundCounter<29) {
                ++marRoundCounter;
                int currentRound = marRoundCounter;
                System.out.println("MAR Round 1");
                for (int i = 0;  i<3; i++) {
                    allocatedObjects.add(new GCObj(102874));
                }
                switchVar = 1;
                switch (switchVar) {
                    case 0:
                    arr0 = new int[724];
                    break;
                    case 1:
                    allocatedObjects.add(new GCObj(1449375));
                    break;
                    case 2:
                    objVar0 = new PhantomReference(gcObj2, new ReferenceQueue());
                    break;
                    default :
                    objVar7 = new int[4973];
                }
                allocatedObjects.add(new GCObj(5439487));
                allocatedObjects.add(new GCObj(6844921));
                map0 = new HashMap();
                objVar7 = new int[352];
                map0 = new HashMap();
                System.gc();
                System.out.println("MAR Round 2");
                whileCounter = 0;
                while (whileCounter < 3) {
                    allocatedObjects.add(new GCObj(174419));
                    whileCounter++;
                }
                shouldThrowException = false;
                try {
                    if (shouldThrowException) {
                        OutOfMemoryError thrownException = new OutOfMemoryError("Simulated OOM during allocation");
                        throw thrownException;
                    }
                    allocatedObjects.add(new GCObj(179716));
                }
                catch (Exception e) {
                    TRAPCOUNT++;
                    System.out.println("Exception caught during allocation");
                }
                allocatedObjects.add(new GCObj(144133));
                allocatedObjects.add(new GCObj(8220752));
                map1 = new HashMap();
                map0 = new HashMap();
                System.out.println("MAR Round 3");
                whileCounter = 0;
                while (whileCounter < 3) {
                    allocatedObjects.add(new GCObj(176512));
                    whileCounter++;
                }
                whileCounter = 0;
                while (whileCounter < 3) {
                    whileCounter++;
                }
                switchVar = 0;
                switch (switchVar) {
                    case 0:
                    allocatedObjects.add(new GCObj(6203075));
                    break;
                    case 1:
                    objVar4 = new LinkedList();
                    break;
                    case 2:
                    allocatedObjects.add(new GCObj(780917));
                    break;
                    default :
                    objVar1 = new SoftReference(gcObj0);
                }
                switchVar = 1;
                switch (switchVar) {
                    case 0:
                    objVar4 = new LinkedList();
                    break;
                    case 1:
                    break;
                    case 2:
                    arr0 = new int[974];
                    break;
                    default :
                    allocatedObjects.add(new GCObj(96124));
                }
                System.out.println("MAR Round 4");
                doWhileCounter = 0;
                do {
                    objVar7 = new int[31];
                    doWhileCounter++;
                }
                while (doWhileCounter < 2);
                switchVar = 0;
                switch (switchVar) {
                    case 0:
                    objVar2 = new SoftReference(gcObj0);
                    break;
                    case 1:
                    allocatedObjects.add(new GCObj(1763231));
                    break;
                    case 2:
                    allocatedObjects.add(new GCObj(707963));
                    break;
                    default :
                    set0 = new HashSet();
                }
                switchVar = 2;
                switch (switchVar) {
                    case 0:
                    set1 = new TreeSet();
                    break;
                    case 1:
                    objVar4 = new LinkedList();
                    break;
                    case 2:
                    objVar7 = new int[6726];
                    break;
                    default :
                    objVar4 = new LinkedList();
                }
                whileCounter = 0;
                while (whileCounter < 4) {
                    objVar0 = new PhantomReference(gcObj2, new ReferenceQueue());
                    whileCounter++;
                }
                System.out.println("MAR Round 5");
                if (TRAPCOUNT % 2  == 0) {
                    objVar7 = new int[759];
                }
                else {
                    objVar2 = new SoftReference(objVar8);
                }
                doWhileCounter = 0;
                do {
                    allocatedObjects.add(new GCObj(1061229));
                    doWhileCounter++;
                }
                while (doWhileCounter < 2);
                whileCounter = 0;
                while (whileCounter < 4) {
                    objVar0 = new PhantomReference(objVar5, new ReferenceQueue());
                    whileCounter++;
                }
                doWhileCounter = 0;
                do {
                    arr1 = new int[2164];
                    doWhileCounter++;
                }
                while (doWhileCounter < 2);
                allocatedObjects.add(new GCObj(198057));
                System.out.println("MAR Round 6");
                whileCounter = 0;
                while (whileCounter < 2) {
                    objVar2 = new SoftReference(gcObj2);
                    whileCounter++;
                }
                shouldThrowException = false;
                try {
                    if (shouldThrowException) {
                        OutOfMemoryError thrownException = new OutOfMemoryError("Simulated OOM during allocation");
                        throw thrownException;
                    }
                    map1 = new HashMap();
                }
                catch (Exception e) {
                    TRAPCOUNT++;
                    System.out.println("Exception caught during allocation");
                }
                map1 = new HashMap();
                allocatedObjects.add(new GCObj(1878321));
                allocatedObjects.add(new GCObj(220825));
                arr0 = new int[2422];
                System.out.println("MAR Round 7");
                switchVar = 1;
                switch (switchVar) {
                    case 0:
                    allocatedObjects.add(new GCObj(2015437));
                    break;
                    case 1:
                    allocatedObjects.add(new GCObj(1409137));
                    break;
                    case 2:
                    map1 = new HashMap();
                    break;
                    default :
                    objVar0 = new PhantomReference(objVar6, new ReferenceQueue());
                }
                if (TRAPCOUNT % 2  == 0) {
                    allocatedObjects.add(new GCObj(7022406));
                }
                else {
                    objVar0 = new PhantomReference(gcObj1, new ReferenceQueue());
                }
                if (TRAPCOUNT % 2  == 0) {
                    arr0 = new int[8716];
                }
                shouldThrowException = false;
                try {
                    if (shouldThrowException) {
                        OutOfMemoryError thrownException = new OutOfMemoryError("Simulated OOM during allocation");
                        throw thrownException;
                    }
                    allocatedObjects.add(new GCObj(213839));
                }
                catch (Exception e) {
                    TRAPCOUNT++;
                    System.out.println("Exception caught during allocation");
                }
                doWhileCounter = 0;
                do {
                    doWhileCounter++;
                }
                while (doWhileCounter < 3);
                System.gc();
                System.out.println("MAR Round 8");
                doWhileCounter = 0;
                do {
                    allocatedObjects.add(new GCObj(1073497));
                    doWhileCounter++;
                }
                while (doWhileCounter < 2);
                whileCounter = 0;
                while (whileCounter < 4) {
                    allocatedObjects.add(new GCObj(8127583));
                    whileCounter++;
                }
                for (int i = 0;  i < 3; i++) {
                    allocatedObjects.add(new GCObj(7074884));
                }
                for (int i = 0;  i < 2; i++) {
                    allocatedObjects.add(new GCObj(145743));
                }
                shouldThrowException = false;
                try {
                    if (shouldThrowException) {
                        OutOfMemoryError thrownException = new OutOfMemoryError("Simulated OOM during allocation");
                        throw thrownException;
                    }
                    allocatedObjects.add(new GCObj(4803807));
                }
                catch (Exception e) {
                    TRAPCOUNT++;
                    System.out.println("Exception caught during allocation");
                }
                System.gc();
                System.out.println("MAR Round 9");
                map1 = new HashMap();
                allocatedObjects.add(new GCObj(254343));
                allocatedObjects.add(new GCObj(143253));
                allocatedObjects.add(new GCObj(218685));
                doWhileCounter = 0;
                do {
                    doWhileCounter++;
                }
                while (doWhileCounter < 4);
                if (TRAPCOUNT % 2  == 0) {
                    allocatedObjects.add(new GCObj(96261));
                }
                else {
                }
                doWhileCounter = 0;
                System.out.println("MAR Round 10");
                switchVar = 2;
                switch (switchVar) {
                    case 0:
                    objVar4 = new LinkedList();
                    break;
                    case 1:
                    allocatedObjects.add(new GCObj(232520));
                    break;
                    case 2:
                    arr1 = new int[326];
                    break;
                    default :
                    objVar7 = new int[2614];
                }
                for (int i = 0;  i < 4; i++) {
                    allocatedObjects.add(new GCObj(7672755));
                }
                for (int i = 0;  i < 4; i++) {
                }
                for (int i = 0;  i < 3; i++) {
                    allocatedObjects.add(new GCObj(4677726));
                }
                shouldThrowException = false;
                try {
                    if (shouldThrowException) {
                        OutOfMemoryError thrownException = new OutOfMemoryError("Simulated OOM during allocation");
                        throw thrownException;
                    }
                    map1 = new HashMap();
                }
                catch (Exception e) {
                    TRAPCOUNT++;
                    System.out.println("Exception caught during allocation");
                }
                whileCounter = 0;
                System.out.println("MAR Round 11");
                if (TRAPCOUNT % 2  == 0) {
                    objVar4 = new LinkedList();
                }
                else {
                    allocatedObjects.add(new GCObj(5059511));
                }
                whileCounter = 0;
                while (whileCounter < 4) {
                    whileCounter++;
                }
                doWhileCounter = 0;
                do {
                    allocatedObjects.add(new GCObj(110610));
                    doWhileCounter++;
                }
                while (doWhileCounter < 4);
                doWhileCounter = 0;
                do {
                    arr0 = new int[7903];
                    doWhileCounter++;
                }
                while (doWhileCounter < 3);
                whileCounter = 0;
                System.out.println("MAR Round 12");
                for (int i = 0;  i < 3; i++) {
                    set1 = new TreeSet();
                }
                for (int i = 0;  i < 4; i++) {
                    allocatedObjects.add(new GCObj(207576));
                }
                switchVar = 0;
                switch (switchVar) {
                    case 0:
                    objVar7 = new int[409];
                    break;
                    case 1:
                    objVar2 = new SoftReference(objVar5);
                    break;
                    case 2:
                    arr1 = new int[820];
                    break;
                    default :
                    arr0 = new int[4815];
                }
                arr1 = new int[585];
                allocatedObjects.add(new GCObj(118151));
                allocatedObjects.add(new GCObj(84435));
                allocatedObjects.add(new GCObj(7170358));
                System.out.println("MAR Round 13");
                doWhileCounter = 0;
                do {
                    allocatedObjects.add(new GCObj(741768));
                    doWhileCounter++;
                }
                while (doWhileCounter < 4);
                doWhileCounter = 0;
                do {
                    allocatedObjects.add(new GCObj(4865666));
                    doWhileCounter++;
                }
                while (doWhileCounter < 2);
                for (int i = 0;  i < 3; i++) {
                    objVar2 = new SoftReference(gcObj1);
                }
                doWhileCounter = 0;
                do {
                    allocatedObjects.add(new GCObj(185190));
                    doWhileCounter++;
                }
                while (doWhileCounter < 2);
                whileCounter = 0;
                System.out.println("MAR Round 14");
                allocatedObjects.add(new GCObj(1356659));
                allocatedObjects.add(new GCObj(220987));
                arr0 = new int[1722];
                allocatedObjects.add(new GCObj(120697));
                map0 = new HashMap();
                map1 = new HashMap();
                allocatedObjects.add(new GCObj(1392896));
                allocatedObjects.add(new GCObj(1654688));
                System.out.println("MAR Round 15");
                if (TRAPCOUNT % 2  == 0) {
                    objVar7 = new int[6979];
                }
                else {
                    allocatedObjects.add(new GCObj(5375515));
                }
                whileCounter = 0;
                while (whileCounter < 3) {
                    allocatedObjects.add(new GCObj(1708506));
                    whileCounter++;
                }
                if (TRAPCOUNT % 2  == 0) {
                    allocatedObjects.add(new GCObj(664787));
                }
                else {
                }
                shouldThrowException = false;
                try {
                    if (shouldThrowException) {
                        OutOfMemoryError thrownException = new OutOfMemoryError("Simulated OOM during allocation");
                        throw thrownException;
                    }
                    objVar7 = new int[319];
                }
                catch (Exception e) {
                    TRAPCOUNT++;
                    System.out.println("Exception caught during allocation");
                }
                whileCounter = 0;
                while (whileCounter < 3) {
                    map1 = new HashMap();
                    whileCounter++;
                }
                System.gc();
                System.out.println("MAR Round 16");
                arr0 = new int[227];
                allocatedObjects.add(new GCObj(79558));
                allocatedObjects.add(new GCObj(2212341));
                map1 = new HashMap();
                arr0 = new int[324];
                map0 = new HashMap();
                allocatedObjects.add(new GCObj(3990748));
                map1 = new HashMap();
                System.out.println("MAR Round 17");
                doWhileCounter = 0;
                do {
                    map0 = new HashMap();
                    doWhileCounter++;
                }
                while (doWhileCounter < 4);
                switchVar = 0;
                switch (switchVar) {
                    case 0:
                    objVar0 = new PhantomReference(objVar5, new ReferenceQueue());
                    break;
                    case 1:
                    arr1 = new int[659];
                    break;
                    case 2:
                    allocatedObjects.add(new GCObj(89522));
                    break;
                    default :
                    objVar0 = new PhantomReference(gcObj1, new ReferenceQueue());
                }
                shouldThrowException = false;
                try {
                    if (shouldThrowException) {
                        OutOfMemoryError thrownException = new OutOfMemoryError("Simulated OOM during allocation");
                        throw thrownException;
                    }
                    map0 = new HashMap();
                }
                catch (Exception e) {
                    TRAPCOUNT++;
                    System.out.println("Exception caught during allocation");
                }
                switchVar = 0;
                switch (switchVar) {
                    case 0:
                    break;
                    case 1:
                    arr0 = new int[746];
                    break;
                    case 2:
                    allocatedObjects.add(new GCObj(4519303));
                    break;
                    default :
                    allocatedObjects.add(new GCObj(3592229));
                }
                System.gc();
                System.out.println("MAR Round 18");
                allocatedObjects.add(new GCObj(4264755));
                allocatedObjects.add(new GCObj(2035820));
                allocatedObjects.add(new GCObj(6684341));
                allocatedObjects.add(new GCObj(250843));
                allocatedObjects.add(new GCObj(735378));
                allocatedObjects.add(new GCObj(5306285));
                arr1 = new int[354];
                allocatedObjects.add(new GCObj(170460));
                System.out.println("MAR Round 19");
                if (TRAPCOUNT % 2  == 0) {
                    objVar0 = new PhantomReference(gcObj1, new ReferenceQueue());
                }
                else {
                    allocatedObjects.add(new GCObj(3010028));
                }
                for (int i = 0;  i < 4; i++) {
                    objVar4 = new LinkedList();
                }
                doWhileCounter = 0;
                do {
                    allocatedObjects.add(new GCObj(188238));
                    doWhileCounter++;
                }
                while (doWhileCounter < 2);
                for (int i = 0;  i < 4; i++) {
                    allocatedObjects.add(new GCObj(197557));
                }
                shouldThrowException = false;
                try {
                    if (shouldThrowException) {
                        OutOfMemoryError thrownException = new OutOfMemoryError("Simulated OOM during allocation");
                        throw thrownException;
                    }
                    objVar2 = new SoftReference(gcObj2);
                }
                catch (Exception e) {
                    TRAPCOUNT++;
                    System.out.println("Exception caught during allocation");
                }
                shouldThrowException = false;
                System.out.println("MAR Round 20");
                shouldThrowException = false;
                try {
                    if (shouldThrowException) {
                        OutOfMemoryError thrownException = new OutOfMemoryError("Simulated OOM during allocation");
                        throw thrownException;
                    }
                    map0 = new HashMap();
                }
                catch (Exception e) {
                    TRAPCOUNT++;
                    System.out.println("Exception caught during allocation");
                }
                shouldThrowException = false;
                try {
                    if (shouldThrowException) {
                        OutOfMemoryError thrownException = new OutOfMemoryError("Simulated OOM during allocation");
                        throw thrownException;
                    }
                    objVar1 = new SoftReference(objVar3);
                }
                catch (Exception e) {
                    TRAPCOUNT++;
                    System.out.println("Exception caught during allocation");
                }
                switchVar = 1;
                switch (switchVar) {
                    case 0:
                    arr1 = new int[1912];
                    break;
                    case 1:
                    allocatedObjects.add(new GCObj(176282));
                    break;
                    case 2:
                    set1 = new TreeSet();
                    break;
                    default :
                    allocatedObjects.add(new GCObj(1978677));
                }
                doWhileCounter = 0;
                do {
                    doWhileCounter++;
                }
                while (doWhileCounter < 4);
                System.out.println("MAR Round 21");
                if (TRAPCOUNT % 2  == 0) {
                    allocatedObjects.add(new GCObj(4261551));
                }
                for (int i = 0;  i < 3; i++) {
                    set0 = new HashSet();
                }
                if (TRAPCOUNT % 2  == 0) {
                }
                else {
                    objVar2 = new SoftReference(objVar3);
                }
                switchVar = 2;
                switch (switchVar) {
                    case 0:
                    break;
                    case 1:
                    map0 = new HashMap();
                    break;
                    case 2:
                    set0 = new HashSet();
                    break;
                    default :
                    objVar0 = new PhantomReference(objVar6, new ReferenceQueue());
                }
                shouldThrowException = false;
                try {
                    if (shouldThrowException) {
                        OutOfMemoryError thrownException = new OutOfMemoryError("Simulated OOM during allocation");
                        throw thrownException;
                    }
                    objVar2 = new SoftReference(gcObj1);
                }
                catch (Exception e) {
                    TRAPCOUNT++;
                    System.out.println("Exception caught during allocation");
                }
                if (TRAPCOUNT % 2  == 0) {
                    arr1 = new int[822];
                }
                else {
                    objVar0 = new PhantomReference(gcObj0, new ReferenceQueue());
                }
                System.out.println("MAR Round 22");
                doWhileCounter = 0;
                do {
                    allocatedObjects.add(new GCObj(125592));
                    doWhileCounter++;
                }
                while (doWhileCounter < 4);
                doWhileCounter = 0;
                do {
                    allocatedObjects.add(new GCObj(7253492));
                    doWhileCounter++;
                }
                while (doWhileCounter < 4);
                doWhileCounter = 0;
                do {
                    allocatedObjects.add(new GCObj(7495594));
                    doWhileCounter++;
                }
                while (doWhileCounter < 2);
                allocatedObjects.add(new GCObj(2651127));
                objVar0 = new PhantomReference(gcObj0, new ReferenceQueue());
                System.out.println("MAR Round 23");
                switchVar = 1;
                switch (switchVar) {
                    case 0:
                    objVar0 = new PhantomReference(objVar8, new ReferenceQueue());
                    break;
                    case 1:
                    objVar1 = new SoftReference(objVar8);
                    break;
                    case 2:
                    set1 = new TreeSet();
                    break;
                    default :
                    allocatedObjects.add(new GCObj(1593642));
                }
                whileCounter = 0;
                while (whileCounter<2) {
                    whileCounter++;
                }
                shouldThrowException = false;
                try {
                    if (shouldThrowException) {
                        OutOfMemoryError thrownException = new OutOfMemoryError("Simulated OOM during allocation");
                        throw thrownException;
                    }
                    arr0 = new int[965];
                }
                catch (Exception e) {
                    TRAPCOUNT++;
                    System.out.println("Exception caught during allocation");
                }
                for (int i = 0;  i<2; i++) {
                    set0 = new HashSet();
                }
                for (int i = 0;  i < 2; i++) {
                    allocatedObjects.add(new GCObj(107834));
                }
                System.out.println("MAR Round 24");
                doWhileCounter = 0;
                do {
                    allocatedObjects.add(new GCObj(215322));
                    doWhileCounter++;
                }
                while (doWhileCounter < 3);
                if (TRAPCOUNT % 2  == 0) {
                    allocatedObjects.add(new GCObj(982131));
                }
                else {
                    allocatedObjects.add(new GCObj(5808098));
                }
                whileCounter = 0;
                while (whileCounter < 2) {
                    whileCounter++;
                }
                shouldThrowException = false;
                try {
                    if (shouldThrowException) {
                        OutOfMemoryError thrownException = new OutOfMemoryError("Simulated OOM during allocation");
                        throw thrownException;
                    }
                    allocatedObjects.add(new GCObj(3666635));
                }
                catch (Exception e) {
                    TRAPCOUNT++;
                    System.out.println("Exception caught during allocation");
                }
                for (int i = 0;  i < 4; i++) {
                    allocatedObjects.add(new GCObj(107140));
                }
                System.gc();
                System.out.println("MAR Round 25");
                for (int i = 0;  i < 3; i++) {
                    allocatedObjects.add(new GCObj(7255011));
                }
                for (int i = 0;  i < 2; i++) {
                    allocatedObjects.add(new GCObj(83372));
                }
                shouldThrowException = false;
                try {
                    if (shouldThrowException) {
                        OutOfMemoryError thrownException = new OutOfMemoryError("Simulated OOM during allocation");
                        throw thrownException;
                    }
                    allocatedObjects.add(new GCObj(1792198));
                }
                catch (Exception e) {
                    TRAPCOUNT++;
                    System.out.println("Exception caught during allocation");
                }
                allocatedObjects.add(new GCObj(184715));
                arr0 = new int[8249];
                allocatedObjects.add(new GCObj(5548977));
                allocatedObjects.add(new GCObj(80878));
                System.out.println("MAR Round 26");
                arr0 = new int[151];
                allocatedObjects.add(new GCObj(224168));
                allocatedObjects.add(new GCObj(104773));
                allocatedObjects.add(new GCObj(7921196));
                allocatedObjects.add(new GCObj(2190665));
                map1 = new HashMap();
                map0 = new HashMap();
                allocatedObjects.add(new GCObj(672631));
                System.out.println("MAR Round 27");
                for (int i = 0;  i < 4; i++) {
                    allocatedObjects.add(new GCObj(212303));
                }
                whileCounter = 0;
                while (whileCounter < 4) {
                    map0 = new HashMap();
                    whileCounter++;
                }
                if (TRAPCOUNT % 2  == 0) {
                }
                else {
                    allocatedObjects.add(new GCObj(2554793));
                }
                for (int i = 0;  i < 3; i++) {
                    allocatedObjects.add(new GCObj(1942710));
                }
                whileCounter = 0;
                while (whileCounter < 4) {
                    objVar7 = new int[8765];
                    whileCounter++;
                }
                allocatedObjects.add(new GCObj(2082700));
                System.out.println("MAR Round 28");
                arr1 = new int[463];
                map1 = new HashMap();
                allocatedObjects.add(new GCObj(2022470));
                allocatedObjects.add(new GCObj(617103));
                allocatedObjects.add(new GCObj(8240986));
                map1 = new HashMap();
                allocatedObjects.add(new GCObj(116286));
                objVar7 = new int[504];
                System.out.println("MAR Round 29");
                whileCounter = 0;
                while (whileCounter < 4) {
                    whileCounter++;
                }
                arr0 = new int[219];
                arr0 = new int[7594];
                map1 = new HashMap();
                allocatedObjects.add(new GCObj(4261898));
                allocatedObjects.add(new GCObj(138880));
                arr1 = new int[375];
                System.gc();
            }
        }
    }

    @WorkerMetadata(threadId = 1)
    static class MDRWorker implements Runnable {
        private static final Random random = new Random(0L);
        @Override
        public void run() {
            int switchVar = 0;
            int whileCounter = 0;
            int doWhileCounter = 0;
            boolean shouldThrowException = false;
            while (mdrRoundCounter < 11) {
                ++mdrRoundCounter;
                int currentRound = mdrRoundCounter;
                System.out.println("MDR Round 1");
                MARWorker.objVar5 = null;
                MARWorker.objVar6 = null;
                MARWorker.objVar7 = null;
                System.gc();
                System.out.println("MDR Round 2");
                switchVar = 0;
                switch (switchVar) {
                    case 0:
                    if (gcObj0 != null) {
                        gcObj0.releaseAllReferences();
                        gcObj0 = null;
                    }
                    break;
                    case 1:
                    if (MARWorker.objVar3 != null) {
                        MARWorker.objVar3.releaseAllReferences();
                        MARWorker.objVar3 = null;
                    }
                    break;
                    default :
                }
                for (int i = 0;  i < 1; i++) {
                    arr2 = null;
                }
                System.gc();
                System.out.println("MDR Round 3");
                System.gc();
                System.out.println("System.gc()called - requesting garbage collection");
                System.gc();
                System.gc();
                System.out.println("MDR Round 4");
                System.gc();
                System.out.println("System.gc()called - requesting garbage collection");
                System.runFinalization();
                System.gc();
                System.out.println("MDR Round 5");
                System.gc();
                System.out.println("System.gc()called - requesting garbage collection");
                System.gc();
                System.gc();
                System.out.println("MDR Round 6");
                System.gc();
                System.out.println("System.gc()called - requesting garbage collection");
                System.runFinalization();
                System.gc();
                System.out.println("MDR Round 7");
                System.gc();
                System.out.println("System.gc()called - requesting garbage collection");
                System.gc();
                System.out.println("MDR Round 8");
                System.gc();
                System.out.println("System.gc()called - requesting garbage collection");
                System.runFinalization();
                System.gc();
                System.out.println("MDR Round 9");
                System.gc();
                System.out.println("System.gc()called - requesting garbage collection");
                System.gc();
                System.gc();
                System.out.println("MDR Round 10");
                System.gc();
                System.out.println("System.gc()called - requesting garbage collection");
                System.gc();
                System.out.println("MDR Round 11");
                System.gc();
                System.out.println("System.gc()called - requesting garbage collection");
                System.gc();
                System.gc();
            }
        }
    }

    @WorkerMetadata(threadId = 2)
    static class MMRWorker implements Runnable {
        private static final Random random = new Random(0L);
        @Override
        public void run() {
            int safeIndex = 0;
            int switchVar = 0;
            int whileCounter = 0;
            int doWhileCounter = 0;
            boolean shouldThrowException = false;
            while (mmrRoundCounter < 8) {
                ++mmrRoundCounter;
                int currentRound = mmrRoundCounter;
                System.out.println("MMR Round 1");
                for (int i = 0;  i < 2; i++) {
                    gcObj2 = new GCObj(37909);
                }
                for (int i = 0;  i < 2; i++) {
                    set1 = new TreeSet();
                }
                map1 = new HashMap();
                if (arr0 != null && arr0.length> 0) {
                    safeIndex = arr0.length > 0 ? arr0.length / 2 : 0;
                    arr0[safeIndex] = 795;
                }
                if (set1 != null && set1.size() > 0) {
                    set1.clear();
                }
                System.out.println("MMR Round 2");
                if (random.nextBoolean()) {
                    MARWorker.objVar4 = new LinkedList();
                }
                for (int i = 0;  i<2; i++) {
                    gcObj2.processGCObj();
                }
                gcObj1.processGCObj();
                MARWorker.objVar8.processGCObj();
                if (arr0 != null && arr0.length> 0) {
                    arr0[0] = 509;
                }
                System.out.println("MMR Round 3");
                if (arr4 != null && arr4.length > 0) {
                    arr4[0] = "element_18";
                }
                if (arr3 != null && arr3.length > 0) {
                    arr3[0] = "element_52";
                }
                map1.put("collection_element_89", new Object());
                if (arr1 != null && arr1.length > 0) {
                    safeIndex = arr1.length > 0 ? arr1.length / 2 : 0;
                    arr1[safeIndex] = 937;
                }
                map0.put("collection_element_84", new Object());
                System.out.println("MMR Round 4");
                for (int i = 0;  i<2; i++) {
                    set0.clear();
                }
                if (arr0 != null && arr0.length> 0) {
                    arr0[0] = 866;
                }
                set1.add(new Object());
                if (random.nextBoolean()) {
                    gcObj1.modifyArrayElement(1, 955);
                }
                MARWorker.objVar8.processGCObj();
                System.out.println("MMR Round 5");
                objVar0 = null;
                gcObj2.replaceStrongReference(null);
                MARWorker.objVar8 = new GCObj(12089);
                gcObj1 = new GCObj(21154);
                gcObj2 = new GCObj(22350);
                System.out.println("MMR Round 6");
                map0.put("collection_element_86", new Object());
                MARWorker.objVar8 = new GCObj(45481);
                if (arr1 != null && arr1.length > 0) {
                    safeIndex = arr1.length > 0 ? arr1.length / 2 : 0;
                    arr1[safeIndex] = 757;
                }
                if (random.nextBoolean()) {
                    if (MARWorker.objVar4 != null && MARWorker.objVar4.size() > 0) {
                        MARWorker.objVar4.remove(0);
                    }
                }
                MARWorker.objVar8 = new GCObj(13202);
                System.out.println("MMR Round 7");
                MARWorker.objVar4 = new LinkedList();
                MARWorker.objVar8 = new GCObj(4138);
                MARWorker.objVar4 = new LinkedList();
                MARWorker.objVar4.clear();
                gcObj2.replaceStrongReference(null);
                System.out.println("MMR Round 8");
                if (arr0 != null && arr0.length > 0) {
                    safeIndex = arr0.length > 0 ? arr0.length / 2 : 0;
                    arr0[safeIndex] = 228;
                }
                MARWorker.objVar8.modifyArrayElement(2, 106);
                if (arr4 != null && arr4.length > 0) {
                    safeIndex = arr4.length > 0 ? arr4.length / 2 : 0;
                    arr4[safeIndex] = "element_78";
                }
                arr0 = new int[5861];
                gcObj1 = new GCObj(43756);
            }
        }
    }

    @WorkerMetadata(threadId = 3)
    static class SPARWorker implements Runnable {
        private static final Random random = new Random(0L);
        @Override
        public void run() {
            int switchVar = 0;
            int whileCounter = 0;
            int doWhileCounter = 0;
            boolean shouldThrowException = false;
            while (sparRoundCounter<8) {
                ++sparRoundCounter;
                int currentRound = sparRoundCounter;
                System.out.println("SPAR Round 1");
                shouldThrowException = false;
                try {
                    if (shouldThrowException) {
                        IllegalStateException thrownException = new IllegalStateException("GCFuzz generated IllegalStateException for testing");
                        throw thrownException;
                    }
                    arr0[0] = 78;
                }
                catch (Exception e) {
                    TRAPCOUNT++;
                    System.out.println("Exception caught");
                }
                finally {
                    System.gc();
                }
                whileCounter = 0;
                while (whileCounter<8) {
                    int temp100 = 28;
                    whileCounter++;
                }
                if (arr1 != null && arr1.length> 0) {
                    int temp332 = 47;
                }
                else {
                    int temp841 = 70;
                }
                shouldThrowException = true;
                System.out.println("SPAR Round 2");
                for (int i = 0;  i < 9; i++) {
                    if (MARWorker.objVar8 != null) {
                        MARWorker.objVar8.processGCObj();
                    }
                }
                if (TRAPCOUNT % 2  == 0) {
                    int temp754 = 6;
                }
                for (int i = 0;  i < 6; i++) {
                    int temp999 = 24;
                }
                shouldThrowException = false;
                try {
                    if (shouldThrowException) {
                        IllegalArgumentException thrownException = new IllegalArgumentException("GCFuzz generated IllegalArgumentException for testing");
                        throw thrownException;
                    }
                    arr0[0] = 55;
                }
                catch (Exception e) {
                    TRAPCOUNT++;
                    System.out.println("Exception caught");
                }
                finally {
                    System.gc();
                }
                if (objVar0 != null) {
                    int temp33 = 6;
                }
                System.out.println("SPAR Round 3");
                doWhileCounter = 0;
                do {
                    int temp918 = 22;
                    doWhileCounter++;
                }
                while (doWhileCounter < 5);
                switchVar = 2;
                switch (switchVar) {
                    case 0:
                    if (gcObj1 != null) {
                        gcObj1.processGCObj();
                    }
                    break;
                    case 1:
                    int temp623 = 19;
                    break;
                    case 2:
                    int temp517 = 61;
                    break;
                    default :
                    if (gcObj2 != null) {
                        gcObj2.processGCObj();
                    }
                }
                for (int i = 0;  i < 5; i++) {
                    int temp480 = 99;
                }
                if (TRAPCOUNT % 2  == 0) {
                    int temp119 = 55;
                }
                else {
                    if (gcObj2 != null) {
                        gcObj2.processGCObj();
                    }
                }
                System.out.println("SPAR Round 4");
                whileCounter = 0;
                while (whileCounter < 10) {
                    int temp335 = 42;
                    whileCounter++;
                }
                doWhileCounter = 0;
                do {
                    int temp21 = 13;
                    doWhileCounter++;
                }
                while (doWhileCounter < 5);
                if (arr3 != null) {
                    if (MARWorker.objVar8 != null) {
                        MARWorker.objVar8.processGCObj();
                    }
                }
                else {
                    if (gcObj2 != null) {
                        gcObj2.processGCObj();
                    }
                }
                shouldThrowException = true;
                System.out.println("SPAR Round 5");
                doWhileCounter = 0;
                do {
                    if (MARWorker.objVar8 != null) {
                        MARWorker.objVar8.processGCObj();
                    }
                    doWhileCounter++;
                }
                while (doWhileCounter < 4);
                for (int i = 0;  i < 8; i++) {
                    int temp195 = 78;
                }
                if (objVar2 != null) {
                    int temp884 = 62;
                }
                whileCounter = 0;
                while (whileCounter < 10) {
                    int temp170 = 92;
                    whileCounter++;
                }
                System.out.println("SPAR Round 6");
                for (int i = 0;  i < 13; i++) {
                    if (gcObj2 != null) {
                        gcObj2.processGCObj();
                    }
                }
                whileCounter = 0;
                while (whileCounter < 10) {
                    int temp77 = 18;
                    whileCounter++;
                }
                for (int i = 0;  i < 6; i++) {
                    int temp531 = 5;
                }
                switchVar = 3;
                switch (switchVar) {
                    case 0:
                    int temp323 = 81;
                    break;
                    case 1:
                    if (gcObj1 != null) {
                        gcObj1.processGCObj();
                    }
                    break;
                    case 2:
                    int temp574 = 74;
                    break;
                    default :
                    int temp771 = 46;
                }
                System.out.println("SPAR Round 7");
                whileCounter = 0;
                while (whileCounter < 8) {
                    int temp769 = 28;
                    whileCounter++;
                }
                shouldThrowException = true;
                try {
                    if (shouldThrowException) {
                        UnsupportedOperationException thrownException = new UnsupportedOperationException("GCFuzz generated UnsupportedOperationException for testing");
                        throw thrownException;
                    }
                    arr0[0] = 52;
                }
                catch (Exception e) {
                    TRAPCOUNT++;
                    System.out.println("Exception caught");
                }
                finally {
                    System.gc();
                }
                for (int i = 0;  i < 7; i++) {
                    int temp59 = 85;
                }
                doWhileCounter = 0;
                System.out.println("SPAR Round 8");
                if (TRAPCOUNT % 2  == 0) {
                    int temp391 = 42;
                }
                else {
                    if (gcObj2 != null) {
                        gcObj2.processGCObj();
                    }
                }
                shouldThrowException = false;
                try {
                    if (shouldThrowException) {
                        RuntimeException thrownException = new RuntimeException("GCFuzz generated RuntimeException for testing");
                        throw thrownException;
                    }
                    arr0[0] = 17;
                }
                catch (Exception e) {
                    TRAPCOUNT++;
                    System.out.println("Exception caught");
                }
                shouldThrowException = false;
                try {
                    if (shouldThrowException) {
                        IllegalArgumentException thrownException = new IllegalArgumentException("GCFuzz generated IllegalArgumentException for testing");
                        throw thrownException;
                    }
                    arr0[0] = 99;
                }
                catch (Exception e) {
                    TRAPCOUNT++;
                    System.out.println("Exception caught");
                }
                whileCounter = 0;
            }
        }
    }
}
