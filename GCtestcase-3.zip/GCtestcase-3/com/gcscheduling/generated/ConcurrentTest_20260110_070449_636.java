package com.gcscheduling.generated;

import com.concurrency.agent.WorkerMetadata;
import java.util.concurrent.*;
import java.util.*;
import java.lang.ref.*;
import org.example.codegen.model.GCObj;
public class ConcurrentTest_20260110_070449_636 {
    private static volatile GCObj gcObj0 = new GCObj(780110);
    private static volatile Object[] arr0 = new Object[73672];
    private static volatile GCObj gcObj1 = new GCObj(872179);
    private static volatile GCObj gcObj2 = new GCObj(5233629);
    private static volatile Object[] arr1 = new Object[784];
    private static volatile GCObj gcObj3 = new GCObj(98049);
    private static volatile Map<Object, Object> objVar0 = new Hashtable();
    private static volatile Set<Object> set0 = new TreeSet();
    private static volatile Set<Object> set1 = new HashSet();
    private static volatile List<Object> list0 = new ArrayList();
    private static volatile Set<Object> set2 = new HashSet();
    private static volatile Set<Object> objVar1 = new LinkedHashSet();
    private static volatile List<Object> list1 = new Vector();
    private static volatile Map<Object, Object> map0 = new HashMap();
    private static volatile List<Object> list2 = new Vector();
    private static volatile GCObj gcObj4 = new GCObj(1212227);
    private static volatile List<Object> list3 = new ArrayList();
    private static volatile GCObj gcObj5 = new GCObj(3354792);
    private static volatile Map<Object, Object> objVar2 = new Hashtable();
    private static volatile GCObj gcObj6 = new GCObj(68422);
    private static volatile GCObj gcObj7 = new GCObj(87919);
    private static volatile Map<Object, Object> objVar3 = new Hashtable();
    private static volatile int[] arr2 = new int[48852];
    private static volatile GCObj gcObj8 = new GCObj(113874);
    private static volatile GCObj gcObj9 = new GCObj(1699588);
    private static volatile WeakReference<GCObj> objVar4 = new WeakReference(gcObj0);
    private static volatile WeakReference<GCObj> objVar5 = new WeakReference(gcObj0);
    private static volatile SoftReference<GCObj> objVar6 = new SoftReference(gcObj0);
    private static volatile PhantomReference<GCObj> objVar7 = new PhantomReference(gcObj0, new ReferenceQueue());
    private static volatile int marRoundCounter = 0;
    private static volatile int mdrRoundCounter = 0;
    private static volatile int mmrRoundCounter = 0;
    private static volatile int sparRoundCounter = 0;
    private static volatile long TRAPCOUNT = 0L;
    public static void main(String[] args) throws ExecutionException, InterruptedException {
        try {
            Class.forName("com.gcscheduling.generated.ConcurrentTest_20260110_070449_636$MARWorker");
            Class.forName("com.gcscheduling.generated.ConcurrentTest_20260110_070449_636$MDRWorker");
            Class.forName("com.gcscheduling.generated.ConcurrentTest_20260110_070449_636$MMRWorker");
            Class.forName("com.gcscheduling.generated.ConcurrentTest_20260110_070449_636$SPARWorker");
        }
        catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        ExecutorService executorPool = Executors.newFixedThreadPool(4);

        Future<?> f1 = executorPool.submit(new MARWorker());
        Future<?> f2 = executorPool.submit(new MDRWorker());
        Future<?> f3 = executorPool.submit(new MMRWorker());
        Future<?> f4 = executorPool.submit(new SPARWorker());
        try {
            f1.get(10, TimeUnit.SECONDS);
            f2.get(10, TimeUnit.SECONDS);
            f3.get(10, TimeUnit.SECONDS);
            f4.get(10, TimeUnit.SECONDS);
        }
        catch (Exception e) {
            System.out.println("任务执行超时或异常: " + e.getMessage());
            f1.cancel(true);
            f2.cancel(true);
            f3.cancel(true);
            f4.cancel(true);
        }
        
        executorPool.shutdown();
        System.exit(0);
    }

    @WorkerMetadata(threadId = 0)
    static class MARWorker implements Runnable {
        static volatile List<Object> allocatedObjects = new ArrayList();
        static volatile Set<Object> largeObjectSet = new HashSet();
        static volatile Map<Object, Object> objectCache = new HashMap();
        static volatile List<List<Object> > nestedCollections = new ArrayList();
        static volatile GCObj objVar8 = new GCObj(2023357);
        static volatile Map<Object, Object> objVar9 = new Hashtable();
        static volatile GCObj objVar10 = new GCObj(2056201);
        static volatile Map<Object, Object> objVar11 = new LinkedHashMap();
        static volatile List<Object> objVar12 = new Vector();
        @Override
        public void run() {
            int switchVar = 0;
            int whileCounter = 0;
            int doWhileCounter = 0;
            boolean shouldThrowException = false;
            while (marRoundCounter<25) {
                ++marRoundCounter;
                int currentRound = marRoundCounter;
                System.out.println("MAR Round 1");
                allocatedObjects.add(new GCObj(780763));
                arr2 = new int[563];
                allocatedObjects.add(new GCObj(179900));
                arr2 = new int[3356];
                arr2 = new int[9511];
                allocatedObjects.add(new GCObj(5826623));
                arr2 = new int[402];
                arr2 = new int[5877];
                System.out.println("MAR Round 2");
                doWhileCounter = 0;
                do {
                    allocatedObjects.add(new GCObj(2999014));
                    doWhileCounter++;
                }
                while (doWhileCounter<3);
                for (int i = 0;  i < 3; i++) {
                    allocatedObjects.add(new GCObj(223569));
                }
                allocatedObjects.add(new GCObj(3990843));
                arr2 = new int[6605];
                list0 = new ArrayList();
                allocatedObjects.add(new GCObj(6989804));
                arr2 = new int[502];
                System.out.println("MAR Round 3");
                switchVar = 2;
                switch (switchVar) {
                    case 0:
                    allocatedObjects.add(new GCObj(5512859));
                    break;
                    case 1:
                    set1 = new HashSet();
                    break;
                    case 2:
                    list3 = new ArrayList();
                    break;
                    default :
                    list2 = new Vector();
                }
                switchVar = 1;
                switch (switchVar) {
                    case 0:
                    set0 = new TreeSet();
                    break;
                    case 1:
                    list0 = new ArrayList();
                    break;
                    case 2:
                    break;
                    default :
                    allocatedObjects.add(new GCObj(1348876));
                }
                for (int i = 0;  i < 2; i++) {
                    arr2 = new int[771];
                }
                allocatedObjects.add(new GCObj(2225225));
                arr2 = new int[734];
                set1 = new HashSet();
                System.out.println("MAR Round 4");
                doWhileCounter = 0;
                do {
                    allocatedObjects.add(new GCObj(5771895));
                    doWhileCounter++;
                }
                while (doWhileCounter < 4);
                doWhileCounter = 0;
                do {
                    doWhileCounter++;
                }
                while (doWhileCounter < 4);
                doWhileCounter = 0;
                do {
                    objVar4 = new WeakReference(gcObj6);
                    doWhileCounter++;
                }
                while (doWhileCounter < 3);
                switchVar = 0;
                switch (switchVar) {
                    case 0:
                    allocatedObjects.add(new GCObj(6518457));
                    break;
                    case 1:
                    allocatedObjects.add(new GCObj(5916821));
                    break;
                    case 2:
                    arr2 = new int[577];
                    break;
                    default :
                    allocatedObjects.add(new GCObj(185273));
                }
                System.out.println("MAR Round 5");
                doWhileCounter = 0;
                do {
                    doWhileCounter++;
                }
                while (doWhileCounter < 3);
                for (int i = 0;  i < 4; i++) {
                    objVar6 = new SoftReference(gcObj8);
                }
                list0 = new ArrayList();
                allocatedObjects.add(new GCObj(86787));
                map0 = new HashMap();
                allocatedObjects.add(new GCObj(177108));
                allocatedObjects.add(new GCObj(2578541));
                System.gc();
                System.out.println("MAR Round 6");
                shouldThrowException = false;
                try {
                    if (shouldThrowException) {
                        OutOfMemoryError thrownException = new OutOfMemoryError("Simulated OOM during allocation");
                        throw thrownException;
                    }
                    allocatedObjects.add(new GCObj(5079859));
                }
                catch (Exception e) {
                    TRAPCOUNT++;
                    System.out.println("Exception caught during allocation");
                }
                doWhileCounter = 0;
                do {
                    list1 = new Vector();
                    doWhileCounter++;
                }
                while (doWhileCounter < 2);
                for (int i = 0;  i < 4; i++) {
                    set2 = new HashSet();
                }
                whileCounter = 0;
                while (whileCounter < 3) {
                    whileCounter++;
                }
                for (int i = 0;  i < 2; i++) {
                    allocatedObjects.add(new GCObj(2299566));
                }
                System.out.println("MAR Round 7");
                for (int i = 0;  i < 2; i++) {
                }
                switchVar = 1;
                switch (switchVar) {
                    case 0:
                    break;
                    case 1:
                    arr2 = new int[930];
                    break;
                    case 2:
                    break;
                    default :
                    allocatedObjects.add(new GCObj(181639));
                }
                for (int i = 0;  i < 4; i++) {
                    arr2 = new int[360];
                }
                allocatedObjects.add(new GCObj(1045740));
                arr2 = new int[4859];
                allocatedObjects.add(new GCObj(4398627));
                allocatedObjects.add(new GCObj(927938));
                System.gc();
                System.out.println("MAR Round 8");
                arr2 = new int[414];
                map0 = new HashMap();
                list0 = new ArrayList();
                allocatedObjects.add(new GCObj(963421));
                map0 = new HashMap();
                map0 = new HashMap();
                allocatedObjects.add(new GCObj(107844));
                list0 = new ArrayList();
                System.out.println("MAR Round 9");
                shouldThrowException = false;
                try {
                    if (shouldThrowException) {
                        OutOfMemoryError thrownException = new OutOfMemoryError("Simulated OOM during allocation");
                        throw thrownException;
                    }
                    allocatedObjects.add(new GCObj(225504));
                }
                catch (Exception e) {
                    TRAPCOUNT++;
                    System.out.println("Exception caught during allocation");
                }
                for (int i = 0;  i < 4; i++) {
                }
                doWhileCounter = 0;
                do {
                    list2 = new Vector();
                    doWhileCounter++;
                }
                while (doWhileCounter < 4);
                map0 = new HashMap();
                allocatedObjects.add(new GCObj(1221575));
                set1 = new HashSet();
                System.out.println("MAR Round 10");
                doWhileCounter = 0;
                do {
                    allocatedObjects.add(new GCObj(1324897));
                    doWhileCounter++;
                }
                while (doWhileCounter < 2);
                if (TRAPCOUNT % 2  == 0) {
                    allocatedObjects.add(new GCObj(6451650));
                }
                else {
                    allocatedObjects.add(new GCObj(3459668));
                }
                allocatedObjects.add(new GCObj(131653));
                allocatedObjects.add(new GCObj(120872));
                map0 = new HashMap();
                objVar4 = new WeakReference(gcObj6);
                doWhileCounter = 0;
                System.gc();
                System.out.println("MAR Round 11");
                doWhileCounter = 0;
                do {
                    objVar4 = new WeakReference(gcObj4);
                    doWhileCounter++;
                }
                while (doWhileCounter < 3);
                doWhileCounter = 0;
                do {
                    set0 = new TreeSet();
                    doWhileCounter++;
                }
                while (doWhileCounter < 2);
                allocatedObjects.add(new GCObj(8126010));
                objVar6 = new SoftReference(objVar8);
                set2 = new HashSet();
                switchVar = 0;
                System.out.println("MAR Round 12");
                switchVar = 0;
                switch (switchVar) {
                    case 0:
                    break;
                    case 1:
                    allocatedObjects.add(new GCObj(196585));
                    break;
                    case 2:
                    set2 = new HashSet();
                    break;
                    default :
                    list1 = new Vector();
                }
                allocatedObjects.add(new GCObj(107643));
                allocatedObjects.add(new GCObj(708278));
                allocatedObjects.add(new GCObj(113037));
                allocatedObjects.add(new GCObj(1524377));
                arr2 = new int[8068];
                arr2 = new int[917];
                System.gc();
                System.out.println("MAR Round 13");
                if (TRAPCOUNT % 2  == 0) {
                    allocatedObjects.add(new GCObj(956533));
                }
                else {
                    list2 = new Vector();
                }
                for (int i = 0;  i < 4; i++) {
                    objVar6 = new SoftReference(gcObj7);
                }
                shouldThrowException = false;
                try {
                    if (shouldThrowException) {
                        OutOfMemoryError thrownException = new OutOfMemoryError("Simulated OOM during allocation");
                        throw thrownException;
                    }
                }
                catch (Exception e) {
                    TRAPCOUNT++;
                    System.out.println("Exception caught during allocation");
                }
                objVar7 = new PhantomReference(gcObj7, new ReferenceQueue());
                set0 = new TreeSet();
                if (TRAPCOUNT % 2  == 0) {
                    allocatedObjects.add(new GCObj(6622764));
                }
                else {
                }
                doWhileCounter = 0;
                System.out.println("MAR Round 14");
                switchVar = 1;
                switch (switchVar) {
                    case 0:
                    allocatedObjects.add(new GCObj(1821171));
                    break;
                    case 1:
                    objVar4 = new WeakReference(gcObj6);
                    break;
                    case 2:
                    list3 = new ArrayList();
                    break;
                    default :
                    allocatedObjects.add(new GCObj(2014641));
                }
                allocatedObjects.add(new GCObj(4632468));
                allocatedObjects.add(new GCObj(128253));
                arr2 = new int[5464];
                arr2 = new int[279];
                allocatedObjects.add(new GCObj(211005));
                allocatedObjects.add(new GCObj(8356355));
                System.gc();
                System.out.println("MAR Round 15");
                shouldThrowException = false;
                try {
                    if (shouldThrowException) {
                        OutOfMemoryError thrownException = new OutOfMemoryError("Simulated OOM during allocation");
                        throw thrownException;
                    }
                    list2 = new Vector();
                }
                catch (Exception e) {
                    TRAPCOUNT++;
                    System.out.println("Exception caught during allocation");
                }
                if (TRAPCOUNT % 2  == 0) {
                    list3 = new ArrayList();
                }
                else {
                    allocatedObjects.add(new GCObj(106746));
                }
                for (int i = 0;  i < 4; i++) {
                    list0 = new ArrayList();
                }
                allocatedObjects.add(new GCObj(211296));
                map0 = new HashMap();
                allocatedObjects.add(new GCObj(1887481));
                arr2 = new int[566];
                System.gc();
                System.out.println("MAR Round 16");
                shouldThrowException = false;
                try {
                    if (shouldThrowException) {
                        OutOfMemoryError thrownException = new OutOfMemoryError("Simulated OOM during allocation");
                        throw thrownException;
                    }
                    list1 = new Vector();
                }
                catch (Exception e) {
                    TRAPCOUNT++;
                    System.out.println("Exception caught during allocation");
                }
                doWhileCounter = 0;
                do {
                    allocatedObjects.add(new GCObj(2458793));
                    doWhileCounter++;
                }
                while (doWhileCounter < 4);
                shouldThrowException = false;
                try {
                    if (shouldThrowException) {
                        OutOfMemoryError thrownException = new OutOfMemoryError("Simulated OOM during allocation");
                        throw thrownException;
                    }
                    objVar5 = new WeakReference(gcObj5);
                }
                catch (Exception e) {
                    TRAPCOUNT++;
                    System.out.println("Exception caught during allocation");
                }
                switchVar = 2;
                switch (switchVar) {
                    case 0:
                    allocatedObjects.add(new GCObj(4346623));
                    break;
                    case 1:
                    objVar5 = new WeakReference(gcObj3);
                    break;
                    case 2:
                    list1 = new Vector();
                    break;
                    default :
                    allocatedObjects.add(new GCObj(7031303));
                }
                System.out.println("MAR Round 17");
                if (TRAPCOUNT % 2  == 0) {
                    allocatedObjects.add(new GCObj(1914591));
                }
                if (TRAPCOUNT % 2  == 0) {
                    list0 = new ArrayList();
                }
                else {
                    set1 = new HashSet();
                }
                doWhileCounter = 0;
                do {
                    doWhileCounter++;
                }
                while (doWhileCounter < 2);
                doWhileCounter = 0;
                do {
                    allocatedObjects.add(new GCObj(5895496));
                    doWhileCounter++;
                }
                while (doWhileCounter < 3);
                for (int i = 0;  i < 4; i++) {
                    allocatedObjects.add(new GCObj(147170));
                }
                doWhileCounter = 0;
                System.out.println("MAR Round 18");
                switchVar = 1;
                switch (switchVar) {
                    case 0:
                    list3 = new ArrayList();
                    break;
                    case 1:
                    allocatedObjects.add(new GCObj(237129));
                    break;
                    case 2:
                    allocatedObjects.add(new GCObj(1796802));
                    break;
                    default :
                    allocatedObjects.add(new GCObj(238200));
                }
                switchVar = 0;
                switch (switchVar) {
                    case 0:
                    arr2 = new int[4622];
                    break;
                    case 1:
                    set0 = new TreeSet();
                    break;
                    case 2:
                    objVar7 = new PhantomReference(objVar8, new ReferenceQueue());
                    break;
                    default :
                    objVar6 = new SoftReference(objVar10);
                }
                doWhileCounter = 0;
                do {
                    objVar5 = new WeakReference(gcObj5);
                    doWhileCounter++;
                }
                while (doWhileCounter < 4);
                shouldThrowException = false;
                try {
                    if (shouldThrowException) {
                        OutOfMemoryError thrownException = new OutOfMemoryError("Simulated OOM during allocation");
                        throw thrownException;
                    }
                    list1 = new Vector();
                }
                catch (Exception e) {
                    TRAPCOUNT++;
                    System.out.println("Exception caught during allocation");
                }
                System.out.println("MAR Round 19");
                whileCounter = 0;
                while (whileCounter < 3) {
                    map0 = new HashMap();
                    whileCounter++;
                }
                shouldThrowException = false;
                try {
                    if (shouldThrowException) {
                        OutOfMemoryError thrownException = new OutOfMemoryError("Simulated OOM during allocation");
                        throw thrownException;
                    }
                }
                catch (Exception e) {
                    TRAPCOUNT++;
                    System.out.println("Exception caught during allocation");
                }
                allocatedObjects.add(new GCObj(674955));
                allocatedObjects.add(new GCObj(225466));
                arr2 = new int[9149];
                allocatedObjects.add(new GCObj(5719894));
                System.out.println("MAR Round 20");
                allocatedObjects.add(new GCObj(7727542));
                objVar7 = new PhantomReference(gcObj0, new ReferenceQueue());
                objVar6 = new SoftReference(gcObj9);
                set0 = new TreeSet();
                whileCounter = 0;
                while (whileCounter < 4) {
                    whileCounter++;
                }
                doWhileCounter = 0;
                do {
                    list3 = new ArrayList();
                    doWhileCounter++;
                }
                while (doWhileCounter < 3);
                System.out.println("MAR Round 21");
                doWhileCounter = 0;
                do {
                    objVar5 = new WeakReference(gcObj0);
                    doWhileCounter++;
                }
                while (doWhileCounter < 4);
                allocatedObjects.add(new GCObj(128317));
                set0 = new TreeSet();
                for (int i = 0;  i < 4; i++) {
                    allocatedObjects.add(new GCObj(1487716));
                }
                doWhileCounter = 0;
                do {
                    list0 = new ArrayList();
                    doWhileCounter++;
                }
                while (doWhileCounter < 4);
                doWhileCounter = 0;
                System.out.println("MAR Round 22");
                if (TRAPCOUNT % 2  == 0) {
                    list1 = new Vector();
                }
                doWhileCounter = 0;
                do {
                    doWhileCounter++;
                }
                while (doWhileCounter < 4);
                shouldThrowException = false;
                try {
                    if (shouldThrowException) {
                        OutOfMemoryError thrownException = new OutOfMemoryError("Simulated OOM during allocation");
                        throw thrownException;
                    }
                }
                catch (Exception e) {
                    TRAPCOUNT++;
                    System.out.println("Exception caught during allocation");
                }
                if (TRAPCOUNT % 2  == 0) {
                    list3 = new ArrayList();
                }
                else {
                    objVar6 = new SoftReference(gcObj2);
                }
                if (TRAPCOUNT % 2  == 0) {
                    objVar4 = new WeakReference(objVar10);
                }
                else {
                    allocatedObjects.add(new GCObj(1406328));
                }
                switchVar = 1;
                System.out.println("MAR Round 23");
                switchVar = 1;
                switch (switchVar) {
                    case 0:
                    allocatedObjects.add(new GCObj(6161509));
                    break;
                    case 1:
                    break;
                    case 2:
                    allocatedObjects.add(new GCObj(159125));
                    break;
                    default :
                    allocatedObjects.add(new GCObj(151874));
                }
                objVar4 = new WeakReference(gcObj3);
                set0 = new TreeSet();
                allocatedObjects.add(new GCObj(174805));
                objVar6 = new SoftReference(gcObj6);
                allocatedObjects.add(new GCObj(1628221));
                switchVar = 1;
                System.gc();
                System.out.println("MAR Round 24");
                switchVar = 0;
                switch (switchVar) {
                    case 0:
                    map0 = new HashMap();
                    break;
                    case 1:
                    objVar12 = new Vector();
                    break;
                    case 2:
                    set1 = new HashSet();
                    break;
                    default :
                    objVar7 = new PhantomReference(gcObj0, new ReferenceQueue());
                }
                for (int i = 0;  i<4; i++) {
                    map0 = new HashMap();
                }
                if (TRAPCOUNT % 2  == 0) {
                    arr2 = new int[83];
                }
                else {
                    allocatedObjects.add(new GCObj(6705597));
                }
                switchVar = 1;
                switch (switchVar) {
                    case 0:
                    allocatedObjects.add(new GCObj(806893));
                    break;
                    case 1:
                    allocatedObjects.add(new GCObj(156798));
                    break;
                    case 2:
                    objVar6 = new SoftReference(gcObj3);
                    break;
                    default :
                    allocatedObjects.add(new GCObj(764408));
                }
                if (TRAPCOUNT % 2  == 0) {
                    allocatedObjects.add(new GCObj(102013));
                }
                if (TRAPCOUNT % 2  == 0) {
                    arr2 = new int[3905];
                }
                else {
                    allocatedObjects.add(new GCObj(2891388));
                }
                System.out.println("MAR Round 25");
                doWhileCounter = 0;
                do {
                    doWhileCounter++;
                }
                while (doWhileCounter<3);
                list1 = new Vector();
                allocatedObjects.add(new GCObj(185156));
                allocatedObjects.add(new GCObj(2851303));
                objVar6 = new SoftReference(gcObj9);
                if (TRAPCOUNT % 2  == 0) {
                    objVar4 = new WeakReference(objVar8);
                }
                shouldThrowException = false;
            }
        }
    }

    @WorkerMetadata(threadId = 1)
    static class MDRWorker implements Runnable {
        private static final Random random = new Random(0L);
        @Override
        public void run() {
            int switchVar = 0;
            int whileCounter = 0;
            int doWhileCounter = 0;
            boolean shouldThrowException = false;
            while (mdrRoundCounter < 9) {
                ++mdrRoundCounter;
                int currentRound = mdrRoundCounter;
                System.out.println("MDR Round 1");
                if (random.nextDouble() < 0.5) {
                    arr0 = null;
                    System.gc();
                    System.out.println("System.gc()called - requesting garbage collection");
                }
                shouldThrowException = false;
                try {
                    if (shouldThrowException) {
                        IllegalStateException thrownException = new IllegalStateException("Error during deallocation");
                        throw thrownException;
                    }
                    set2 = null;
                }
                catch (Exception e) {
                    TRAPCOUNT++;
                    System.out.println("Exception caught during deallocation");
                }
                finally {
                    System.gc();
                    System.out.println("System.gc()called - requesting garbage collection");
                }
                System.gc();
                System.out.println("MDR Round 2");
                whileCounter = 0;
                while (whileCounter < 2) {
                    if (gcObj0 != null) {
                        gcObj0.releaseAllReferences();
                        gcObj0 = null;
                    }
                    whileCounter++;
                }
                for (int i = 0;  i < 2; i++) {
                }
                System.gc();
                System.out.println("MDR Round 3");
                shouldThrowException = false;
                try {
                    if (shouldThrowException) {
                        IllegalStateException thrownException = new IllegalStateException("Error during deallocation");
                        throw thrownException;
                    }
                    arr1 = null;
                }
                catch (Exception e) {
                    TRAPCOUNT++;
                    System.out.println("Exception caught during deallocation");
                }
                finally {
                }
                System.gc();
                System.gc();
                System.out.println("MDR Round 4");
                System.gc();
                System.out.println("System.gc()called - requesting garbage collection");
                System.runFinalization();
                System.gc();
                System.out.println("MDR Round 5");
                System.gc();
                System.out.println("System.gc()called - requesting garbage collection");
                System.gc();
                System.gc();
                System.out.println("MDR Round 6");
                System.gc();
                System.out.println("System.gc()called - requesting garbage collection");
                System.gc();
                System.gc();
                System.out.println("MDR Round 7");
                System.gc();
                System.out.println("System.gc()called - requesting garbage collection");
                System.gc();
                System.out.println("MDR Round 8");
                System.gc();
                System.out.println("System.gc()called - requesting garbage collection");
                System.runFinalization();
                System.gc();
                System.out.println("MDR Round 9");
                System.gc();
            }
        }
    }

    @WorkerMetadata(threadId = 2)
    static class MMRWorker implements Runnable {
        private static final Random random = new Random(0L);
        @Override
        public void run() {
            int safeIndex = 0;
            int switchVar = 0;
            int whileCounter = 0;
            int doWhileCounter = 0;
            boolean shouldThrowException = false;
            while (mmrRoundCounter < 12) {
                ++mmrRoundCounter;
                int currentRound = mmrRoundCounter;
                System.out.println("MMR Round 1");
                gcObj7.processGCObj();
                gcObj6 = new GCObj(17009);
                gcObj3.replaceStrongReference(null);
                for (int i = 0;  i < 2; i++) {
                    list2.add(335);
                }
                gcObj4.processGCObj();
                System.out.println("MMR Round 2");
                if (random.nextBoolean()) {
                    list2.clear();
                }
                list3 = new ArrayList();
                if (list1 != null && list1.size()> 0) {
                    list1.remove(0);
                }
                gcObj7.replaceStrongReference(null);
                MARWorker.objVar8 = new GCObj(51678);
                System.out.println("MMR Round 3");
                gcObj2.processGCObj();
                gcObj9.replaceStrongReference(null);
                list1.add(new Object());
                gcObj8 = new GCObj(56698);
                set1 = new HashSet();
                System.out.println("MMR Round 4");
                MARWorker.objVar10.processGCObj();
                gcObj6.processGCObj();
                list3.add(new Object());
                for (int i = 0;  i<1; i++) {
                    MARWorker.objVar12 = new Vector();
                }
                for (int i = 0;  i<2; i++) {
                    MARWorker.objVar8.modifyArrayElement(1, 839);
                }
                System.out.println("MMR Round 5");
                MARWorker.objVar8.replaceStrongReference(null);
                gcObj6.replaceStrongReference(null);
                map0.put("collection_element_81", new Object());
                gcObj8.replaceStrongReference(null);
                map0.put("collection_element_51", new Object());
                System.out.println("MMR Round 6");
                gcObj4.processGCObj();
                gcObj7.replaceStrongReference(null);
                MARWorker.objVar8.replaceStrongReference(null);
                if (set1 != null && set1.size()> 0) {
                    set1.clear();
                }
                if (list3 != null && list3.size() > 0) {
                    list3.remove(0);
                }
                System.out.println("MMR Round 7");
                list3.add(new Object());
                if (random.nextBoolean()) {
                    gcObj9.modifyArrayElement(0, 952);
                }
                map0 = new HashMap();
                gcObj7 = new GCObj(19618);
                if (random.nextBoolean()) {
                    list2.add(293);
                }
                System.out.println("MMR Round 8");
                gcObj8 = new GCObj(15050);
                if (random.nextBoolean()) {
                    gcObj8 = new GCObj(29325);
                }
                gcObj2 = new GCObj(49908);
                MARWorker.objVar8.replaceStrongReference(null);
                gcObj2.processGCObj();
                System.out.println("MMR Round 9");
                gcObj9.processGCObj();
                set0 = new TreeSet();
                if (random.nextBoolean()) {
                    set0 = new TreeSet();
                }
                gcObj4.replaceStrongReference(null);
                MARWorker.objVar8.processGCObj();
                System.out.println("MMR Round 10");
                map0 = new HashMap();
                for (int i = 0;  i<2; i++) {
                    list0.add(162);
                }
                if (random.nextBoolean()) {
                    arr2 = new int[48852];
                }
                MARWorker.objVar8.modifyArrayElement(5, 491);
                try {
                    gcObj4.processGCObj();
                }
                catch (Exception e) {
                }
                System.out.println("MMR Round 11");
                try {
                    MARWorker.objVar10.replaceStrongReference(null);
                }
                catch (Exception e) {
                }
                gcObj5 = new GCObj(34851);
                gcObj4 = new GCObj(19445);
                for (int i = 0;  i<2; i++) {
                    if (MARWorker.objVar12 != null && MARWorker.objVar12.size()> 0) {
                        MARWorker.objVar12.remove(0);
                    }
                }
                gcObj7.processGCObj();
                System.out.println("MMR Round 12");
                try {
                    set0 = new TreeSet();
                }
                catch (Exception e) {
                }
                map0.clear();
                if (random.nextBoolean()) {
                    list0.add(334);
                }
                gcObj3 = new GCObj(53694);
                gcObj5.replaceStrongReference(null);
            }
        }
    }

    @WorkerMetadata(threadId = 3)
    static class SPARWorker implements Runnable {
        private static final Random random = new Random(0L);
        @Override
        public void run() {
            int switchVar = 0;
            int whileCounter = 0;
            int doWhileCounter = 0;
            boolean shouldThrowException = false;
            while (sparRoundCounter < 13) {
                ++sparRoundCounter;
                int currentRound = sparRoundCounter;
                System.out.println("SPAR Round 1");
                switchVar = 0;
                switch (switchVar) {
                    case 0:
                    int temp36 = 11;
                    break;
                    case 1:
                    if (MARWorker.objVar8 != null) {
                        MARWorker.objVar8.processGCObj();
                    }
                    break;
                    case 2:
                    int temp481 = 98;
                    break;
                    default :
                    int temp176 = 30;
                }
                if (list1 != null) {
                    if (MARWorker.objVar10 != null) {
                        MARWorker.objVar10.processGCObj();
                    }
                }
                shouldThrowException = true;
                try {
                    if (shouldThrowException) {
                        RuntimeException thrownException = new RuntimeException("GCFuzz generated RuntimeException for testing");
                        throw thrownException;
                    }
                    arr2[0] = 0;
                }
                catch (Exception e) {
                    TRAPCOUNT++;
                    System.out.println("Exception caught");
                }
                doWhileCounter = 0;
                System.out.println("SPAR Round 2");
                shouldThrowException = true;
                try {
                    if (shouldThrowException) {
                        RuntimeException thrownException = new RuntimeException("GCFuzz generated RuntimeException for testing");
                        throw thrownException;
                    }
                    arr2[0] = 19;
                }
                catch (Exception e) {
                    TRAPCOUNT++;
                    System.out.println("Exception caught");
                }
                finally {
                    System.gc();
                }
                shouldThrowException = false;
                try {
                    if (shouldThrowException) {
                        NullPointerException thrownException = new NullPointerException("GCFuzz generated NullPointerException for testing");
                        throw thrownException;
                    }
                    arr2[0] = 66;
                }
                catch (Exception e) {
                    TRAPCOUNT++;
                    System.out.println("Exception caught");
                }
                for (int i = 0;  i < 8; i++) {
                    int temp657 = 85;
                }
                whileCounter = 0;
                System.out.println("SPAR Round 3");
                for (int i = 0;  i < 8; i++) {
                    if (gcObj6 != null) {
                        gcObj6.processGCObj();
                    }
                }
                if (TRAPCOUNT % 2  == 0) {
                    int temp103 = 82;
                }
                shouldThrowException = true;
                try {
                    if (shouldThrowException) {
                        IllegalArgumentException thrownException = new IllegalArgumentException("GCFuzz generated IllegalArgumentException for testing");
                        throw thrownException;
                    }
                    arr2[0] = 94;
                }
                catch (Exception e) {
                    TRAPCOUNT++;
                    System.out.println("Exception caught");
                }
                finally {
                    System.gc();
                }
                doWhileCounter = 0;
                do {
                    int temp436 = 30;
                    doWhileCounter++;
                }
                while (doWhileCounter < 6);
                System.out.println("SPAR Round 4");
                if (gcObj2 != null) {
                    if (gcObj9 != null) {
                        gcObj9.processGCObj();
                    }
                }
                else {
                    int temp137 = 42;
                }
                for (int i = 0;  i < 6; i++) {
                    if (MARWorker.objVar8 != null) {
                        MARWorker.objVar8.processGCObj();
                    }
                }
                whileCounter = 0;
                while (whileCounter < 4) {
                    if (gcObj4 != null) {
                        gcObj4.processGCObj();
                    }
                    whileCounter++;
                }
                for (int i = 0;  i < 8; i++) {
                    int temp254 = 75;
                }
                doWhileCounter = 0;
                System.out.println("SPAR Round 5");
                if (TRAPCOUNT % 2  == 0) {
                    int temp779 = 35;
                }
                shouldThrowException = true;
                try {
                    if (shouldThrowException) {
                        NullPointerException thrownException = new NullPointerException("GCFuzz generated NullPointerException for testing");
                        throw thrownException;
                    }
                    arr2[0] = 37;
                }
                catch (Exception e) {
                    TRAPCOUNT++;
                    System.out.println("Exception caught");
                }
                if (MARWorker.objVar10 != null) {
                    int temp158 = 21;
                }
                else {
                    if (gcObj1 != null) {
                        gcObj1.processGCObj();
                    }
                }
                switchVar = 2;
                switch (switchVar) {
                    case 0:
                    int temp880 = 63;
                    break;
                    case 1:
                    if (gcObj7 != null) {
                        gcObj7.processGCObj();
                    }
                    break;
                    case 2:
                    if (gcObj8 != null) {
                        gcObj8.processGCObj();
                    }
                    break;
                    default :
                    int temp199 = 84;
                }
                System.out.println("SPAR Round 6");
                switchVar = 1;
                switch (switchVar) {
                    case 0:
                    break;
                    case 1:
                    if (gcObj3 != null) {
                        gcObj3.processGCObj();
                    }
                    break;
                    case 2:
                    int temp865 = 6;
                    break;
                    default :
                    if (gcObj5 != null) {
                        gcObj5.processGCObj();
                    }
                }
                for (int i = 0;  i < 12; i++) {
                    if (gcObj3 != null) {
                        gcObj3.processGCObj();
                    }
                }
                shouldThrowException = false;
                try {
                    if (shouldThrowException) {
                        NullPointerException thrownException = new NullPointerException("GCFuzz generated NullPointerException for testing");
                        throw thrownException;
                    }
                    arr2[0] = 20;
                }
                catch (Exception e) {
                    TRAPCOUNT++;
                    System.out.println("Exception caught");
                }
                shouldThrowException = true;
                System.out.println("SPAR Round 7");
                if (gcObj6 != null) {
                    if (gcObj4 != null) {
                        gcObj4.processGCObj();
                    }
                }
                else {
                    int temp611 = 16;
                }
                for (int i = 0;  i < 8; i++) {
                    int temp169 = 50;
                }
                for (int i = 0;  i < 7; i++) {
                    int temp869 = 93;
                }
                doWhileCounter = 0;
                do {
                    int temp909 = 62;
                    doWhileCounter++;
                }
                while (doWhileCounter < 5);
                whileCounter = 0;
                System.out.println("SPAR Round 8");
                for (int i = 0;  i < 13; i++) {
                    int temp661 = 66;
                }
                switchVar = 2;
                switch (switchVar) {
                    case 0:
                    if (gcObj1 != null) {
                        gcObj1.processGCObj();
                    }
                    break;
                    case 1:
                    if (gcObj8 != null) {
                        gcObj8.processGCObj();
                    }
                    break;
                    case 2:
                    int temp680 = 17;
                    break;
                    default :
                    int temp582 = 46;
                }
                doWhileCounter = 0;
                do {
                    int temp111 = 99;
                    doWhileCounter++;
                }
                while (doWhileCounter < 5);
                shouldThrowException = false;
                System.out.println("SPAR Round 9");
                if (objVar4 != null) {
                    int temp287 = 48;
                }
                else {
                    if (gcObj3 != null) {
                        gcObj3.processGCObj();
                    }
                }
                for (int i = 0;  i < 8; i++) {
                    int temp989 = 15;
                }
                if (TRAPCOUNT % 2  == 0) {
                    int temp962 = 12;
                }
                else {
                    if (gcObj7 != null) {
                        gcObj7.processGCObj();
                    }
                }
                if (gcObj5 != null) {
                    int temp867 = 59;
                }
                whileCounter = 0;
                while (whileCounter < 10) {
                    if (gcObj7 != null) {
                        gcObj7.processGCObj();
                    }
                    whileCounter++;
                }
                System.out.println("SPAR Round 10");
                doWhileCounter = 0;
                do {
                    int temp929 = 65;
                    doWhileCounter++;
                }
                while (doWhileCounter < 5);
                if (gcObj2 != null) {
                    int temp367 = 60;
                }
                doWhileCounter = 0;
                do {
                    if (gcObj5 != null) {
                        gcObj5.processGCObj();
                    }
                    doWhileCounter++;
                }
                while (doWhileCounter < 5);
                if (list2 != null) {
                    int temp510 = 18;
                }
                System.out.println("SPAR Round 11");
                whileCounter = 0;
                while (whileCounter < 6) {
                    if (gcObj1 != null) {
                        gcObj1.processGCObj();
                    }
                    whileCounter++;
                }
                for (int i = 0;  i < 6; i++) {
                    if (gcObj1 != null) {
                        gcObj1.processGCObj();
                    }
                }
                doWhileCounter = 0;
                do {
                    int temp839 = 27;
                    doWhileCounter++;
                }
                while (doWhileCounter < 2);
                whileCounter = 0;
                System.out.println("SPAR Round 12");
                switchVar = 0;
                switch (switchVar) {
                    case 0:
                    int temp294 = 3;
                    break;
                    case 1:
                    int temp903 = 31;
                    break;
                    case 2:
                    int temp423 = 66;
                    break;
                    default :
                    int temp790 = 54;
                }
                for (int i = 0;  i < 10; i++) {
                    int temp771 = 52;
                }
                for (int i = 0;  i < 14; i++) {
                    int temp699 = 4;
                }
                for (int i = 0;  i < 9; i++) {
                    int temp912 = 44;
                }
                doWhileCounter = 0;
                System.out.println("SPAR Round 13");
                whileCounter = 0;
                while (whileCounter < 7) {
                    int temp708 = 84;
                    whileCounter++;
                }
                switchVar = 0;
                switch (switchVar) {
                    case 0:
                    int temp737 = 18;
                    break;
                    case 1:
                    int temp878 = 7;
                    break;
                    case 2:
                    int temp574 = 16;
                    break;
                    default :
                    int temp424 = 17;
                }
                if (gcObj8 != null) {
                    int temp627 = 19;
                }
                else {
                    if (gcObj9 != null) {
                        gcObj9.processGCObj();
                    }
                }
                switchVar = 1;
            }
        }
    }
}
