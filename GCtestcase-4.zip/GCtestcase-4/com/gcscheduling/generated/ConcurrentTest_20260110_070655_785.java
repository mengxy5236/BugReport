package com.gcscheduling.generated;

import com.concurrency.agent.WorkerMetadata;
import java.util.concurrent.*;
import java.util.*;
import java.lang.ref.*;
import org.example.codegen.model.GCObj;
public class ConcurrentTest_20260110_070655_785 {
    private static volatile GCObj gcObj0 = new GCObj(225125);
    private static volatile GCObj gcObj1 = new GCObj(5131465);
    private static volatile GCObj gcObj2 = new GCObj(949183);
    private static volatile GCObj gcObj3 = new GCObj(211327);
    private static volatile List<Object> list0 = new Vector();
    private static volatile int[] arr0 = new int[81780];
    private static volatile GCObj gcObj4 = new GCObj(121583);
    private static volatile List<Object> list1 = new LinkedList();
    private static volatile GCObj gcObj5 = new GCObj(1210677);
    private static volatile Set<Object> objVar0 = new LinkedHashSet();
    private static volatile int[] arr1 = new int[308];
    private static volatile int[] arr2 = new int[70743];
    private static volatile Map<Object, Object> objVar1 = new LinkedHashMap();
    private static volatile int[] arr3 = new int[421];
    private static volatile Set<Object> set0 = new TreeSet();
    private static volatile PhantomReference<GCObj> objVar2 = new PhantomReference(gcObj0, new ReferenceQueue());
    private static volatile int marRoundCounter = 0;
    private static volatile int mdrRoundCounter = 0;
    private static volatile int mmrRoundCounter = 0;
    private static volatile int sparRoundCounter = 0;
    private static volatile long TRAPCOUNT = 0L;
    public static void main(String[] args) throws ExecutionException, InterruptedException {
        try {
            Class.forName("com.gcscheduling.generated.ConcurrentTest_20260110_070655_785$MARWorker");
            Class.forName("com.gcscheduling.generated.ConcurrentTest_20260110_070655_785$MDRWorker");
            Class.forName("com.gcscheduling.generated.ConcurrentTest_20260110_070655_785$MMRWorker");
            Class.forName("com.gcscheduling.generated.ConcurrentTest_20260110_070655_785$SPARWorker");
        }
        catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        ExecutorService executorPool = Executors.newFixedThreadPool(4);

        Future<?> f1 = executorPool.submit(new MARWorker());
        Future<?> f2 = executorPool.submit(new MDRWorker());
        Future<?> f3 = executorPool.submit(new MMRWorker());
        Future<?> f4 = executorPool.submit(new SPARWorker());
        try {
            f1.get(10, TimeUnit.SECONDS);
            f2.get(10, TimeUnit.SECONDS);
            f3.get(10, TimeUnit.SECONDS);
            f4.get(10, TimeUnit.SECONDS);
        }
        catch (Exception e) {
            System.out.println("任务执行超时或异常: " + e.getMessage());
            f1.cancel(true);
            f2.cancel(true);
            f3.cancel(true);
            f4.cancel(true);
        }
        
        executorPool.shutdown();
        System.exit(0);
    }

    @WorkerMetadata(threadId = 0)
    static class MARWorker implements Runnable {
        static volatile List<Object> allocatedObjects = new ArrayList();
        static volatile Set<Object> largeObjectSet = new HashSet();
        static volatile Map<Object, Object> objectCache = new HashMap();
        static volatile List<List<Object> > nestedCollections = new ArrayList();
        static volatile GCObj objVar3 = new GCObj(89826);
        static volatile GCObj objVar4 = new GCObj(105794);
        static volatile int[] objVar5 = new int[648];
        static volatile GCObj objVar6 = new GCObj(6359708);
        static volatile List<Object> objVar7 = new LinkedList();
        static volatile GCObj objVar8 = new GCObj(2110154);
        static volatile SoftReference<GCObj> objVar9 = new SoftReference(gcObj0);
        @Override
        public void run() {
            int switchVar = 0;
            int whileCounter = 0;
            int doWhileCounter = 0;
            boolean shouldThrowException = false;
            while (marRoundCounter<16) {
                ++marRoundCounter;
                int currentRound = marRoundCounter;
                System.out.println("MAR Round 1");
                switchVar = 2;
                switch (switchVar) {
                    case 0:
                    allocatedObjects.add(new GCObj(229357));
                    break;
                    case 1:
                    arr3 = new int[527];
                    break;
                    case 2:
                    allocatedObjects.add(new GCObj(70867));
                    break;
                    default :
                    objVar2 = new PhantomReference(gcObj0, new ReferenceQueue());
                }
                doWhileCounter = 0;
                do {
                    list1 = new LinkedList();
                    doWhileCounter++;
                }
                while (doWhileCounter<4);
                doWhileCounter = 0;
                do {
                    objVar7 = new LinkedList();
                    doWhileCounter++;
                }
                while (doWhileCounter < 3);
                shouldThrowException = false;
                try {
                    if (shouldThrowException) {
                        OutOfMemoryError thrownException = new OutOfMemoryError("Simulated OOM during allocation");
                        throw thrownException;
                    }
                    allocatedObjects.add(new GCObj(761135));
                }
                catch (Exception e) {
                    TRAPCOUNT++;
                    System.out.println("Exception caught during allocation");
                }
                System.out.println("MAR Round 2");
                shouldThrowException = false;
                try {
                    if (shouldThrowException) {
                        OutOfMemoryError thrownException = new OutOfMemoryError("Simulated OOM during allocation");
                        throw thrownException;
                    }
                    list0 = new Vector();
                }
                catch (Exception e) {
                    TRAPCOUNT++;
                    System.out.println("Exception caught during allocation");
                }
                whileCounter = 0;
                while (whileCounter < 4) {
                    list1 = new LinkedList();
                    whileCounter++;
                }
                if (TRAPCOUNT % 2  == 0) {
                    arr3 = new int[8812];
                }
                whileCounter = 0;
                while (whileCounter < 2) {
                    allocatedObjects.add(new GCObj(1349836));
                    whileCounter++;
                }
                whileCounter = 0;
                System.gc();
                System.out.println("MAR Round 3");
                for (int i = 0;  i < 3; i++) {
                    objVar5 = new int[487];
                }
                for (int i = 0;  i < 3; i++) {
                    objVar7 = new LinkedList();
                }
                if (TRAPCOUNT % 2  == 0) {
                    set0 = new TreeSet();
                }
                else {
                    objVar2 = new PhantomReference(gcObj1, new ReferenceQueue());
                }
                shouldThrowException = false;
                try {
                    if (shouldThrowException) {
                        OutOfMemoryError thrownException = new OutOfMemoryError("Simulated OOM during allocation");
                        throw thrownException;
                    }
                    set0 = new TreeSet();
                }
                catch (Exception e) {
                    TRAPCOUNT++;
                    System.out.println("Exception caught during allocation");
                }
                if (TRAPCOUNT % 2  == 0) {
                    list0 = new Vector();
                }
                else {
                    arr3 = new int[1494];
                }
                whileCounter = 0;
                while (whileCounter < 3) {
                    list0 = new Vector();
                    whileCounter++;
                }
                System.out.println("MAR Round 4");
                switchVar = 0;
                switch (switchVar) {
                    case 0:
                    arr1 = new int[1102];
                    break;
                    case 1:
                    objVar5 = new int[1006];
                    break;
                    case 2:
                    objVar2 = new PhantomReference(gcObj0, new ReferenceQueue());
                    break;
                    default :
                    allocatedObjects.add(new GCObj(8263361));
                }
                whileCounter = 0;
                while (whileCounter < 3) {
                    list0 = new Vector();
                    whileCounter++;
                }
                shouldThrowException = false;
                try {
                    if (shouldThrowException) {
                        OutOfMemoryError thrownException = new OutOfMemoryError("Simulated OOM during allocation");
                        throw thrownException;
                    }
                    allocatedObjects.add(new GCObj(1810703));
                }
                catch (Exception e) {
                    TRAPCOUNT++;
                    System.out.println("Exception caught during allocation");
                }
                doWhileCounter = 0;
                do {
                    allocatedObjects.add(new GCObj(8203166));
                    doWhileCounter++;
                }
                while (doWhileCounter < 4);
                System.out.println("MAR Round 5");
                switchVar = 0;
                switch (switchVar) {
                    case 0:
                    allocatedObjects.add(new GCObj(5873620));
                    break;
                    case 1:
                    list0 = new Vector();
                    break;
                    case 2:
                    arr1 = new int[725];
                    break;
                    default :
                    objVar7 = new LinkedList();
                }
                if (TRAPCOUNT % 2  == 0) {
                    list0 = new Vector();
                }
                else {
                    allocatedObjects.add(new GCObj(3367098));
                }
                switchVar = 2;
                switch (switchVar) {
                    case 0:
                    objVar5 = new int[189];
                    break;
                    case 1:
                    allocatedObjects.add(new GCObj(786104));
                    break;
                    case 2:
                    allocatedObjects.add(new GCObj(211934));
                    break;
                    default :
                    arr3 = new int[235];
                }
                doWhileCounter = 0;
                do {
                    arr3 = new int[1546];
                    doWhileCounter++;
                }
                while (doWhileCounter < 4);
                whileCounter = 0;
                System.out.println("MAR Round 6");
                if (TRAPCOUNT % 2  == 0) {
                    objVar5 = new int[29];
                }
                else {
                    objVar7 = new LinkedList();
                }
                whileCounter = 0;
                while (whileCounter < 4) {
                    allocatedObjects.add(new GCObj(66999));
                    whileCounter++;
                }
                whileCounter = 0;
                while (whileCounter < 3) {
                    arr2 = new int[2202];
                    whileCounter++;
                }
                shouldThrowException = false;
                try {
                    if (shouldThrowException) {
                        OutOfMemoryError thrownException = new OutOfMemoryError("Simulated OOM during allocation");
                        throw thrownException;
                    }
                    allocatedObjects.add(new GCObj(8230885));
                }
                catch (Exception e) {
                    TRAPCOUNT++;
                    System.out.println("Exception caught during allocation");
                }
                for (int i = 0;  i < 3; i++) {
                    allocatedObjects.add(new GCObj(87552));
                }
                System.gc();
                System.out.println("MAR Round 7");
                shouldThrowException = false;
                try {
                    if (shouldThrowException) {
                        OutOfMemoryError thrownException = new OutOfMemoryError("Simulated OOM during allocation");
                        throw thrownException;
                    }
                    allocatedObjects.add(new GCObj(163354));
                }
                catch (Exception e) {
                    TRAPCOUNT++;
                    System.out.println("Exception caught during allocation");
                }
                for (int i = 0;  i < 4; i++) {
                    objVar2 = new PhantomReference(objVar4, new ReferenceQueue());
                }
                whileCounter = 0;
                while (whileCounter < 4) {
                    whileCounter++;
                }
                shouldThrowException = false;
                try {
                    if (shouldThrowException) {
                        OutOfMemoryError thrownException = new OutOfMemoryError("Simulated OOM during allocation");
                        throw thrownException;
                    }
                }
                catch (Exception e) {
                    TRAPCOUNT++;
                    System.out.println("Exception caught during allocation");
                }
                allocatedObjects.add(new GCObj(184271));
                System.out.println("MAR Round 8");
                whileCounter = 0;
                while (whileCounter < 3) {
                    objVar7 = new LinkedList();
                    whileCounter++;
                }
                whileCounter = 0;
                while (whileCounter < 2) {
                    arr1 = new int[649];
                    whileCounter++;
                }
                switchVar = 1;
                switch (switchVar) {
                    case 0:
                    list1 = new LinkedList();
                    break;
                    case 1:
                    objVar2 = new PhantomReference(objVar4, new ReferenceQueue());
                    break;
                    case 2:
                    list0 = new Vector();
                    break;
                    default :
                    objVar9 = new SoftReference(gcObj5);
                }
                if (TRAPCOUNT % 2  == 0) {
                    arr3 = new int[1855];
                }
                else {
                    allocatedObjects.add(new GCObj(119307));
                }
                whileCounter = 0;
                System.out.println("MAR Round 9");
                whileCounter = 0;
                while (whileCounter < 2) {
                    arr0 = new int[7530];
                    whileCounter++;
                }
                shouldThrowException = false;
                try {
                    if (shouldThrowException) {
                        OutOfMemoryError thrownException = new OutOfMemoryError("Simulated OOM during allocation");
                        throw thrownException;
                    }
                    allocatedObjects.add(new GCObj(3122530));
                }
                catch (Exception e) {
                    TRAPCOUNT++;
                    System.out.println("Exception caught during allocation");
                }
                doWhileCounter = 0;
                do {
                    allocatedObjects.add(new GCObj(255282));
                    doWhileCounter++;
                }
                while (doWhileCounter < 2);
                for (int i = 0;  i < 2; i++) {
                    allocatedObjects.add(new GCObj(6715493));
                }
                for (int i = 0;  i < 4; i++) {
                    allocatedObjects.add(new GCObj(7343071));
                }
                System.gc();
                System.out.println("MAR Round 10");
                doWhileCounter = 0;
                do {
                    allocatedObjects.add(new GCObj(4804326));
                    doWhileCounter++;
                }
                while (doWhileCounter < 2);
                whileCounter = 0;
                while (whileCounter < 4) {
                    arr1 = new int[35];
                    whileCounter++;
                }
                whileCounter = 0;
                while (whileCounter < 2) {
                    allocatedObjects.add(new GCObj(91913));
                    whileCounter++;
                }
                doWhileCounter = 0;
                do {
                    allocatedObjects.add(new GCObj(4209384));
                    doWhileCounter++;
                }
                while (doWhileCounter < 4);
                System.out.println("MAR Round 11");
                shouldThrowException = false;
                try {
                    if (shouldThrowException) {
                        OutOfMemoryError thrownException = new OutOfMemoryError("Simulated OOM during allocation");
                        throw thrownException;
                    }
                    allocatedObjects.add(new GCObj(111948));
                }
                catch (Exception e) {
                    TRAPCOUNT++;
                    System.out.println("Exception caught during allocation");
                }
                shouldThrowException = false;
                try {
                    if (shouldThrowException) {
                        OutOfMemoryError thrownException = new OutOfMemoryError("Simulated OOM during allocation");
                        throw thrownException;
                    }
                    allocatedObjects.add(new GCObj(1433810));
                }
                catch (Exception e) {
                    TRAPCOUNT++;
                    System.out.println("Exception caught during allocation");
                }
                shouldThrowException = false;
                try {
                    if (shouldThrowException) {
                        OutOfMemoryError thrownException = new OutOfMemoryError("Simulated OOM during allocation");
                        throw thrownException;
                    }
                    list0 = new Vector();
                }
                catch (Exception e) {
                    TRAPCOUNT++;
                    System.out.println("Exception caught during allocation");
                }
                whileCounter = 0;
                while (whileCounter < 4) {
                    whileCounter++;
                }
                System.gc();
                System.out.println("MAR Round 12");
                shouldThrowException = false;
                try {
                    if (shouldThrowException) {
                        OutOfMemoryError thrownException = new OutOfMemoryError("Simulated OOM during allocation");
                        throw thrownException;
                    }
                    allocatedObjects.add(new GCObj(3168386));
                }
                catch (Exception e) {
                    TRAPCOUNT++;
                    System.out.println("Exception caught during allocation");
                }
                doWhileCounter = 0;
                do {
                    list0 = new Vector();
                    doWhileCounter++;
                }
                while (doWhileCounter < 4);
                allocatedObjects.add(new GCObj(8203372));
                arr3 = new int[481];
                arr1 = new int[128];
                arr3 = new int[4127];
                System.out.println("MAR Round 13");
                switchVar = 1;
                switch (switchVar) {
                    case 0:
                    arr2 = new int[1952];
                    break;
                    case 1:
                    objVar5 = new int[3013];
                    break;
                    case 2:
                    set0 = new TreeSet();
                    break;
                    default :
                    objVar5 = new int[1736];
                }
                switchVar = 1;
                switch (switchVar) {
                    case 0:
                    allocatedObjects.add(new GCObj(2550595));
                    break;
                    case 1:
                    arr3 = new int[2690];
                    break;
                    case 2:
                    list0 = new Vector();
                    break;
                    default :
                    objVar5 = new int[415];
                }
                doWhileCounter = 0;
                do {
                    arr3 = new int[4360];
                    doWhileCounter++;
                }
                while (doWhileCounter < 3);
                for (int i = 0;  i < 3; i++) {
                    allocatedObjects.add(new GCObj(2657320));
                }
                if (TRAPCOUNT % 2  == 0) {
                    objVar9 = new SoftReference(gcObj3);
                }
                else {
                    allocatedObjects.add(new GCObj(8131453));
                }
                System.out.println("MAR Round 14");
                switchVar = 1;
                switch (switchVar) {
                    case 0:
                    list1 = new LinkedList();
                    break;
                    case 1:
                    objVar7 = new LinkedList();
                    break;
                    case 2:
                    allocatedObjects.add(new GCObj(2195777));
                    break;
                    default :
                    list1 = new LinkedList();
                }
                shouldThrowException = false;
                try {
                    if (shouldThrowException) {
                        OutOfMemoryError thrownException = new OutOfMemoryError("Simulated OOM during allocation");
                        throw thrownException;
                    }
                    arr3 = new int[29];
                }
                catch (Exception e) {
                    TRAPCOUNT++;
                    System.out.println("Exception caught during allocation");
                }
                shouldThrowException = false;
                try {
                    if (shouldThrowException) {
                        OutOfMemoryError thrownException = new OutOfMemoryError("Simulated OOM during allocation");
                        throw thrownException;
                    }
                    arr2 = new int[361];
                }
                catch (Exception e) {
                    TRAPCOUNT++;
                    System.out.println("Exception caught during allocation");
                }
                doWhileCounter = 0;
                do {
                    allocatedObjects.add(new GCObj(3028765));
                    doWhileCounter++;
                }
                while (doWhileCounter < 2);
                System.out.println("MAR Round 15");
                shouldThrowException = false;
                try {
                    if (shouldThrowException) {
                        OutOfMemoryError thrownException = new OutOfMemoryError("Simulated OOM during allocation");
                        throw thrownException;
                    }
                    list1 = new LinkedList();
                }
                catch (Exception e) {
                    TRAPCOUNT++;
                    System.out.println("Exception caught during allocation");
                }
                shouldThrowException = false;
                try {
                    if (shouldThrowException) {
                        OutOfMemoryError thrownException = new OutOfMemoryError("Simulated OOM during allocation");
                        throw thrownException;
                    }
                    allocatedObjects.add(new GCObj(1383974));
                }
                catch (Exception e) {
                    TRAPCOUNT++;
                    System.out.println("Exception caught during allocation");
                }
                whileCounter = 0;
                while (whileCounter < 3) {
                    allocatedObjects.add(new GCObj(5041226));
                    whileCounter++;
                }
                allocatedObjects.add(new GCObj(1511911));
                list0 = new Vector();
                System.gc();
                System.out.println("MAR Round 16");
                allocatedObjects.add(new GCObj(194784));
                allocatedObjects.add(new GCObj(8158346));
                objVar5 = new int[643];
                arr2 = new int[2053];
                allocatedObjects.add(new GCObj(6961367));
                allocatedObjects.add(new GCObj(3146869));
                allocatedObjects.add(new GCObj(199071));
                allocatedObjects.add(new GCObj(692264));
            }
        }
    }

    @WorkerMetadata(threadId = 1)
    static class MDRWorker implements Runnable {
        private static final Random random = new Random(0L);
        @Override
        public void run() {
            int switchVar = 0;
            int whileCounter = 0;
            int doWhileCounter = 0;
            boolean shouldThrowException = false;
            while (mdrRoundCounter < 15) {
                ++mdrRoundCounter;
                int currentRound = mdrRoundCounter;
                System.out.println("MDR Round 1");
                shouldThrowException = false;
                try {
                    if (shouldThrowException) {
                        IllegalStateException thrownException = new IllegalStateException("Error during deallocation");
                        throw thrownException;
                    }
                    if (gcObj5 != null) {
                        gcObj5.releaseAllReferences();
                        gcObj5 = null;
                    }
                }
                catch (Exception e) {
                    TRAPCOUNT++;
                    System.out.println("Exception caught during deallocation");
                }
                switchVar = 1;
                System.gc();
                System.out.println("MDR Round 2");
                for (int i = 0;  i < 1; i++) {
                    if (gcObj0 != null) {
                        gcObj0.releaseAllReferences();
                        gcObj0 = null;
                    }
                }
                doWhileCounter = 0;
                do {
                    set0 = null;
                    doWhileCounter++;
                }
                while (doWhileCounter < 1);
                System.gc();
                System.out.println("MDR Round 3");
                System.gc();
                System.out.println("System.gc()called - requesting garbage collection");
                System.gc();
                System.gc();
                System.out.println("MDR Round 4");
                System.gc();
                System.out.println("System.gc()called - requesting garbage collection");
                System.gc();
                System.gc();
                System.out.println("MDR Round 5");
                System.gc();
                System.out.println("System.gc()called - requesting garbage collection");
                System.gc();
                System.gc();
                System.out.println("MDR Round 6");
                System.gc();
                System.out.println("MDR Round 7");
                System.gc();
                System.out.println("System.gc()called - requesting garbage collection");
                System.gc();
                System.gc();
                System.out.println("MDR Round 8");
                System.gc();
                System.out.println("System.gc()called - requesting garbage collection");
                System.gc();
                System.out.println("MDR Round 9");
                System.gc();
                System.out.println("System.gc()called - requesting garbage collection");
                System.gc();
                System.gc();
                System.out.println("MDR Round 10");
                System.gc();
                System.out.println("System.gc()called - requesting garbage collection");
                System.gc();
                System.gc();
                System.out.println("MDR Round 11");
                System.gc();
                System.out.println("System.gc()called - requesting garbage collection");
                System.gc();
                System.gc();
                System.out.println("MDR Round 12");
                System.gc();
                System.out.println("MDR Round 13");
                System.gc();
                System.out.println("System.gc()called - requesting garbage collection");
                System.gc();
                System.gc();
                System.out.println("MDR Round 14");
                System.gc();
                System.out.println("System.gc()called - requesting garbage collection");
                System.gc();
                System.gc();
                System.out.println("MDR Round 15");
                System.gc();
                System.out.println("System.gc()called - requesting garbage collection");
                System.gc();
            }
        }
    }

    @WorkerMetadata(threadId = 2)
    static class MMRWorker implements Runnable {
        private static final Random random = new Random(0L);
        @Override
        public void run() {
            int safeIndex = 0;
            int switchVar = 0;
            int whileCounter = 0;
            int doWhileCounter = 0;
            boolean shouldThrowException = false;
            while (mmrRoundCounter < 14) {
                ++mmrRoundCounter;
                int currentRound = mmrRoundCounter;
                System.out.println("MMR Round 1");
                list0.add(868);
                arr2 = new int[70743];
                MARWorker.objVar3.modifyArrayElement(0, 126);
                MARWorker.objVar6 = new GCObj(39971);
                for (int i = 0;  i<1; i++) {
                    if (arr2 != null && arr2.length> 0) {
                        safeIndex = arr2.length > 0 ? arr2.length / 2 : 0;
                        arr2[safeIndex] = 672;
                    }
                }
                System.out.println("MMR Round 2");
                MARWorker.objVar4.processGCObj();
                MARWorker.objVar3.processGCObj();
                list1.add(new Object());
                try {
                    if (arr0 != null && arr0.length > 0) {
                        safeIndex = arr0.length > 0 ? arr0.length / 2 : 0;
                        arr0[safeIndex] = 663;
                    }
                }
                catch (Exception e) {
                }
                MARWorker.objVar3.processGCObj();
                System.out.println("MMR Round 3");
                for (int i = 0;  i<1; i++) {
                    if (arr2 != null && arr2.length> 0) {
                        safeIndex = arr2.length > 0 ? arr2.length / 2 : 0;
                        arr2[safeIndex] = 445;
                    }
                }
                gcObj2.replaceStrongReference(null);
                if (random.nextBoolean()) {
                    if (arr1 != null && arr1.length > 0) {
                        safeIndex = arr1.length > 0 ? arr1.length / 2 : 0;
                        arr1[safeIndex] = 24;
                    }
                }
                if (list1 != null && list1.size() > 0) {
                    list1.remove(0);
                }
                MARWorker.objVar4.modifyArrayElement(2, 111);
                System.out.println("MMR Round 4");
                for (int i = 0;  i<1; i++) {
                    list1 = new LinkedList();
                }
                if (random.nextBoolean()) {
                    gcObj4 = new GCObj(44029);
                }
                MARWorker.objVar4.replaceStrongReference(null);
                gcObj3.modifyArrayElement(4, 145);
                gcObj1 = new GCObj(10620);
                System.out.println("MMR Round 5");
                arr1 = new int[308];
                gcObj1 = new GCObj(9598);
                MARWorker.objVar3.processGCObj();
                for (int i = 0;  i<1; i++) {
                    gcObj2.modifyArrayElement(8, 30);
                }
                MARWorker.objVar6.replaceStrongReference(null);
                System.out.println("MMR Round 6");
                MARWorker.objVar3.processGCObj();
                list1.clear();
                gcObj4 = new GCObj(59000);
                if (arr0 != null && arr0.length> 0) {
                    safeIndex = arr0.length > 0 ? arr0.length / 2 : 0;
                    arr0[safeIndex] = 667;
                }
                gcObj1 = new GCObj(2854);
                System.out.println("MMR Round 7");
                if (random.nextBoolean()) {
                    if (arr0 != null && arr0.length > 0) {
                        safeIndex = arr0.length > 0 ? arr0.length / 2 : 0;
                        arr0[safeIndex] = 597;
                    }
                }
                for (int i = 0;  i<1; i++) {
                    list0 = new Vector();
                }
                for (int i = 0;  i<1; i++) {
                    MARWorker.objVar3.replaceStrongReference(null);
                }
                if (list1 != null && list1.size()> 0) {
                    list1.set(0, new Object());
                }
                MARWorker.objVar4 = new GCObj(45414);
                System.out.println("MMR Round 8");
                MARWorker.objVar6.processGCObj();
                if (arr2 != null && arr2.length > 0) {
                    safeIndex = arr2.length > 0 ? arr2.length / 2 : 0;
                    arr2[safeIndex] = 392;
                }
                MARWorker.objVar3.replaceStrongReference(null);
                arr2 = new int[70743];
                list1 = new LinkedList();
                System.out.println("MMR Round 9");
                for (int i = 0;  i<2; i++) {
                    if (arr1 != null && arr1.length> 0) {
                        safeIndex = arr1.length > 0 ? arr1.length / 2 : 0;
                        arr1[safeIndex] = 810;
                    }
                }
                if (arr0 != null && arr0.length > 0) {
                    safeIndex = arr0.length > 0 ? arr0.length / 2 : 0;
                    arr0[safeIndex] = 424;
                }
                gcObj4.processGCObj();
                MARWorker.objVar4.processGCObj();
                try {
                    gcObj4 = new GCObj(25627);
                }
                catch (Exception e) {
                }
                System.out.println("MMR Round 10");
                for (int i = 0;  i<1; i++) {
                    if (arr0 != null && arr0.length> 0) {
                        safeIndex = arr0.length > 0 ? arr0.length / 2 : 0;
                        arr0[safeIndex] = 1;
                    }
                }
                for (int i = 0;  i<1; i++) {
                    if (arr3 != null && arr3.length> 0) {
                        safeIndex = arr3.length > 0 ? arr3.length / 2 : 0;
                        arr3[safeIndex] = 690;
                    }
                }
                try {
                    if (arr1 != null && arr1.length > 0) {
                        safeIndex = arr1.length > 0 ? arr1.length / 2 : 0;
                        arr1[safeIndex] = 281;
                    }
                }
                catch (Exception e) {
                }
                MARWorker.objVar6.modifyArrayElement(3, 289);
                try {
                    if (list1 != null && list1.size() > 0) {
                        list1.remove(0);
                    }
                }
                catch (Exception e) {
                }
                System.out.println("MMR Round 11");
                if (arr2 != null && arr2.length > 0) {
                    safeIndex = arr2.length > 0 ? arr2.length / 2 : 0;
                    arr2[safeIndex] = 641;
                }
                if (arr2 != null && arr2.length > 0) {
                    safeIndex = arr2.length > 0 ? arr2.length / 2 : 0;
                    arr2[safeIndex] = 301;
                }
                gcObj4.modifyArrayElement(9, 351);
                gcObj1.replaceStrongReference(null);
                list1.add(new Object());
                System.out.println("MMR Round 12");
                if (random.nextBoolean()) {
                    if (arr1 != null && arr1.length > 0) {
                        safeIndex = arr1.length > 0 ? arr1.length / 2 : 0;
                        arr1[safeIndex] = 351;
                    }
                }
                MARWorker.objVar3 = new GCObj(42971);
                gcObj2 = new GCObj(54823);
                MARWorker.objVar8 = new GCObj(61736);
                arr3 = new int[421];
                System.out.println("MMR Round 13");
                MARWorker.objVar8.replaceStrongReference(null);
                if (arr3 != null && arr3.length > 0) {
                    arr3[0] = 983;
                }
                list1.add(new Object());
                gcObj3.modifyArrayElement(8, 613);
                for (int i = 0;  i<1; i++) {
                    list1.clear();
                }
                System.out.println("MMR Round 14");
                gcObj2 = new GCObj(41129);
                MARWorker.objVar8.replaceStrongReference(null);
                gcObj3.processGCObj();
                list0.add(new Object());
                for (int i = 0;  i<2; i++) {
                    MARWorker.objVar4.modifyArrayElement(5, 116);
                }
            }
        }
    }

    @WorkerMetadata(threadId = 3)
    static class SPARWorker implements Runnable {
        private static final Random random = new Random(0L);
        @Override
        public void run() {
            int switchVar = 0;
            int whileCounter = 0;
            int doWhileCounter = 0;
            boolean shouldThrowException = false;
            while (sparRoundCounter<11) {
                ++sparRoundCounter;
                int currentRound = sparRoundCounter;
                System.out.println("SPAR Round 1");
                shouldThrowException = true;
                try {
                    if (shouldThrowException) {
                        UnsupportedOperationException thrownException = new UnsupportedOperationException("GCFuzz generated UnsupportedOperationException for testing");
                        throw thrownException;
                    }
                    arr0[0] = 48;
                }
                catch (Exception e) {
                    TRAPCOUNT++;
                    System.out.println("Exception caught");
                }
                whileCounter = 0;
                while (whileCounter<5) {
                    if (MARWorker.objVar3 != null) {
                        MARWorker.objVar3.processGCObj();
                    }
                    whileCounter++;
                }
                whileCounter = 0;
                while (whileCounter < 7) {
                    int temp769 = 45;
                    whileCounter++;
                }
                System.out.println("SPAR Round 2");
                doWhileCounter = 0;
                do {
                    int temp539 = 97;
                    doWhileCounter++;
                }
                while (doWhileCounter < 6);
                if (TRAPCOUNT % 2  == 0) {
                    if (MARWorker.objVar6 != null) {
                        MARWorker.objVar6.processGCObj();
                    }
                }
                shouldThrowException = false;
                try {
                    if (shouldThrowException) {
                        IndexOutOfBoundsException thrownException = new IndexOutOfBoundsException("GCFuzz generated IndexOutOfBoundsException for testing");
                        throw thrownException;
                    }
                    arr0[0] = 57;
                }
                catch (Exception e) {
                    TRAPCOUNT++;
                    System.out.println("Exception caught");
                }
                shouldThrowException = false;
                System.out.println("SPAR Round 3");
                if (MARWorker.objVar4 != null) {
                    if (gcObj4 != null) {
                        gcObj4.processGCObj();
                    }
                }
                doWhileCounter = 0;
                do {
                    if (MARWorker.objVar4 != null) {
                        MARWorker.objVar4.processGCObj();
                    }
                    doWhileCounter++;
                }
                while (doWhileCounter < 4);
                for (int i = 0;  i < 11; i++) {
                    if (gcObj3 != null) {
                        gcObj3.processGCObj();
                    }
                }
                shouldThrowException = true;
                try {
                    if (shouldThrowException) {
                        IllegalArgumentException thrownException = new IllegalArgumentException("GCFuzz generated IllegalArgumentException for testing");
                        throw thrownException;
                    }
                    arr0[0] = 98;
                }
                catch (Exception e) {
                    TRAPCOUNT++;
                    System.out.println("Exception caught");
                }
                finally {
                    System.gc();
                }
                System.out.println("SPAR Round 4");
                shouldThrowException = true;
                try {
                    if (shouldThrowException) {
                        IllegalArgumentException thrownException = new IllegalArgumentException("GCFuzz generated IllegalArgumentException for testing");
                        throw thrownException;
                    }
                    arr0[0] = 97;
                }
                catch (Exception e) {
                    TRAPCOUNT++;
                    System.out.println("Exception caught");
                }
                for (int i = 0;  i < 14; i++) {
                    if (gcObj2 != null) {
                        gcObj2.processGCObj();
                    }
                }
                switchVar = 2;
                switch (switchVar) {
                    case 0:
                    if (gcObj1 != null) {
                        gcObj1.processGCObj();
                    }
                    break;
                    case 1:
                    int temp95 = 19;
                    break;
                    case 2:
                    int temp651 = 57;
                    break;
                    default :
                    int temp650 = 30;
                }
                shouldThrowException = false;
                System.out.println("SPAR Round 5");
                if (arr0 != null && arr0.length> 0) {
                    int temp449 = 39;
                }
                if (MARWorker.objVar8 != null) {
                    int temp236 = 1;
                }
                for (int i = 0;  i < 8; i++) {
                    int temp474 = 99;
                }
                whileCounter = 0;
                while (whileCounter < 4) {
                    int temp924 = 47;
                    whileCounter++;
                }
                switchVar = 2;
                System.out.println("SPAR Round 6");
                for (int i = 0;  i < 8; i++) {
                    if (MARWorker.objVar3 != null) {
                        MARWorker.objVar3.processGCObj();
                    }
                }
                for (int i = 0;  i < 8; i++) {
                    int temp879 = 97;
                }
                for (int i = 0;  i < 14; i++) {
                    int temp894 = 81;
                }
                shouldThrowException = true;
                try {
                    if (shouldThrowException) {
                        UnsupportedOperationException thrownException = new UnsupportedOperationException("GCFuzz generated UnsupportedOperationException for testing");
                        throw thrownException;
                    }
                    arr0[0] = 73;
                }
                catch (Exception e) {
                    TRAPCOUNT++;
                    System.out.println("Exception caught");
                }
                switchVar = 2;
                System.out.println("SPAR Round 7");
                if (gcObj2 != null) {
                    if (MARWorker.objVar8 != null) {
                        MARWorker.objVar8.processGCObj();
                    }
                }
                switchVar = 2;
                switch (switchVar) {
                    case 0:
                    int temp82 = 75;
                    break;
                    case 1:
                    int temp330 = 60;
                    break;
                    case 2:
                    int temp484 = 11;
                    break;
                    default :
                    if (MARWorker.objVar4 != null) {
                        MARWorker.objVar4.processGCObj();
                    }
                }
                whileCounter = 0;
                while (whileCounter < 4) {
                    int temp775 = 73;
                    whileCounter++;
                }
                whileCounter = 0;
                System.out.println("SPAR Round 8");
                whileCounter = 0;
                while (whileCounter < 3) {
                    int temp85 = 45;
                    whileCounter++;
                }
                doWhileCounter = 0;
                do {
                    doWhileCounter++;
                }
                while (doWhileCounter < 5);
                whileCounter = 0;
                while (whileCounter < 10) {
                    if (gcObj3 != null) {
                        gcObj3.processGCObj();
                    }
                    whileCounter++;
                }
                System.out.println("SPAR Round 9");
                shouldThrowException = false;
                try {
                    if (shouldThrowException) {
                        IndexOutOfBoundsException thrownException = new IndexOutOfBoundsException("GCFuzz generated IndexOutOfBoundsException for testing");
                        throw thrownException;
                    }
                    arr0[0] = 9;
                }
                catch (Exception e) {
                    TRAPCOUNT++;
                    System.out.println("Exception caught");
                }
                finally {
                    System.gc();
                }
                shouldThrowException = false;
                try {
                    if (shouldThrowException) {
                        RuntimeException thrownException = new RuntimeException("GCFuzz generated RuntimeException for testing");
                        throw thrownException;
                    }
                    arr0[0] = 75;
                }
                catch (Exception e) {
                    TRAPCOUNT++;
                    System.out.println("Exception caught");
                }
                if (MARWorker.objVar6 != null) {
                    if (gcObj3 != null) {
                        gcObj3.processGCObj();
                    }
                }
                else {
                    int temp125 = 73;
                }
                if (MARWorker.objVar3 != null) {
                    if (gcObj3 != null) {
                        gcObj3.processGCObj();
                    }
                }
                else {
                    if (MARWorker.objVar6 != null) {
                        MARWorker.objVar6.processGCObj();
                    }
                }
                System.out.println("SPAR Round 10");
                for (int i = 0;  i < 9; i++) {
                    int temp932 = 91;
                }
                if (objVar0 != null) {
                    int temp683 = 26;
                }
                else {
                    if (gcObj1 != null) {
                        gcObj1.processGCObj();
                    }
                }
                if (TRAPCOUNT % 2  == 0) {
                    int temp767 = 29;
                }
                else {
                    int temp887 = 12;
                }
                for (int i = 0;  i < 10; i++) {
                    if (MARWorker.objVar4 != null) {
                        MARWorker.objVar4.processGCObj();
                    }
                }
                whileCounter = 0;
                while (whileCounter < 3) {
                    int temp895 = 31;
                    whileCounter++;
                }
                System.out.println("SPAR Round 11");
                for (int i = 0;  i < 14; i++) {
                    if (MARWorker.objVar3 != null) {
                        MARWorker.objVar3.processGCObj();
                    }
                }
                shouldThrowException = true;
                try {
                    if (shouldThrowException) {
                        RuntimeException thrownException = new RuntimeException("GCFuzz generated RuntimeException for testing");
                        throw thrownException;
                    }
                    arr0[0] = 79;
                }
                catch (Exception e) {
                    TRAPCOUNT++;
                    System.out.println("Exception caught");
                }
                doWhileCounter = 0;
                do {
                    int temp907 = 0;
                    doWhileCounter++;
                }
                while (doWhileCounter < 5);
                for (int i = 0;  i < 13; i++) {
                    int temp129 = 91;
                }
            }
        }
    }
}
