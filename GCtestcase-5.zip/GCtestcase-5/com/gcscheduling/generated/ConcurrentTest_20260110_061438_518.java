package com.gcscheduling.generated;

import com.concurrency.agent.WorkerMetadata;
import java.util.concurrent.*;
import java.util.*;
import java.lang.ref.*;
import org.example.codegen.model.GCObj;
public class ConcurrentTest_20260110_061438_518 {
    private static volatile GCObj gcObj0 = new GCObj(646599);
    private static volatile GCObj gcObj1 = new GCObj(242119);
    private static volatile Object[] arr0 = new Object[63];
    private static volatile Set<Object> set0 = new TreeSet();
    private static volatile List<Object> list0 = new Vector();
    private static volatile List<Object> list1 = new ArrayList();
    private static volatile GCObj gcObj2 = new GCObj(3951982);
    private static volatile GCObj gcObj3 = new GCObj(2122761);
    private static volatile GCObj gcObj4 = new GCObj(181542);
    private static volatile Map<Object, Object> objVar0 = new LinkedHashMap();
    private static volatile int[] arr1 = new int[724];
    private static volatile int[] arr2 = new int[56792];
    private static volatile GCObj gcObj5 = new GCObj(1201942);
    private static volatile Map<Object, Object> objVar1 = new LinkedHashMap();
    private static volatile GCObj gcObj6 = new GCObj(6215172);
    private static volatile Object[] arr3 = new Object[307];
    private static volatile GCObj gcObj7 = new GCObj(7071472);
    private static volatile SoftReference<GCObj> objVar2 = new SoftReference(gcObj0);
    private static volatile PhantomReference<GCObj> objVar3 = new PhantomReference(gcObj0, new ReferenceQueue());
    private static volatile PhantomReference<Object> objVar4 = new PhantomReference(objVar3, new ReferenceQueue());
    private static volatile SoftReference<Object> objVar5 = new SoftReference(objVar4);
    private static volatile PhantomReference<Object> objVar6 = new PhantomReference(objVar5, new ReferenceQueue());
    private static volatile int marRoundCounter = 0;
    private static volatile int mdrRoundCounter = 0;
    private static volatile int mmrRoundCounter = 0;
    private static volatile int sparRoundCounter = 0;
    private static volatile long TRAPCOUNT = 0L;
    public static void main(String[] args) throws ExecutionException, InterruptedException {
        try {
            Class.forName("com.gcscheduling.generated.ConcurrentTest_20260110_061438_518$MARWorker");
            Class.forName("com.gcscheduling.generated.ConcurrentTest_20260110_061438_518$MDRWorker");
            Class.forName("com.gcscheduling.generated.ConcurrentTest_20260110_061438_518$MMRWorker");
            Class.forName("com.gcscheduling.generated.ConcurrentTest_20260110_061438_518$SPARWorker");
        }
        catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        ExecutorService executorPool = Executors.newFixedThreadPool(4);

        Future<?> f1 = executorPool.submit(new MARWorker());
        Future<?> f2 = executorPool.submit(new MDRWorker());
        Future<?> f3 = executorPool.submit(new MMRWorker());
        Future<?> f4 = executorPool.submit(new SPARWorker());
        try {
            f1.get(10, TimeUnit.SECONDS);
            f2.get(10, TimeUnit.SECONDS);
            f3.get(10, TimeUnit.SECONDS);
            f4.get(10, TimeUnit.SECONDS);
        }
        catch (Exception e) {
            System.out.println("任务执行超时或异常: " + e.getMessage());
            f1.cancel(true);
            f2.cancel(true);
            f3.cancel(true);
            f4.cancel(true);
        }
        
        executorPool.shutdown();
        System.exit(0);
    }

    @WorkerMetadata(threadId = 0)
    static class MARWorker implements Runnable {
        static volatile List<Object> allocatedObjects = new ArrayList();
        static volatile Set<Object> largeObjectSet = new HashSet();
        static volatile Map<Object, Object> objectCache = new HashMap();
        static volatile List<List<Object> > nestedCollections = new ArrayList();
        static volatile Object[] objVar7 = new Object[897];
        static volatile int[] objVar8 = new int[25986];
        static volatile int[] objVar9 = new int[107];
        static volatile WeakReference<GCObj> objVar10 = new WeakReference(gcObj0);
        @Override
        public void run() {
            int switchVar = 0;
            int whileCounter = 0;
            int doWhileCounter = 0;
            boolean shouldThrowException = false;
            while (marRoundCounter<27) {
                ++marRoundCounter;
                int currentRound = marRoundCounter;
                System.out.println("MAR Round 1");
                allocatedObjects.add(new GCObj(647107));
                allocatedObjects.add(new GCObj(248455));
                arr1 = new int[655];
                list1 = new ArrayList();
                allocatedObjects.add(new GCObj(252186));
                list1 = new ArrayList();
                allocatedObjects.add(new GCObj(3952158));
                allocatedObjects.add(new GCObj(2122957));
                System.out.println("MAR Round 2");
                shouldThrowException = false;
                try {
                    if (shouldThrowException) {
                        OutOfMemoryError thrownException = new OutOfMemoryError("Simulated OOM during allocation");
                        throw thrownException;
                    }
                    allocatedObjects.add(new GCObj(760994));
                }
                catch (Exception e) {
                    TRAPCOUNT++;
                    System.out.println("Exception caught during allocation");
                }
                switchVar = 1;
                switch (switchVar) {
                    case 0:
                    break;
                    case 1:
                    objVar8 = new int[2867];
                    break;
                    case 2:
                    objVar8 = new int[9395];
                    break;
                    default :
                    list0 = new Vector();
                }
                for (int i = 0;  i<2; i++) {
                    objVar6 = new PhantomReference(gcObj4, new ReferenceQueue());
                }
                if (TRAPCOUNT % 2  == 0) {
                }
                whileCounter = 0;
                while (whileCounter < 4) {
                    objVar5 = new SoftReference(gcObj0);
                    whileCounter++;
                }
                System.out.println("MAR Round 3");
                switchVar = 0;
                switch (switchVar) {
                    case 0:
                    set0 = new TreeSet();
                    break;
                    case 1:
                    list1 = new ArrayList();
                    break;
                    case 2:
                    objVar9 = new int[320];
                    break;
                    default :
                    list1 = new ArrayList();
                }
                for (int i = 0;  i < 3; i++) {
                    list1 = new ArrayList();
                }
                switchVar = 0;
                switch (switchVar) {
                    case 0:
                    objVar6 = new PhantomReference(gcObj2, new ReferenceQueue());
                    break;
                    case 1:
                    allocatedObjects.add(new GCObj(227219));
                    break;
                    case 2:
                    break;
                    default :
                    allocatedObjects.add(new GCObj(2764367));
                }
                shouldThrowException = false;
                try {
                    if (shouldThrowException) {
                        OutOfMemoryError thrownException = new OutOfMemoryError("Simulated OOM during allocation");
                        throw thrownException;
                    }
                }
                catch (Exception e) {
                    TRAPCOUNT++;
                    System.out.println("Exception caught during allocation");
                }
                allocatedObjects.add(new GCObj(1955222));
                System.gc();
                System.out.println("MAR Round 4");
                switchVar = 1;
                switch (switchVar) {
                    case 0:
                    set0 = new TreeSet();
                    break;
                    case 1:
                    allocatedObjects.add(new GCObj(1171577));
                    break;
                    case 2:
                    allocatedObjects.add(new GCObj(2466645));
                    break;
                    default :
                    allocatedObjects.add(new GCObj(3668397));
                }
                whileCounter = 0;
                while (whileCounter < 3) {
                    list0 = new Vector();
                    whileCounter++;
                }
                whileCounter = 0;
                while (whileCounter < 2) {
                    allocatedObjects.add(new GCObj(1968984));
                    whileCounter++;
                }
                objVar9 = new int[659];
                arr1 = new int[131];
                System.out.println("MAR Round 5");
                doWhileCounter = 0;
                do {
                    doWhileCounter++;
                }
                while (doWhileCounter < 3);
                shouldThrowException = false;
                try {
                    if (shouldThrowException) {
                        OutOfMemoryError thrownException = new OutOfMemoryError("Simulated OOM during allocation");
                        throw thrownException;
                    }
                    objVar4 = new PhantomReference(gcObj5, new ReferenceQueue());
                }
                catch (Exception e) {
                    TRAPCOUNT++;
                    System.out.println("Exception caught during allocation");
                }
                doWhileCounter = 0;
                do {
                    objVar10 = new WeakReference(gcObj2);
                    doWhileCounter++;
                }
                while (doWhileCounter < 4);
                whileCounter = 0;
                while (whileCounter < 3) {
                    set0 = new TreeSet();
                    whileCounter++;
                }
                System.out.println("MAR Round 6");
                for (int i = 0;  i < 3; i++) {
                    allocatedObjects.add(new GCObj(2007267));
                }
                doWhileCounter = 0;
                do {
                    doWhileCounter++;
                }
                while (doWhileCounter < 2);
                if (TRAPCOUNT % 2  == 0) {
                    allocatedObjects.add(new GCObj(206702));
                }
                doWhileCounter = 0;
                do {
                    objVar6 = new PhantomReference(gcObj1, new ReferenceQueue());
                    doWhileCounter++;
                }
                while (doWhileCounter < 4);
                shouldThrowException = false;
                try {
                    if (shouldThrowException) {
                        OutOfMemoryError thrownException = new OutOfMemoryError("Simulated OOM during allocation");
                        throw thrownException;
                    }
                    set0 = new TreeSet();
                }
                catch (Exception e) {
                    TRAPCOUNT++;
                    System.out.println("Exception caught during allocation");
                }
                System.out.println("MAR Round 7");
                arr1 = new int[1292];
                allocatedObjects.add(new GCObj(922333));
                allocatedObjects.add(new GCObj(197847));
                list1 = new ArrayList();
                allocatedObjects.add(new GCObj(1493488));
                allocatedObjects.add(new GCObj(122131));
                objVar9 = new int[3330];
                allocatedObjects.add(new GCObj(1512860));
                System.out.println("MAR Round 8");
                switchVar = 0;
                switch (switchVar) {
                    case 0:
                    objVar8 = new int[732];
                    break;
                    case 1:
                    allocatedObjects.add(new GCObj(2848780));
                    break;
                    case 2:
                    arr2 = new int[8635];
                    break;
                    default :
                    allocatedObjects.add(new GCObj(4829151));
                }
                whileCounter = 0;
                while (whileCounter < 4) {
                    allocatedObjects.add(new GCObj(1036278));
                    whileCounter++;
                }
                whileCounter = 0;
                while (whileCounter < 4) {
                    whileCounter++;
                }
                switchVar = 2;
                switch (switchVar) {
                    case 0:
                    objVar4 = new PhantomReference(gcObj4, new ReferenceQueue());
                    break;
                    case 1:
                    objVar2 = new SoftReference(gcObj7);
                    break;
                    case 2:
                    objVar4 = new PhantomReference(gcObj1, new ReferenceQueue());
                    break;
                    default :
                    allocatedObjects.add(new GCObj(865861));
                }
                System.gc();
                System.out.println("MAR Round 9");
                for (int i = 0;  i < 2; i++) {
                    objVar4 = new PhantomReference(gcObj7, new ReferenceQueue());
                }
                shouldThrowException = false;
                try {
                    if (shouldThrowException) {
                        OutOfMemoryError thrownException = new OutOfMemoryError("Simulated OOM during allocation");
                        throw thrownException;
                    }
                    objVar6 = new PhantomReference(gcObj2, new ReferenceQueue());
                }
                catch (Exception e) {
                    TRAPCOUNT++;
                    System.out.println("Exception caught during allocation");
                }
                for (int i = 0;  i < 3; i++) {
                }
                list0 = new Vector();
                allocatedObjects.add(new GCObj(2050021));
                shouldThrowException = false;
                try {
                    if (shouldThrowException) {
                        OutOfMemoryError thrownException = new OutOfMemoryError("Simulated OOM during allocation");
                        throw thrownException;
                    }
                }
                catch (Exception e) {
                    TRAPCOUNT++;
                    System.out.println("Exception caught during allocation");
                }
                System.out.println("MAR Round 10");
                if (TRAPCOUNT % 2  == 0) {
                }
                else {
                    objVar8 = new int[1425];
                }
                if (TRAPCOUNT % 2  == 0) {
                    allocatedObjects.add(new GCObj(1358280));
                }
                else {
                }
                whileCounter = 0;
                while (whileCounter < 3) {
                    objVar8 = new int[386];
                    whileCounter++;
                }
                allocatedObjects.add(new GCObj(4744069));
                list1 = new ArrayList();
                list1 = new ArrayList();
                list1 = new ArrayList();
                System.out.println("MAR Round 11");
                doWhileCounter = 0;
                do {
                    allocatedObjects.add(new GCObj(1774434));
                    doWhileCounter++;
                }
                while (doWhileCounter < 3);
                allocatedObjects.add(new GCObj(209357));
                allocatedObjects.add(new GCObj(5593121));
                allocatedObjects.add(new GCObj(118568));
                list1 = new ArrayList();
                arr2 = new int[436];
                arr1 = new int[2173];
                System.out.println("MAR Round 12");
                switchVar = 1;
                switch (switchVar) {
                    case 0:
                    set0 = new TreeSet();
                    break;
                    case 1:
                    allocatedObjects.add(new GCObj(233804));
                    break;
                    case 2:
                    allocatedObjects.add(new GCObj(2389901));
                    break;
                    default :
                }
                for (int i = 0;  i < 4; i++) {
                    objVar6 = new PhantomReference(gcObj5, new ReferenceQueue());
                }
                whileCounter = 0;
                while (whileCounter < 3) {
                    objVar4 = new PhantomReference(gcObj7, new ReferenceQueue());
                    whileCounter++;
                }
                switchVar = 0;
                switch (switchVar) {
                    case 0:
                    objVar10 = new WeakReference(gcObj0);
                    break;
                    case 1:
                    objVar2 = new SoftReference(gcObj0);
                    break;
                    case 2:
                    allocatedObjects.add(new GCObj(7407926));
                    break;
                    default :
                    allocatedObjects.add(new GCObj(3503622));
                }
                for (int i = 0;  i < 4; i++) {
                }
                System.gc();
                System.out.println("MAR Round 13");
                whileCounter = 0;
                while (whileCounter < 3) {
                    allocatedObjects.add(new GCObj(6366609));
                    whileCounter++;
                }
                whileCounter = 0;
                while (whileCounter < 4) {
                    objVar10 = new WeakReference(gcObj1);
                    whileCounter++;
                }
                shouldThrowException = false;
                try {
                    if (shouldThrowException) {
                        OutOfMemoryError thrownException = new OutOfMemoryError("Simulated OOM during allocation");
                        throw thrownException;
                    }
                }
                catch (Exception e) {
                    TRAPCOUNT++;
                    System.out.println("Exception caught during allocation");
                }
                for (int i = 0;  i < 3; i++) {
                    allocatedObjects.add(new GCObj(71119));
                }
                for (int i = 0;  i < 4; i++) {
                    objVar5 = new SoftReference(gcObj3);
                }
                System.out.println("MAR Round 14");
                doWhileCounter = 0;
                do {
                    objVar10 = new WeakReference(gcObj4);
                    doWhileCounter++;
                }
                while (doWhileCounter < 3);
                for (int i = 0;  i < 2; i++) {
                    allocatedObjects.add(new GCObj(5715979));
                }
                switchVar = 2;
                switch (switchVar) {
                    case 0:
                    allocatedObjects.add(new GCObj(233569));
                    break;
                    case 1:
                    break;
                    case 2:
                    allocatedObjects.add(new GCObj(236934));
                    break;
                    default :
                    set0 = new TreeSet();
                }
                shouldThrowException = false;
                try {
                    if (shouldThrowException) {
                        OutOfMemoryError thrownException = new OutOfMemoryError("Simulated OOM during allocation");
                        throw thrownException;
                    }
                }
                catch (Exception e) {
                    TRAPCOUNT++;
                    System.out.println("Exception caught during allocation");
                }
                if (TRAPCOUNT % 2  == 0) {
                    allocatedObjects.add(new GCObj(220601));
                }
                else {
                    objVar3 = new PhantomReference(gcObj5, new ReferenceQueue());
                }
                System.gc();
                System.out.println("MAR Round 15");
                doWhileCounter = 0;
                do {
                    objVar3 = new PhantomReference(gcObj0, new ReferenceQueue());
                    doWhileCounter++;
                }
                while (doWhileCounter < 3);
                whileCounter = 0;
                while (whileCounter < 4) {
                    whileCounter++;
                }
                if (TRAPCOUNT % 2  == 0) {
                }
                else {
                    objVar10 = new WeakReference(gcObj5);
                }
                for (int i = 0;  i < 2; i++) {
                    objVar10 = new WeakReference(gcObj6);
                }
                shouldThrowException = false;
                try {
                    if (shouldThrowException) {
                        OutOfMemoryError thrownException = new OutOfMemoryError("Simulated OOM during allocation");
                        throw thrownException;
                    }
                    allocatedObjects.add(new GCObj(255071));
                }
                catch (Exception e) {
                    TRAPCOUNT++;
                    System.out.println("Exception caught during allocation");
                }
                System.gc();
                System.out.println("MAR Round 16");
                for (int i = 0;  i < 2; i++) {
                    list1 = new ArrayList();
                }
                allocatedObjects.add(new GCObj(119564));
                list1 = new ArrayList();
                allocatedObjects.add(new GCObj(188181));
                arr1 = new int[737];
                allocatedObjects.add(new GCObj(1671151));
                list1 = new ArrayList();
                objVar9 = new int[7651];
                System.gc();
                System.out.println("MAR Round 17");
                doWhileCounter = 0;
                do {
                    allocatedObjects.add(new GCObj(3459310));
                    doWhileCounter++;
                }
                while (doWhileCounter < 4);
                doWhileCounter = 0;
                do {
                    allocatedObjects.add(new GCObj(2427609));
                    doWhileCounter++;
                }
                while (doWhileCounter < 4);
                whileCounter = 0;
                while (whileCounter < 4) {
                    set0 = new TreeSet();
                    whileCounter++;
                }
                doWhileCounter = 0;
                do {
                    doWhileCounter++;
                }
                while (doWhileCounter < 2);
                System.out.println("MAR Round 18");
                shouldThrowException = false;
                try {
                    if (shouldThrowException) {
                        OutOfMemoryError thrownException = new OutOfMemoryError("Simulated OOM during allocation");
                        throw thrownException;
                    }
                    objVar9 = new int[701];
                }
                catch (Exception e) {
                    TRAPCOUNT++;
                    System.out.println("Exception caught during allocation");
                }
                for (int i = 0;  i < 4; i++) {
                    allocatedObjects.add(new GCObj(7527040));
                }
                switchVar = 0;
                switch (switchVar) {
                    case 0:
                    objVar5 = new SoftReference(gcObj3);
                    break;
                    case 1:
                    set0 = new TreeSet();
                    break;
                    case 2:
                    break;
                    default :
                    arr1 = new int[1256];
                }
                allocatedObjects.add(new GCObj(69105));
                allocatedObjects.add(new GCObj(2435286));
                allocatedObjects.add(new GCObj(720067));
                System.gc();
                System.out.println("MAR Round 19");
                whileCounter = 0;
                while (whileCounter < 3) {
                    whileCounter++;
                }
                shouldThrowException = false;
                try {
                    if (shouldThrowException) {
                        OutOfMemoryError thrownException = new OutOfMemoryError("Simulated OOM during allocation");
                        throw thrownException;
                    }
                    allocatedObjects.add(new GCObj(1188313));
                }
                catch (Exception e) {
                    TRAPCOUNT++;
                    System.out.println("Exception caught during allocation");
                }
                switchVar = 2;
                switch (switchVar) {
                    case 0:
                    break;
                    case 1:
                    arr2 = new int[4583];
                    break;
                    case 2:
                    allocatedObjects.add(new GCObj(164963));
                    break;
                    default :
                    objVar3 = new PhantomReference(gcObj7, new ReferenceQueue());
                }
                allocatedObjects.add(new GCObj(210829));
                arr1 = new int[1001];
                System.out.println("MAR Round 20");
                switchVar = 1;
                switch (switchVar) {
                    case 0:
                    break;
                    case 1:
                    allocatedObjects.add(new GCObj(229988));
                    break;
                    case 2:
                    break;
                    default :
                }
                if (TRAPCOUNT % 2  == 0) {
                }
                doWhileCounter = 0;
                do {
                    list0 = new Vector();
                    doWhileCounter++;
                }
                while (doWhileCounter < 2);
                if (TRAPCOUNT % 2  == 0) {
                }
                else {
                    allocatedObjects.add(new GCObj(1438894));
                }
                whileCounter = 0;
                while (whileCounter < 4) {
                    objVar6 = new PhantomReference(gcObj3, new ReferenceQueue());
                    whileCounter++;
                }
                System.out.println("MAR Round 21");
                shouldThrowException = false;
                try {
                    if (shouldThrowException) {
                        OutOfMemoryError thrownException = new OutOfMemoryError("Simulated OOM during allocation");
                        throw thrownException;
                    }
                    objVar6 = new PhantomReference(gcObj0, new ReferenceQueue());
                }
                catch (Exception e) {
                    TRAPCOUNT++;
                    System.out.println("Exception caught during allocation");
                }
                whileCounter = 0;
                while (whileCounter < 3) {
                    objVar10 = new WeakReference(gcObj0);
                    whileCounter++;
                }
                whileCounter = 0;
                while (whileCounter < 3) {
                    whileCounter++;
                }
                switchVar = 2;
                switch (switchVar) {
                    case 0:
                    break;
                    case 1:
                    allocatedObjects.add(new GCObj(7278229));
                    break;
                    case 2:
                    objVar4 = new PhantomReference(gcObj7, new ReferenceQueue());
                    break;
                    default :
                    objVar6 = new PhantomReference(gcObj0, new ReferenceQueue());
                }
                System.out.println("MAR Round 22");
                for (int i = 0;  i < 2; i++) {
                    allocatedObjects.add(new GCObj(665488));
                }
                set0 = new TreeSet();
                if (TRAPCOUNT % 2  == 0) {
                    objVar9 = new int[683];
                }
                else {
                    arr1 = new int[1806];
                }
                list1 = new ArrayList();
                list1 = new ArrayList();
                arr1 = new int[8078];
                objVar9 = new int[419];
                arr2 = new int[104];
                System.out.println("MAR Round 23");
                shouldThrowException = false;
                try {
                    if (shouldThrowException) {
                        OutOfMemoryError thrownException = new OutOfMemoryError("Simulated OOM during allocation");
                        throw thrownException;
                    }
                    objVar10 = new WeakReference(gcObj0);
                }
                catch (Exception e) {
                    TRAPCOUNT++;
                    System.out.println("Exception caught during allocation");
                }
                shouldThrowException = false;
                try {
                    if (shouldThrowException) {
                        OutOfMemoryError thrownException = new OutOfMemoryError("Simulated OOM during allocation");
                        throw thrownException;
                    }
                    allocatedObjects.add(new GCObj(1433346));
                }
                catch (Exception e) {
                    TRAPCOUNT++;
                    System.out.println("Exception caught during allocation");
                }
                for (int i = 0;  i < 3; i++) {
                    allocatedObjects.add(new GCObj(7656208));
                }
                whileCounter = 0;
                while (whileCounter < 2) {
                    whileCounter++;
                }
                if (TRAPCOUNT % 2  == 0) {
                    objVar5 = new SoftReference(gcObj5);
                }
                else {
                }
                System.out.println("MAR Round 24");
                for (int i = 0;  i < 3; i++) {
                }
                for (int i = 0;  i < 4; i++) {
                    allocatedObjects.add(new GCObj(3836923));
                }
                doWhileCounter = 0;
                do {
                    list1 = new ArrayList();
                    doWhileCounter++;
                }
                while (doWhileCounter < 3);
                for (int i = 0;  i < 2; i++) {
                    allocatedObjects.add(new GCObj(115924));
                }
                shouldThrowException = false;
                try {
                    if (shouldThrowException) {
                        OutOfMemoryError thrownException = new OutOfMemoryError("Simulated OOM during allocation");
                        throw thrownException;
                    }
                    objVar8 = new int[529];
                }
                catch (Exception e) {
                    TRAPCOUNT++;
                    System.out.println("Exception caught during allocation");
                }
                whileCounter = 0;
                System.out.println("MAR Round 25");
                whileCounter = 0;
                while (whileCounter < 2) {
                    objVar5 = new SoftReference(gcObj0);
                    whileCounter++;
                }
                for (int i = 0;  i < 3; i++) {
                    objVar4 = new PhantomReference(gcObj7, new ReferenceQueue());
                }
                doWhileCounter = 0;
                do {
                    allocatedObjects.add(new GCObj(6428050));
                    doWhileCounter++;
                }
                while (doWhileCounter < 2);
                shouldThrowException = false;
                try {
                    if (shouldThrowException) {
                        OutOfMemoryError thrownException = new OutOfMemoryError("Simulated OOM during allocation");
                        throw thrownException;
                    }
                    objVar2 = new SoftReference(gcObj1);
                }
                catch (Exception e) {
                    TRAPCOUNT++;
                    System.out.println("Exception caught during allocation");
                }
                switchVar = 1;
                System.gc();
                System.out.println("MAR Round 26");
                for (int i = 0;  i < 3; i++) {
                    objVar8 = new int[457];
                }
                if (TRAPCOUNT % 2  == 0) {
                    allocatedObjects.add(new GCObj(4278954));
                }
                else {
                }
                shouldThrowException = false;
                try {
                    if (shouldThrowException) {
                        OutOfMemoryError thrownException = new OutOfMemoryError("Simulated OOM during allocation");
                        throw thrownException;
                    }
                    set0 = new TreeSet();
                }
                catch (Exception e) {
                    TRAPCOUNT++;
                    System.out.println("Exception caught during allocation");
                }
                shouldThrowException = false;
                try {
                    if (shouldThrowException) {
                        OutOfMemoryError thrownException = new OutOfMemoryError("Simulated OOM during allocation");
                        throw thrownException;
                    }
                    allocatedObjects.add(new GCObj(1800442));
                }
                catch (Exception e) {
                    TRAPCOUNT++;
                    System.out.println("Exception caught during allocation");
                }
                whileCounter = 0;
                while (whileCounter < 3) {
                    objVar3 = new PhantomReference(gcObj5, new ReferenceQueue());
                    whileCounter++;
                }
                System.out.println("MAR Round 27");
                for (int i = 0;  i < 4; i++) {
                    allocatedObjects.add(new GCObj(4248758));
                }
                shouldThrowException = false;
                try {
                    if (shouldThrowException) {
                        OutOfMemoryError thrownException = new OutOfMemoryError("Simulated OOM during allocation");
                        throw thrownException;
                    }
                }
                catch (Exception e) {
                    TRAPCOUNT++;
                    System.out.println("Exception caught during allocation");
                }
                whileCounter = 0;
                while (whileCounter < 2) {
                    list1 = new ArrayList();
                    whileCounter++;
                }
                if (TRAPCOUNT % 2  == 0) {
                    set0 = new TreeSet();
                }
                else {
                    objVar3 = new PhantomReference(gcObj5, new ReferenceQueue());
                }
                whileCounter = 0;
                while (whileCounter<2) {
                    arr1 = new int[3988];
                    whileCounter++;
                }
                System.gc();
            }
        }
    }

    @WorkerMetadata(threadId = 1)
    static class MDRWorker implements Runnable {
        private static final Random random = new Random(0L);
        @Override
        public void run() {
            int switchVar = 0;
            int whileCounter = 0;
            int doWhileCounter = 0;
            boolean shouldThrowException = false;
            while (mdrRoundCounter<7) {
                ++mdrRoundCounter;
                int currentRound = mdrRoundCounter;
                System.out.println("MDR Round 1");
                if (gcObj5 != null) {
                    gcObj5.releaseAllReferences();
                    gcObj5 = null;
                }
                if (gcObj3 != null) {
                    gcObj3.releaseAllReferences();
                    gcObj3 = null;
                }
                shouldThrowException = false;
                System.gc();
                System.out.println("MDR Round 2");
                if (random.nextDouble() < 0.5) {
                    set0 = null;
                }
                else {
                }
                shouldThrowException = false;
                try {
                    if (shouldThrowException) {
                        IllegalStateException thrownException = new IllegalStateException("Error during deallocation");
                        throw thrownException;
                    }
                    arr3 = null;
                }
                catch (Exception e) {
                    TRAPCOUNT++;
                    System.out.println("Exception caught during deallocation");
                }
                System.gc();
                System.out.println("MDR Round 3");
                System.gc();
                System.out.println("System.gc()called - requesting garbage collection");
                System.gc();
                System.gc();
                System.out.println("MDR Round 4");
                System.gc();
                System.out.println("MDR Round 5");
                System.gc();
                System.out.println("System.gc()called - requesting garbage collection");
                System.gc();
                System.gc();
                System.out.println("MDR Round 6");
                System.gc();
                System.out.println("System.gc()called - requesting garbage collection");
                System.gc();
                System.gc();
                System.out.println("MDR Round 7");
                System.gc();
                System.out.println("System.gc()called - requesting garbage collection");
                System.gc();
                System.gc();
            }
        }
    }

    @WorkerMetadata(threadId = 2)
    static class MMRWorker implements Runnable {
        private static final Random random = new Random(0L);
        @Override
        public void run() {
            int safeIndex = 0;
            int switchVar = 0;
            int whileCounter = 0;
            int doWhileCounter = 0;
            boolean shouldThrowException = false;
            while (mmrRoundCounter < 9) {
                ++mmrRoundCounter;
                int currentRound = mmrRoundCounter;
                System.out.println("MMR Round 1");
                gcObj0 = new GCObj(62193);
                if (list0 != null && list0.size()> 0) {
                    list0.set(0, new Object());
                }
                if (arr0 != null && arr0.length > 0) {
                    safeIndex = arr0.length > 0 ? arr0.length / 2 : 0;
                    arr0[safeIndex] = "element_1";
                }
                gcObj4.replaceStrongReference(null);
                list1.clear();
                System.out.println("MMR Round 2");
                if (arr0 != null && arr0.length > 0) {
                    arr0[0] = "element_66";
                }
                if (MARWorker.objVar7 != null && MARWorker.objVar7.length > 0) {
                    MARWorker.objVar7[0] = "element_52";
                }
                gcObj7.modifyArrayElement(7, 677);
                gcObj6 = new GCObj(64570);
                gcObj1 = new GCObj(50265);
                System.out.println("MMR Round 3");
                if (arr2 != null && arr2.length > 0) {
                    arr2[0] = 616;
                }
                list0.add(new Object());
                MARWorker.objVar8 = new int[25986];
                if (arr2 != null && arr2.length > 0) {
                    safeIndex = arr2.length > 0 ? arr2.length / 2 : 0;
                    arr2[safeIndex] = 487;
                }
                if (MARWorker.objVar8 != null && MARWorker.objVar8.length > 0) {
                    MARWorker.objVar8[0] = 928;
                }
                System.out.println("MMR Round 4");
                gcObj7 = new GCObj(42293);
                gcObj0.processGCObj();
                list1.add(new Object());
                list0.add(new Object());
                for (int i = 0;  i<1; i++) {
                    if (MARWorker.objVar7 != null && MARWorker.objVar7.length> 0) {
                        safeIndex = MARWorker.objVar7.length > 0 ? MARWorker.objVar7.length / 2 : 0;
                        MARWorker.objVar7[safeIndex] = "element_49";
                    }
                }
                System.out.println("MMR Round 5");
                gcObj1 = new GCObj(65449);
                gcObj6 = new GCObj(5263);
                MARWorker.objVar7 = new Object[897];
                if (arr0 != null && arr0.length > 0) {
                    safeIndex = arr0.length > 0 ? arr0.length / 2 : 0;
                    arr0[safeIndex] = "element_56";
                }
                gcObj7.processGCObj();
                System.out.println("MMR Round 6");
                gcObj7 = new GCObj(29588);
                if (list0 != null && list0.size() > 0) {
                    list0.set(0, new Object());
                }
                gcObj1.replaceStrongReference(null);
                gcObj6.replaceStrongReference(null);
                if (arr0 != null && arr0.length > 0) {
                    arr0[0] = "element_46";
                }
                System.out.println("MMR Round 7");
                gcObj0.processGCObj();
                gcObj2.processGCObj();
                gcObj0.processGCObj();
                gcObj1.modifyArrayElement(6, 900);
                if (arr0 != null && arr0.length > 0) {
                    safeIndex = arr0.length > 0 ? arr0.length / 2 : 0;
                    arr0[safeIndex] = "element_6";
                }
                System.out.println("MMR Round 8");
                if (random.nextBoolean()) {
                    if (MARWorker.objVar7 != null && MARWorker.objVar7.length > 0) {
                        safeIndex = MARWorker.objVar7.length > 0 ? MARWorker.objVar7.length / 2 : 0;
                        MARWorker.objVar7[safeIndex] = "element_43";
                    }
                }
                gcObj4.replaceStrongReference(null);
                gcObj0.replaceStrongReference(null);
                list0.add(new Object());
                gcObj7.processGCObj();
                System.out.println("MMR Round 9");
                gcObj0.processGCObj();
                list0 = new Vector();
                gcObj1 = new GCObj(17093);
                gcObj1.replaceStrongReference(null);
                if (arr2 != null && arr2.length > 0) {
                    arr2[0] = 786;
                }
            }
        }
    }

    @WorkerMetadata(threadId = 3)
    static class SPARWorker implements Runnable {
        private static final Random random = new Random(0L);
        @Override
        public void run() {
            int switchVar = 0;
            int whileCounter = 0;
            int doWhileCounter = 0;
            boolean shouldThrowException = false;
            while (sparRoundCounter < 7) {
                ++sparRoundCounter;
                int currentRound = sparRoundCounter;
                System.out.println("SPAR Round 1");
                doWhileCounter = 0;
                do {
                    int temp992 = 59;
                    doWhileCounter++;
                }
                while (doWhileCounter < 3);
                doWhileCounter = 0;
                do {
                    int temp208 = 25;
                    doWhileCounter++;
                }
                while (doWhileCounter < 6);
                shouldThrowException = false;
                try {
                    if (shouldThrowException) {
                        RuntimeException thrownException = new RuntimeException("GCFuzz generated RuntimeException for testing");
                        throw thrownException;
                    }
                    arr1[0] = 17;
                }
                catch (Exception e) {
                    TRAPCOUNT++;
                    System.out.println("Exception caught");
                }
                System.out.println("SPAR Round 2");
                shouldThrowException = false;
                try {
                    if (shouldThrowException) {
                        IllegalStateException thrownException = new IllegalStateException("GCFuzz generated IllegalStateException for testing");
                        throw thrownException;
                    }
                    arr1[0] = 43;
                }
                catch (Exception e) {
                    TRAPCOUNT++;
                    System.out.println("Exception caught");
                }
                for (int i = 0;  i < 9; i++) {
                    int temp848 = 77;
                }
                whileCounter = 0;
                while (whileCounter < 10) {
                    int temp775 = 53;
                    whileCounter++;
                }
                if (gcObj0 != null) {
                    int temp685 = 1;
                }
                System.out.println("SPAR Round 3");
                for (int i = 0;  i < 10; i++) {
                    int temp831 = 21;
                }
                switchVar = 0;
                switch (switchVar) {
                    case 0:
                    int temp152 = 37;
                    break;
                    case 1:
                    int temp632 = 49;
                    break;
                    case 2:
                    int temp569 = 38;
                    break;
                    default :
                    int temp282 = 39;
                }
                for (int i = 0;  i < 5; i++) {
                    if (gcObj1 != null) {
                        gcObj1.processGCObj();
                    }
                }
                if (gcObj4 != null) {
                    int temp768 = 55;
                }
                else {
                    if (gcObj6 != null) {
                        gcObj6.processGCObj();
                    }
                }
                if (arr0 != null) {
                }
                else {
                    if (gcObj4 != null) {
                        gcObj4.processGCObj();
                    }
                }
                System.out.println("SPAR Round 4");
                shouldThrowException = false;
                try {
                    if (shouldThrowException) {
                        IllegalStateException thrownException = new IllegalStateException("GCFuzz generated IllegalStateException for testing");
                        throw thrownException;
                    }
                    arr1[0] = 98;
                }
                catch (Exception e) {
                    TRAPCOUNT++;
                    System.out.println("Exception caught");
                }
                shouldThrowException = false;
                try {
                    if (shouldThrowException) {
                        RuntimeException thrownException = new RuntimeException("GCFuzz generated RuntimeException for testing");
                        throw thrownException;
                    }
                    arr1[0] = 10;
                }
                catch (Exception e) {
                    TRAPCOUNT++;
                    System.out.println("Exception caught");
                }
                shouldThrowException = false;
                try {
                    if (shouldThrowException) {
                        IndexOutOfBoundsException thrownException = new IndexOutOfBoundsException("GCFuzz generated IndexOutOfBoundsException for testing");
                        throw thrownException;
                    }
                    arr1[0] = 32;
                }
                catch (Exception e) {
                    TRAPCOUNT++;
                    System.out.println("Exception caught");
                }
                System.out.println("SPAR Round 5");
                for (int i = 0;  i < 10; i++) {
                    if (gcObj0 != null) {
                        gcObj0.processGCObj();
                    }
                }
                switchVar = 1;
                switch (switchVar) {
                    case 0:
                    if (gcObj0 != null) {
                        gcObj0.processGCObj();
                    }
                    break;
                    case 1:
                    int temp63 = 37;
                    break;
                    case 2:
                    int temp389 = 38;
                    break;
                    default :
                    if (gcObj1 != null) {
                        gcObj1.processGCObj();
                    }
                }
                for (int i = 0;  i < 5; i++) {
                    if (gcObj7 != null) {
                        gcObj7.processGCObj();
                    }
                }
                for (int i = 0;  i < 13; i++) {
                    if (gcObj0 != null) {
                        gcObj0.processGCObj();
                    }
                }
                for (int i = 0;  i < 8; i++) {
                    int temp971 = 80;
                }
                System.out.println("SPAR Round 6");
                doWhileCounter = 0;
                do {
                    int temp163 = 63;
                    doWhileCounter++;
                }
                while (doWhileCounter < 5);
                shouldThrowException = false;
                try {
                    if (shouldThrowException) {
                        IndexOutOfBoundsException thrownException = new IndexOutOfBoundsException("GCFuzz generated IndexOutOfBoundsException for testing");
                        throw thrownException;
                    }
                    arr1[0] = 54;
                }
                catch (Exception e) {
                    TRAPCOUNT++;
                    System.out.println("Exception caught");
                }
                for (int i = 0;  i < 7; i++) {
                    int temp512 = 37;
                }
                switchVar = 1;
                System.out.println("SPAR Round 7");
                shouldThrowException = false;
                try {
                    if (shouldThrowException) {
                        IndexOutOfBoundsException thrownException = new IndexOutOfBoundsException("GCFuzz generated IndexOutOfBoundsException for testing");
                        throw thrownException;
                    }
                    arr1[0] = 93;
                }
                catch (Exception e) {
                    TRAPCOUNT++;
                    System.out.println("Exception caught");
                }
                finally {
                    System.gc();
                }
                switchVar = 1;
                switch (switchVar) {
                    case 0:
                    if (gcObj7 != null) {
                        gcObj7.processGCObj();
                    }
                    break;
                    case 1:
                    int temp168 = 89;
                    break;
                    case 2:
                    if (gcObj7 != null) {
                        gcObj7.processGCObj();
                    }
                    break;
                    default :
                    int temp885 = 46;
                }
                if (gcObj1 != null) {
                    int temp535 = 81;
                }
                else {
                    int temp505 = 60;
                }
                doWhileCounter = 0;
            }
        }
    }
}
